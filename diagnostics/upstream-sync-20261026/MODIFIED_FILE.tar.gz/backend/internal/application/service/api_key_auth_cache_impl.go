package service

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"math/rand/v2"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/domain"
	"github.com/Wei-Shaw/sub2api/internal/platform/config"
	"github.com/dgraph-io/ristretto"
)

const apiKeyAuthSnapshotVersion = 26 // v26: include group image_count_billing; preserve v25 distillation policy

type apiKeyAuthCacheConfig struct {
	l1Size        int
	l1TTL         time.Duration
	l2TTL         time.Duration
	negativeTTL   time.Duration
	jitterPercent int
	singleflight  bool
}

type apiKeyAuthHotCacheEntry struct {
	digest    [sha256.Size]byte
	entry     *APIKeyAuthCacheEntry
	apiKey    *APIKey
	expiresAt int64
}

func newAPIKeyAuthCacheConfig(cfg *config.Config) apiKeyAuthCacheConfig {
	if cfg == nil {
		return apiKeyAuthCacheConfig{}
	}
	auth := cfg.APIKeyAuth
	return apiKeyAuthCacheConfig{
		l1Size:        auth.L1Size,
		l1TTL:         time.Duration(auth.L1TTLSeconds) * time.Second,
		l2TTL:         time.Duration(auth.L2TTLSeconds) * time.Second,
		negativeTTL:   time.Duration(auth.NegativeTTLSeconds) * time.Second,
		jitterPercent: auth.JitterPercent,
		singleflight:  auth.Singleflight,
	}
}

func (c apiKeyAuthCacheConfig) l1Enabled() bool {
	return c.l1Size > 0 && c.l1TTL > 0
}

func (c apiKeyAuthCacheConfig) l2Enabled() bool {
	return c.l2TTL > 0
}

func (c apiKeyAuthCacheConfig) negativeEnabled() bool {
	return c.negativeTTL > 0
}

// jitterTTL 为缓存 TTL 添加抖动，避免多个请求在同一时刻同时过期触发集中回源。
// 这里直接使用 rand/v2 的顶层函数：并发安全，无需全局互斥锁。
func (c apiKeyAuthCacheConfig) jitterTTL(ttl time.Duration) time.Duration {
	if ttl <= 0 {
		return ttl
	}
	if c.jitterPercent <= 0 {
		return ttl
	}
	percent := c.jitterPercent
	if percent > 100 {
		percent = 100
	}
	delta := float64(percent) / 100
	randVal := rand.Float64()
	factor := 1 - delta + randVal*(2*delta)
	if factor <= 0 {
		return ttl
	}
	return time.Duration(float64(ttl) * factor)
}

func (s *APIKeyService) initAuthCache(cfg *config.Config) {
	s.authCfg = newAPIKeyAuthCacheConfig(cfg)
	if s.authCfg.negativeEnabled() {
		negativeSize := defaultNegativeAuthCacheSize
		if s.authCfg.l1Size > 0 && s.authCfg.l1Size < negativeSize {
			negativeSize = s.authCfg.l1Size
		}
		cache, err := ristretto.NewCache(&ristretto.Config{
			NumCounters: int64(negativeSize) * 10,
			MaxCost:     int64(negativeSize),
			BufferItems: 64,
		})
		if err == nil {
			s.authNegativeCacheL1 = cache
		}
	}
	if s.authCfg.l1Enabled() {
		cache, err := ristretto.NewCache(&ristretto.Config{
			NumCounters: int64(s.authCfg.l1Size) * 10,
			MaxCost:     int64(s.authCfg.l1Size),
			BufferItems: 64,
		})
		if err == nil {
			s.authCacheL1 = cache
		}
	}
}

// StartAuthCacheInvalidationSubscriber starts the Pub/Sub subscriber for L1 cache invalidation.
// This should be called after the service is fully initialized.
func (s *APIKeyService) StartAuthCacheInvalidationSubscriber(ctx context.Context) {
	if s.cache == nil || (s.authCacheL1 == nil && s.authNegativeCacheL1 == nil) {
		return
	}
	s.authInvalidationStart.Do(func() {
		subscriberCtx, cancel := context.WithCancel(ctx)
		subscriberCtx = withAuthCacheSubscriptionReady(subscriberCtx, func() {
			s.authInvalidationConnected.Store(true)
		})
		s.authInvalidationCancel = cancel
		s.authInvalidationWG.Add(1)
		go func() {
			defer s.authInvalidationWG.Done()
			backoff := time.Second
			for {
				err := s.cache.SubscribeAuthCacheInvalidation(subscriberCtx, func(cacheKey string) {
					s.invalidateLocalAuthCache(cacheKey)
				})
				wasConnected := s.authInvalidationConnected.Swap(false)
				if subscriberCtx.Err() != nil {
					return
				}
				if wasConnected {
					backoff = time.Second
				}
				s.authInvalidationFailures.Add(1)
				if err == nil {
					err = errors.New("auth cache invalidation subscription closed")
				}
				slog.Warn("failed to start auth cache invalidation subscriber; retrying", "error", err, "retry_in", backoff)
				timer := time.NewTimer(backoff)
				select {
				case <-subscriberCtx.Done():
					timer.Stop()
					return
				case <-timer.C:
				}
				if backoff < 30*time.Second {
					backoff *= 2
					if backoff > 30*time.Second {
						backoff = 30 * time.Second
					}
				}
			}
		}()
	})
}

func (s *APIKeyService) invalidateLocalAuthCache(cacheKey string) {
	if s == nil {
		return
	}
	if s.authCacheL1 != nil {
		s.authCacheL1.Del(cacheKey)
	}
	if s.authNegativeCacheL1 != nil {
		s.authNegativeCacheL1.Del(cacheKey)
	}
	s.clearAuthHotCacheEntry(cacheKey)
}

type AuthCacheInvalidationSubscriberHealth struct {
	Connected bool   `json:"connected"`
	Failures  uint64 `json:"failures"`
}

func (s *APIKeyService) AuthCacheInvalidationSubscriberHealth() AuthCacheInvalidationSubscriberHealth {
	if s == nil {
		return AuthCacheInvalidationSubscriberHealth{}
	}
	return AuthCacheInvalidationSubscriberHealth{
		Connected: s.authInvalidationConnected.Load(),
		Failures:  s.authInvalidationFailures.Load(),
	}
}

func (s *APIKeyService) StopAuthCacheInvalidationSubscriber() {
	if s == nil {
		return
	}
	s.authInvalidationStop.Do(func() {
		if s.authInvalidationCancel != nil {
			s.authInvalidationCancel()
		}
		s.authInvalidationWG.Wait()
	})
}

func (s *APIKeyService) authCacheKey(key string) string {
	return authCacheKeyFromDigest(authCacheDigest(key))
}

func authCacheDigest(key string) [sha256.Size]byte {
	return sha256.Sum256([]byte(key))
}

func authCacheKeyFromDigest(digest [sha256.Size]byte) string {
	return hex.EncodeToString(digest[:])
}

func (s *APIKeyService) getAuthHotCacheEntry(digest [sha256.Size]byte, now time.Time) (*apiKeyAuthHotCacheEntry, bool) {
	if s == nil {
		return nil, false
	}
	hot := s.authHotCache.Load()
	if hot == nil || hot.digest != digest || hot.entry == nil {
		return nil, false
	}
	if hot.expiresAt <= now.UnixNano() {
		s.authHotCache.CompareAndSwap(hot, nil)
		return nil, false
	}
	return hot, true
}

func (s *APIKeyService) setAuthHotCacheEntry(digest [sha256.Size]byte, key string, entry *APIKeyAuthCacheEntry) {
	if s == nil || entry == nil || entry.NotFound || entry.Snapshot == nil || entry.Snapshot.Version != apiKeyAuthSnapshotVersion {
		return
	}
	now := time.Now()
	current := s.authHotCache.Load()
	if current != nil && current.expiresAt > now.UnixNano() {
		// Keep the current hot key stable. Replacing it on every ordinary L1 hit
		// would turn mixed-key traffic into allocation and cache-line churn.
		return
	}
	ttl := s.authCfg.l1TTL
	if !s.authCfg.l1Enabled() {
		return
	}
	if ttl <= 0 {
		return
	}
	prototype := s.authCacheRuntimeAPIKey(entry)
	if prototype == nil {
		return
	}
	clone := *prototype
	clone.Key = key
	ttl = s.authCfg.jitterTTL(ttl)
	hot := &apiKeyAuthHotCacheEntry{
		digest:    digest,
		entry:     entry,
		apiKey:    &clone,
		expiresAt: now.Add(ttl).UnixNano(),
	}
	if current == nil {
		s.authHotCache.CompareAndSwap(nil, hot)
		return
	}
	s.authHotCache.CompareAndSwap(current, hot)
}

func (s *APIKeyService) applyAuthHotCacheEntry(key string, hot *apiKeyAuthHotCacheEntry) (*APIKey, bool, error) {
	if hot == nil || hot.entry == nil {
		return nil, false, nil
	}
	entry := hot.entry
	if entry.NotFound {
		return nil, true, ErrAPIKeyNotFound
	}
	if entry.Snapshot == nil || entry.Snapshot.Version != apiKeyAuthSnapshotVersion {
		return nil, false, nil
	}
	if hot.apiKey == nil || hot.apiKey.Key != key {
		return s.applyAuthCacheEntry(key, entry)
	}
	return hot.apiKey, true, nil
}

func (s *APIKeyService) clearAuthHotCacheEntry(cacheKey string) {
	if s == nil || len(cacheKey) != sha256.Size*2 {
		return
	}
	decoded, err := hex.DecodeString(cacheKey)
	if err != nil || len(decoded) != sha256.Size {
		return
	}
	var digest [sha256.Size]byte
	copy(digest[:], decoded)
	for {
		hot := s.authHotCache.Load()
		if hot == nil || hot.digest != digest {
			return
		}
		if s.authHotCache.CompareAndSwap(hot, nil) {
			return
		}
	}
}

func (s *APIKeyService) getAuthCacheEntry(ctx context.Context, cacheKey string) (*APIKeyAuthCacheEntry, bool) {
	if s.authCacheL1 != nil {
		if val, ok := s.authCacheL1.Get(cacheKey); ok {
			if entry, ok := val.(*APIKeyAuthCacheEntry); ok {
				return entry, true
			}
		}
	}
	if s.authNegativeCacheL1 != nil {
		if val, ok := s.authNegativeCacheL1.Get(cacheKey); ok {
			if entry, ok := val.(*APIKeyAuthCacheEntry); ok && entry.NotFound {
				return entry, true
			}
		}
	}
	if s.cache == nil || !s.authCfg.l2Enabled() {
		return nil, false
	}
	entry, err := s.cache.GetAuthCache(ctx, cacheKey)
	if err != nil {
		return nil, false
	}
	s.setAuthCacheL1(cacheKey, entry)
	return entry, true
}

func (s *APIKeyService) setAuthCacheL1(cacheKey string, entry *APIKeyAuthCacheEntry) {
	if entry == nil {
		return
	}
	if entry.NotFound {
		if s.authNegativeCacheL1 != nil && s.authCfg.negativeTTL > 0 {
			_ = s.authNegativeCacheL1.SetWithTTL(cacheKey, entry, 1, s.authCfg.jitterTTL(s.authCfg.negativeTTL))
		}
		return
	}
	if s.authCacheL1 == nil {
		return
	}
	ttl := s.authCfg.l1TTL
	ttl = s.authCfg.jitterTTL(ttl)
	_ = s.authCacheL1.SetWithTTL(cacheKey, entry, 1, ttl)
}

func (s *APIKeyService) setAuthCacheEntry(ctx context.Context, cacheKey string, entry *APIKeyAuthCacheEntry, ttl time.Duration) {
	if entry == nil {
		return
	}
	s.setAuthCacheL1(cacheKey, entry)
	if s.cache == nil || !s.authCfg.l2Enabled() {
		return
	}
	_ = s.cache.SetAuthCache(ctx, cacheKey, entry, s.authCfg.jitterTTL(ttl))
}

func (s *APIKeyService) deleteAuthCache(ctx context.Context, cacheKey string) {
	s.clearAuthHotCacheEntry(cacheKey)
	if s.authCacheL1 != nil {
		s.authCacheL1.Del(cacheKey)
	}
	if s.authNegativeCacheL1 != nil {
		s.authNegativeCacheL1.Del(cacheKey)
	}
	if s.cache == nil {
		return
	}
	_ = s.cache.DeleteAuthCache(ctx, cacheKey)
	// Publish invalidation message to other instances
	_ = s.cache.PublishAuthCacheInvalidation(ctx, cacheKey)
}

func (s *APIKeyService) loadAuthCacheEntry(ctx context.Context, key, cacheKey string) (*APIKeyAuthCacheEntry, error) {
	apiKey, err := s.lookupAPIKeyForAuth(ctx, key)
	if err != nil {
		if errors.Is(err, ErrAPIKeyNotFound) {
			entry := &APIKeyAuthCacheEntry{NotFound: true}
			if s.authCfg.negativeEnabled() {
				// Invalid keys are attacker-controlled and high-cardinality. Keep their
				// negative entries in the bounded process-local cache; do not amplify
				// random-key scans into Redis writes on every instance.
				s.setAuthCacheL1(cacheKey, entry)
			}
			return entry, nil
		}
		return nil, fmt.Errorf("get api key: %w", err)
	}
	apiKey.Key = key
	snapshot := s.snapshotFromAPIKey(ctx, apiKey)
	if snapshot == nil {
		return nil, fmt.Errorf("get api key: %w", ErrAPIKeyNotFound)
	}
	entry := &APIKeyAuthCacheEntry{Snapshot: snapshot}
	s.setAuthCacheEntry(ctx, cacheKey, entry, s.authCfg.l2TTL)
	return entry, nil
}

func (s *APIKeyService) lookupAPIKeyForAuth(ctx context.Context, key string) (*APIKey, error) {
	if s == nil || s.apiKeyRepo == nil {
		return nil, ErrAPIKeyNotFound
	}
	if s.authLookupSlots == nil {
		apiKey, err := s.apiKeyRepo.GetByKeyForAuth(ctx, key)
		if err == nil {
			s.hydrateAPIKeyGroupBindingsForAuth(ctx, apiKey)
		}
		return apiKey, err
	}
	s.authLookupTotal.Add(1)
	select {
	case s.authLookupSlots <- struct{}{}:
		s.authLookupInFlight.Add(1)
		defer func() {
			s.authLookupInFlight.Add(-1)
			<-s.authLookupSlots
		}()
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
		s.authLookupRejected.Add(1)
		return nil, ErrAPIKeyAuthOverloaded
	}
	apiKey, err := s.apiKeyRepo.GetByKeyForAuth(ctx, key)
	if err == nil {
		s.hydrateAPIKeyGroupBindingsForAuth(ctx, apiKey)
	}
	return apiKey, err
}

func (s *APIKeyService) hydrateAPIKeyGroupBindingsForAuth(ctx context.Context, apiKey *APIKey) {
	if s == nil || apiKey == nil {
		return
	}
	bindings := apiKey.GroupBindings
	if len(bindings) == 0 && apiKey.GroupID != nil && *apiKey.GroupID > 0 {
		bindings = []APIKeyGroupBinding{{APIKeyGroupBinding: domain.APIKeyGroupBinding{GroupID: *apiKey.GroupID}}}
	}
	if len(bindings) == 0 {
		return
	}

	var userRates map[int64]float64
	if s.userGroupRateRepo != nil && apiKey.UserID > 0 {
		userRates, _ = s.userGroupRateRepo.GetByUserID(ctx, apiKey.UserID)
	}
	for i := range bindings {
		group := bindings[i].Group
		if group == nil && apiKey.Group != nil && apiKey.Group.ID == bindings[i].GroupID {
			group = apiKey.Group
		}
		if group == nil && s.groupRepo != nil {
			group, _ = s.groupRepo.GetByID(ctx, bindings[i].GroupID)
		}
		bindings[i].Group = group
		if group != nil {
			bindings[i].EffectiveRateMultiplier = group.RateMultiplier
		}
		if rate, ok := userRates[bindings[i].GroupID]; ok {
			bindings[i].EffectiveRateMultiplier = rate
		}
	}
	apiKey.GroupBindings = bindings
}

func (s *APIKeyService) applyAuthCacheEntry(key string, entry *APIKeyAuthCacheEntry) (*APIKey, bool, error) {
	if entry == nil {
		return nil, false, nil
	}
	if entry.NotFound {
		return nil, true, ErrAPIKeyNotFound
	}
	if entry.Snapshot == nil {
		return nil, false, nil
	}
	if entry.Snapshot.Version != apiKeyAuthSnapshotVersion {
		return nil, false, nil
	}
	prototype := s.authCacheRuntimeAPIKey(entry)
	if prototype == nil {
		return nil, false, nil
	}
	apiKey := *prototype
	apiKey.Key = key
	return &apiKey, true, nil
}

func (s *APIKeyService) authCacheRuntimeAPIKey(entry *APIKeyAuthCacheEntry) *APIKey {
	if entry == nil || entry.Snapshot == nil {
		return nil
	}
	if prototype := entry.runtimeAPIKey.Load(); prototype != nil {
		return prototype
	}
	entry.runtimeMu.Lock()
	defer entry.runtimeMu.Unlock()
	if prototype := entry.runtimeAPIKey.Load(); prototype != nil {
		return prototype
	}
	prototype := s.snapshotToAPIKey("", entry.Snapshot)
	if prototype != nil {
		// User, Group, compiled IP rules, and nested routing config are immutable for
		// the lifetime of an auth-cache entry. Invalidation replaces the whole entry.
		entry.runtimeAPIKey.Store(prototype)
	}
	return prototype
}

func (s *APIKeyService) snapshotFromAPIKey(ctx context.Context, apiKey *APIKey) *APIKeyAuthSnapshot {
	if apiKey == nil || apiKey.User == nil {
		return nil
	}
	snapshot := &APIKeyAuthSnapshot{
		Version:          apiKeyAuthSnapshotVersion,
		APIKeyID:         apiKey.ID,
		UserID:           apiKey.UserID,
		GroupID:          apiKey.GroupID,
		Name:             apiKey.Name,
		Status:           apiKey.Status,
		IPWhitelist:      apiKey.IPWhitelist,
		IPBlacklist:      apiKey.IPBlacklist,
		Quota:            apiKey.Quota,
		QuotaUsed:        apiKey.QuotaUsed,
		ExpiresAt:        apiKey.ExpiresAt,
		ConcurrencyLimit: apiKey.ConcurrencyLimit,
		RateLimit5h:      apiKey.RateLimit5h,
		RateLimit1d:      apiKey.RateLimit1d,
		RateLimit7d:      apiKey.RateLimit7d,
		User: APIKeyAuthUserSnapshot{
			ID:                         apiKey.User.ID,
			Status:                     apiKey.User.Status,
			Role:                       apiKey.User.Role,
			Balance:                    apiKey.User.Balance,
			Concurrency:                apiKey.User.Concurrency,
			SchedulingTier:             NormalizeRequestSchedulingTier(apiKey.User.SchedulingTier),
			AllowedGroups:              apiKey.User.AllowedGroups,
			Email:                      apiKey.User.Email,
			Username:                   apiKey.User.Username,
			BalanceNotifyEnabled:       apiKey.User.BalanceNotifyEnabled,
			BalanceNotifyThresholdType: apiKey.User.BalanceNotifyThresholdType,
			BalanceNotifyThreshold:     apiKey.User.BalanceNotifyThreshold,
			BalanceNotifyExtraEmails:   apiKey.User.BalanceNotifyExtraEmails,
			TotalRecharged:             apiKey.User.TotalRecharged,
			RPMLimit:                   apiKey.User.RPMLimit,
		},
	}

	// 填充 (user, group) RPM override —— snapshot 构建时查一次 DB，后续请求零 DB 往返。
	if apiKey.GroupID != nil && *apiKey.GroupID > 0 && s.userGroupRateRepo != nil {
		override, err := s.userGroupRateRepo.GetRPMOverrideByUserAndGroup(ctx, apiKey.UserID, *apiKey.GroupID)
		if err == nil && override != nil {
			snapshot.User.UserGroupRPMOverride = override
		}
		// 查询失败或无 override 时留 nil，checkRPM 会回退到 DB 查询
	}
	if apiKey.Group != nil {
		snapshot.Group = &APIKeyAuthGroupSnapshot{
			ID:                              apiKey.Group.ID,
			Name:                            apiKey.Group.Name,
			Platform:                        apiKey.Group.Platform,
			IsExclusive:                     apiKey.Group.IsExclusive,
			Status:                          apiKey.Group.Status,
			SubscriptionType:                apiKey.Group.SubscriptionType,
			RateMultiplier:                  apiKey.Group.RateMultiplier,
			DailyLimitUSD:                   apiKey.Group.DailyLimitUSD,
			WeeklyLimitUSD:                  apiKey.Group.WeeklyLimitUSD,
			MonthlyLimitUSD:                 apiKey.Group.MonthlyLimitUSD,
			AllowImageGeneration:            apiKey.Group.AllowImageGeneration,
			OpenAIForceImageTool:            apiKey.Group.OpenAIForceImageTool,
			AllowBatchImageGeneration:       apiKey.Group.AllowBatchImageGeneration,
			ImageCountBilling:               apiKey.Group.ImageCountBilling,
			ImageRateIndependent:            apiKey.Group.ImageRateIndependent,
			ImageRateMultiplier:             apiKey.Group.ImageRateMultiplier,
			ImagePrice1K:                    apiKey.Group.ImagePrice1K,
			ImagePrice2K:                    apiKey.Group.ImagePrice2K,
			ImagePrice4K:                    apiKey.Group.ImagePrice4K,
			VideoRateIndependent:            apiKey.Group.VideoRateIndependent,
			VideoRateMultiplier:             apiKey.Group.VideoRateMultiplier,
			VideoPrice480P:                  apiKey.Group.VideoPrice480P,
			VideoPrice720P:                  apiKey.Group.VideoPrice720P,
			VideoPrice1080P:                 apiKey.Group.VideoPrice1080P,
			WebSearchPricePerCall:           apiKey.Group.WebSearchPricePerCall,
			LongContextPricingEnabled:       apiKey.Group.LongContextPricingEnabled,
			ModelPricing:                    cloneGroupModelPricing(apiKey.Group.ModelPricing),
			ClaudeCodeOnly:                  apiKey.Group.ClaudeCodeOnly,
			IsDistillationGroup:             apiKey.Group.IsDistillationGroup,
			FallbackGroupID:                 apiKey.Group.FallbackGroupID,
			FallbackGroupIDOnInvalidRequest: apiKey.Group.FallbackGroupIDOnInvalidRequest,
			ModelRouting:                    apiKey.Group.ModelRouting,
			ModelRoutingEnabled:             apiKey.Group.ModelRoutingEnabled,
			MCPXMLInject:                    apiKey.Group.MCPXMLInject,
			SupportedModelScopes:            apiKey.Group.SupportedModelScopes,
			AllowMessagesDispatch:           apiKey.Group.AllowMessagesDispatch,
			AllowLive:                       apiKey.Group.AllowLive,
			DefaultMappedModel:              apiKey.Group.DefaultMappedModel,
			MessagesDispatchModelConfig:     apiKey.Group.MessagesDispatchModelConfig,
			ModelsListConfig:                apiKey.Group.ModelsListConfig,
			ModelAllowlist:                  apiKey.Group.ModelAllowlist,
			RPMLimit:                        apiKey.Group.RPMLimit,
			MaxReasoningEffort:              apiKey.Group.MaxReasoningEffort,
			ReasoningEffortMappings:         apiKey.Group.ReasoningEffortMappings,
			PeakRateEnabled:                 apiKey.Group.PeakRateEnabled,
			PeakStart:                       apiKey.Group.PeakStart,
			PeakEnd:                         apiKey.Group.PeakEnd,
			PeakRateMultiplier:              apiKey.Group.PeakRateMultiplier,
			ProfitControlEnabled:            apiKey.Group.ProfitControlEnabled,
			ProfitMinMargin:                 apiKey.Group.ProfitMinMargin,
			ProfitSafetyBuffer:              apiKey.Group.ProfitSafetyBuffer,
		}
	}
	if len(apiKey.GroupBindings) > 0 {
		snapshot.GroupBindings = make([]APIKeyAuthGroupBindingSnapshot, 0, len(apiKey.GroupBindings))
		for i := range apiKey.GroupBindings {
			binding := apiKey.GroupBindings[i]
			snapshot.GroupBindings = append(snapshot.GroupBindings, APIKeyAuthGroupBindingSnapshot{
				APIKeyGroupBinding:      binding.APIKeyGroupBinding,
				EffectiveRateMultiplier: binding.EffectiveRateMultiplier,
				Group:                   apiKeyAuthGroupSnapshotFromGroup(binding.Group),
			})
		}
	}
	return snapshot
}

func (s *APIKeyService) snapshotToAPIKey(key string, snapshot *APIKeyAuthSnapshot) *APIKey {
	if snapshot == nil {
		return nil
	}
	apiKey := &APIKey{
		ID:               snapshot.APIKeyID,
		UserID:           snapshot.UserID,
		GroupID:          snapshot.GroupID,
		Key:              key,
		Name:             snapshot.Name,
		Status:           snapshot.Status,
		IPWhitelist:      snapshot.IPWhitelist,
		IPBlacklist:      snapshot.IPBlacklist,
		Quota:            snapshot.Quota,
		QuotaUsed:        snapshot.QuotaUsed,
		ExpiresAt:        snapshot.ExpiresAt,
		ConcurrencyLimit: snapshot.ConcurrencyLimit,
		RateLimit5h:      snapshot.RateLimit5h,
		RateLimit1d:      snapshot.RateLimit1d,
		RateLimit7d:      snapshot.RateLimit7d,
		User: &User{
			ID:                         snapshot.User.ID,
			Status:                     snapshot.User.Status,
			Role:                       snapshot.User.Role,
			Balance:                    snapshot.User.Balance,
			Concurrency:                snapshot.User.Concurrency,
			SchedulingTier:             NormalizeRequestSchedulingTier(snapshot.User.SchedulingTier),
			AllowedGroups:              snapshot.User.AllowedGroups,
			Email:                      snapshot.User.Email,
			Username:                   snapshot.User.Username,
			BalanceNotifyEnabled:       snapshot.User.BalanceNotifyEnabled,
			BalanceNotifyThresholdType: snapshot.User.BalanceNotifyThresholdType,
			BalanceNotifyThreshold:     snapshot.User.BalanceNotifyThreshold,
			BalanceNotifyExtraEmails:   snapshot.User.BalanceNotifyExtraEmails,
			TotalRecharged:             snapshot.User.TotalRecharged,
			RPMLimit:                   snapshot.User.RPMLimit,
			UserGroupRPMOverride:       snapshot.User.UserGroupRPMOverride,
		},
	}
	if snapshot.Group != nil {
		apiKey.Group = &Group{
			ID:                              snapshot.Group.ID,
			Name:                            snapshot.Group.Name,
			Platform:                        snapshot.Group.Platform,
			IsExclusive:                     snapshot.Group.IsExclusive,
			Status:                          snapshot.Group.Status,
			Hydrated:                        true,
			SubscriptionType:                snapshot.Group.SubscriptionType,
			RateMultiplier:                  snapshot.Group.RateMultiplier,
			DailyLimitUSD:                   snapshot.Group.DailyLimitUSD,
			WeeklyLimitUSD:                  snapshot.Group.WeeklyLimitUSD,
			MonthlyLimitUSD:                 snapshot.Group.MonthlyLimitUSD,
			AllowImageGeneration:            snapshot.Group.AllowImageGeneration,
			OpenAIForceImageTool:            snapshot.Group.OpenAIForceImageTool,
			AllowBatchImageGeneration:       snapshot.Group.AllowBatchImageGeneration,
			ImageCountBilling:               snapshot.Group.ImageCountBilling,
			ImageRateIndependent:            snapshot.Group.ImageRateIndependent,
			ImageRateMultiplier:             snapshot.Group.ImageRateMultiplier,
			ImagePrice1K:                    snapshot.Group.ImagePrice1K,
			ImagePrice2K:                    snapshot.Group.ImagePrice2K,
			ImagePrice4K:                    snapshot.Group.ImagePrice4K,
			VideoRateIndependent:            snapshot.Group.VideoRateIndependent,
			VideoRateMultiplier:             snapshot.Group.VideoRateMultiplier,
			VideoPrice480P:                  snapshot.Group.VideoPrice480P,
			VideoPrice720P:                  snapshot.Group.VideoPrice720P,
			VideoPrice1080P:                 snapshot.Group.VideoPrice1080P,
			WebSearchPricePerCall:           snapshot.Group.WebSearchPricePerCall,
			LongContextPricingEnabled:       snapshot.Group.LongContextPricingEnabled,
			ModelPricing:                    snapshot.Group.ModelPricing,
			ClaudeCodeOnly:                  snapshot.Group.ClaudeCodeOnly,
			IsDistillationGroup:             snapshot.Group.IsDistillationGroup,
			FallbackGroupID:                 snapshot.Group.FallbackGroupID,
			FallbackGroupIDOnInvalidRequest: snapshot.Group.FallbackGroupIDOnInvalidRequest,
			ModelRouting:                    snapshot.Group.ModelRouting,
			ModelRoutingEnabled:             snapshot.Group.ModelRoutingEnabled,
			MCPXMLInject:                    snapshot.Group.MCPXMLInject,
			SupportedModelScopes:            snapshot.Group.SupportedModelScopes,
			AllowMessagesDispatch:           snapshot.Group.AllowMessagesDispatch,
			AllowLive:                       snapshot.Group.AllowLive,
			DefaultMappedModel:              snapshot.Group.DefaultMappedModel,
			MessagesDispatchModelConfig:     snapshot.Group.MessagesDispatchModelConfig,
			ModelsListConfig:                snapshot.Group.ModelsListConfig,
			ModelAllowlist:                  snapshot.Group.ModelAllowlist,
			RPMLimit:                        snapshot.Group.RPMLimit,
			MaxReasoningEffort:              snapshot.Group.MaxReasoningEffort,
			ReasoningEffortMappings:         snapshot.Group.ReasoningEffortMappings,
			PeakRateEnabled:                 snapshot.Group.PeakRateEnabled,
			PeakStart:                       snapshot.Group.PeakStart,
			PeakEnd:                         snapshot.Group.PeakEnd,
			PeakRateMultiplier:              snapshot.Group.PeakRateMultiplier,
			ProfitControlEnabled:            snapshot.Group.ProfitControlEnabled,
			ProfitMinMargin:                 snapshot.Group.ProfitMinMargin,
			ProfitSafetyBuffer:              snapshot.Group.ProfitSafetyBuffer,
		}
		apiKey.Group.compileModelPricingIndex()
	}
	if len(snapshot.GroupBindings) > 0 {
		apiKey.GroupBindings = make([]APIKeyGroupBinding, 0, len(snapshot.GroupBindings))
		for i := range snapshot.GroupBindings {
			binding := snapshot.GroupBindings[i]
			apiKey.GroupBindings = append(apiKey.GroupBindings, APIKeyGroupBinding{
				APIKeyGroupBinding:      binding.APIKeyGroupBinding,
				EffectiveRateMultiplier: binding.EffectiveRateMultiplier,
				Group:                   apiKeyGroupFromAuthSnapshot(binding.Group),
			})
		}
	}
	s.compileAPIKeyIPRules(apiKey)
	return apiKey
}

func apiKeyAuthGroupSnapshotFromGroup(group *Group) *APIKeyAuthGroupSnapshot {
	if group == nil {
		return nil
	}
	return &APIKeyAuthGroupSnapshot{
		ID:                              group.ID,
		Name:                            group.Name,
		Platform:                        group.Platform,
		IsExclusive:                     group.IsExclusive,
		Status:                          group.Status,
		SubscriptionType:                group.SubscriptionType,
		RateMultiplier:                  group.RateMultiplier,
		DailyLimitUSD:                   group.DailyLimitUSD,
		WeeklyLimitUSD:                  group.WeeklyLimitUSD,
		MonthlyLimitUSD:                 group.MonthlyLimitUSD,
		AllowImageGeneration:            group.AllowImageGeneration,
		OpenAIForceImageTool:            group.OpenAIForceImageTool,
		AllowBatchImageGeneration:       group.AllowBatchImageGeneration,
		ImageCountBilling:               group.ImageCountBilling,
		ImageRateIndependent:            group.ImageRateIndependent,
		ImageRateMultiplier:             group.ImageRateMultiplier,
		ImagePrice1K:                    group.ImagePrice1K,
		ImagePrice2K:                    group.ImagePrice2K,
		ImagePrice4K:                    group.ImagePrice4K,
		VideoRateIndependent:            group.VideoRateIndependent,
		VideoRateMultiplier:             group.VideoRateMultiplier,
		VideoPrice480P:                  group.VideoPrice480P,
		VideoPrice720P:                  group.VideoPrice720P,
		VideoPrice1080P:                 group.VideoPrice1080P,
		WebSearchPricePerCall:           group.WebSearchPricePerCall,
		LongContextPricingEnabled:       group.LongContextPricingEnabled,
		ModelPricing:                    cloneGroupModelPricing(group.ModelPricing),
		ClaudeCodeOnly:                  group.ClaudeCodeOnly,
		IsDistillationGroup:             group.IsDistillationGroup,
		FallbackGroupID:                 group.FallbackGroupID,
		FallbackGroupIDOnInvalidRequest: group.FallbackGroupIDOnInvalidRequest,
		ModelRouting:                    group.ModelRouting,
		ModelRoutingEnabled:             group.ModelRoutingEnabled,
		MCPXMLInject:                    group.MCPXMLInject,
		SupportedModelScopes:            group.SupportedModelScopes,
		AllowMessagesDispatch:           group.AllowMessagesDispatch,
		AllowLive:                       group.AllowLive,
		DefaultMappedModel:              group.DefaultMappedModel,
		MessagesDispatchModelConfig:     group.MessagesDispatchModelConfig,
		ModelsListConfig:                group.ModelsListConfig,
		ModelAllowlist:                  group.ModelAllowlist,
		RPMLimit:                        group.RPMLimit,
		MaxReasoningEffort:              group.MaxReasoningEffort,
		ReasoningEffortMappings:         group.ReasoningEffortMappings,
		PeakRateEnabled:                 group.PeakRateEnabled,
		PeakStart:                       group.PeakStart,
		PeakEnd:                         group.PeakEnd,
		PeakRateMultiplier:              group.PeakRateMultiplier,
		ProfitControlEnabled:            group.ProfitControlEnabled,
		ProfitMinMargin:                 group.ProfitMinMargin,
		ProfitSafetyBuffer:              group.ProfitSafetyBuffer,
	}
}

func apiKeyGroupFromAuthSnapshot(snapshot *APIKeyAuthGroupSnapshot) *Group {
	if snapshot == nil {
		return nil
	}
	group := &Group{
		ID:                              snapshot.ID,
		Name:                            snapshot.Name,
		Platform:                        snapshot.Platform,
		IsExclusive:                     snapshot.IsExclusive,
		Status:                          snapshot.Status,
		Hydrated:                        true,
		SubscriptionType:                snapshot.SubscriptionType,
		RateMultiplier:                  snapshot.RateMultiplier,
		DailyLimitUSD:                   snapshot.DailyLimitUSD,
		WeeklyLimitUSD:                  snapshot.WeeklyLimitUSD,
		MonthlyLimitUSD:                 snapshot.MonthlyLimitUSD,
		AllowImageGeneration:            snapshot.AllowImageGeneration,
		OpenAIForceImageTool:            snapshot.OpenAIForceImageTool,
		AllowBatchImageGeneration:       snapshot.AllowBatchImageGeneration,
		ImageCountBilling:               snapshot.ImageCountBilling,
		ImageRateIndependent:            snapshot.ImageRateIndependent,
		ImageRateMultiplier:             snapshot.ImageRateMultiplier,
		ImagePrice1K:                    snapshot.ImagePrice1K,
		ImagePrice2K:                    snapshot.ImagePrice2K,
		ImagePrice4K:                    snapshot.ImagePrice4K,
		VideoRateIndependent:            snapshot.VideoRateIndependent,
		VideoRateMultiplier:             snapshot.VideoRateMultiplier,
		VideoPrice480P:                  snapshot.VideoPrice480P,
		VideoPrice720P:                  snapshot.VideoPrice720P,
		VideoPrice1080P:                 snapshot.VideoPrice1080P,
		WebSearchPricePerCall:           snapshot.WebSearchPricePerCall,
		LongContextPricingEnabled:       snapshot.LongContextPricingEnabled,
		ModelPricing:                    snapshot.ModelPricing,
		ClaudeCodeOnly:                  snapshot.ClaudeCodeOnly,
		IsDistillationGroup:             snapshot.IsDistillationGroup,
		FallbackGroupID:                 snapshot.FallbackGroupID,
		FallbackGroupIDOnInvalidRequest: snapshot.FallbackGroupIDOnInvalidRequest,
		ModelRouting:                    snapshot.ModelRouting,
		ModelRoutingEnabled:             snapshot.ModelRoutingEnabled,
		MCPXMLInject:                    snapshot.MCPXMLInject,
		SupportedModelScopes:            snapshot.SupportedModelScopes,
		AllowMessagesDispatch:           snapshot.AllowMessagesDispatch,
		AllowLive:                       snapshot.AllowLive,
		DefaultMappedModel:              snapshot.DefaultMappedModel,
		MessagesDispatchModelConfig:     snapshot.MessagesDispatchModelConfig,
		ModelsListConfig:                snapshot.ModelsListConfig,
		ModelAllowlist:                  snapshot.ModelAllowlist,
		RPMLimit:                        snapshot.RPMLimit,
		MaxReasoningEffort:              snapshot.MaxReasoningEffort,
		ReasoningEffortMappings:         snapshot.ReasoningEffortMappings,
		PeakRateEnabled:                 snapshot.PeakRateEnabled,
		PeakStart:                       snapshot.PeakStart,
		PeakEnd:                         snapshot.PeakEnd,
		PeakRateMultiplier:              snapshot.PeakRateMultiplier,
		ProfitControlEnabled:            snapshot.ProfitControlEnabled,
		ProfitMinMargin:                 snapshot.ProfitMinMargin,
		ProfitSafetyBuffer:              snapshot.ProfitSafetyBuffer,
	}
	group.compileModelPricingIndex()
	return group
}
