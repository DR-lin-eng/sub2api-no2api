import { createApp, defineComponent, h, reactive, ref } from 'vue'
import { provideSettingsPageContext } from '@/features/admin-settings/presentation/composables/settingsPageContext'
import ImageModeFields from '@/features/admin-settings/presentation/widgets/settings-tabs/SettingsOpenAIImagesModeFields.vue'
import '@/core/themes/style.css'

import zh from '@/core/i18n/locales/zh/admin/settings'
const messages = {admin:zh}
const translate = (key: string) => key.split('.').reduce((value: any, part) => value?.[part], messages) ?? key

createApp(defineComponent({
  setup() {
    const form = reactive({openai_images_legacy_enabled: localStorage.getItem('image-mode-preview') === 'legacy'})
    const saved = ref('')
    provideSettingsPageContext({form,t:translate} as never)
    return () => h('main',{class:'min-h-screen bg-gray-50 p-4 sm:p-8'},[
      h('section',{class:'mx-auto max-w-3xl rounded-xl border border-gray-200 bg-white p-5 sm:p-8 shadow-sm'},[
        h('h1',{class:'mb-6 text-xl font-semibold text-gray-900'},'网关设置 · 生图版本'),
        h(ImageModeFields),
        h('button',{class:'btn btn-primary mt-6',onClick:()=>{localStorage.setItem('image-mode-preview',form.openai_images_legacy_enabled?'legacy':'chatgpt_app');saved.value=form.openai_images_legacy_enabled?'已保存：旧版 Codex 生图':'已保存：新版 ChatGPT App 生图'}},'保存设置'),
        h('p',{'data-testid':'saved-mode',class:'mt-4 text-sm text-gray-600'},saved.value),
      ]),
    ])
  },
})).mount('#app')
