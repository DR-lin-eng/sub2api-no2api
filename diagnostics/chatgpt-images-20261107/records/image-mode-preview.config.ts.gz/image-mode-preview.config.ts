import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({root:'/work/frontend',plugins:[vue()],resolve:{alias:{'@':'/work/frontend/src'}},server:{host:'0.0.0.0',port:4187,strictPort:true}})
