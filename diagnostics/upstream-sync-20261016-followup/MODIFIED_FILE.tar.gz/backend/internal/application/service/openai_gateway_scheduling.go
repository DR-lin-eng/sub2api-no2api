package service

// 本文件由 openai_gateway_service.go 纯移动拆分而来：粘性会话哈希、账号选择与
// 负载感知调度、配额自动暂停判定、并发槽位获取。仅做代码搬迁，无任何行为变更。

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/platform/config"
	"github.com/Wei-Shaw/sub2api/internal/shared/xai"
	"github.com/gin-gonic/gin"
	"github.com/tidwall/gjson"
)

const (
	openCodeSessionAffinityHeader = "X-Session-Affinity"
	openCodeSessionIDHeader       = "X-Session-Id"
	openCodeNativeSessionHeader   = "X-OpenCode-Session"
	codeBuddyConversationHeader   = "X-Conversation-ID"
)

var explicitOpenAIHeaderSessionNames = []string{
	"session-id",
	"session_id",
	"conversation_id",
	claudeCodeSessionHeader,
	openCodeSessionAffinityHeader,
	openCodeSessionIDHeader,
	openCodeNativeSessionHeader,
	codeBuddyConversationHeader,
}

// explicitOpenAIHeaderSessionID resolves stable conversation identifiers sent
// by OpenAI-compatible clients. Keep this list limited to session-scoped
// fields: request/message IDs rotate every turn and would defeat sticky routing
// and upstream prompt caching.
func explicitOpenAIHeaderSessionID(c *gin.Context) string {
	if c == nil {
		return ""
	}

	for _, header := range explicitOpenAIHeaderSessionNames {
		if sessionID := strings.TrimSpace(c.GetHeader(header)); sessionID != "" {
			return sessionID
		}
	}
	return ""
}

// ExtractSessionID extracts the raw session ID from headers or body without hashing.
// Used by ForwardAsAnthropic to pass as prompt_cache_key for upstream cache.
func (s *OpenAIGatewayService) ExtractSessionID(c *gin.Context, body []byte) string {
	return explicitOpenAIRequestSessionID(c, body)
}

func explicitOpenAISessionID(c *gin.Context, body []byte) string {
	if c == nil {
		return ""
	}

	sessionID := explicitOpenAIHeaderSessionID(c)
	if sessionID == "" && len(body) > 0 {
		sessionID = strings.TrimSpace(gjson.GetBytes(body, "prompt_cache_key").String())
	}
	return sessionID
}

// openAIRequestPayloadView unwraps Responses WebSocket event envelopes while
// leaving ordinary HTTP request objects untouched.
func openAIRequestPayloadView(body []byte) gjson.Result {
	root := parseRawJSONView(body)
	eventType := strings.ToLower(strings.TrimSpace(root.Get("type").String()))
	if strings.HasPrefix(eventType, "response.") {
		if response := root.Get("response"); response.Exists() && response.IsObject() {
			return response
		}
	}
	return root
}

// explicitOpenAIRequestSessionID extends the common OpenAI session signals
// with Grok's native conversation header only for requests authenticated to a
// Grok group. This keeps an unrelated x-grok-conv-id header from changing
// scheduling or upstream session behavior for non-Grok groups.
func explicitOpenAIRequestSessionID(c *gin.Context, body []byte) string {
	if c == nil {
		return ""
	}

	sessionID := explicitOpenAIHeaderSessionID(c)
	if sessionID == "" && isGrokRequestContext(c) {
		sessionID = strings.TrimSpace(c.GetHeader(grokConversationIDHeader))
	}
	if sessionID == "" && len(body) > 0 {
		sessionID = strings.TrimSpace(gjson.GetBytes(body, "prompt_cache_key").String())
	}
	return sessionID
}

// GenerateExplicitSessionHash generates a sticky-session hash only from explicit
// client session signals. It intentionally skips content-derived fallback and is
// used by stateless endpoints such as /v1/images.
func (s *OpenAIGatewayService) GenerateExplicitSessionHash(c *gin.Context, body []byte) string {
	sessionID := explicitOpenAIRequestSessionID(c, body)
	if sessionID == "" {
		return ""
	}

	currentHash, legacyHash := deriveOpenAISessionHashes(sessionID)
	attachOpenAILegacySessionHashToGin(c, legacyHash)
	return currentHash
}

// GenerateSessionHash generates a sticky-session hash for OpenAI requests.
//
// Priority:
//  1. Header: session-id / session_id
//  2. Header: conversation_id
//  3. Header: X-Claude-Code-Session-Id
//  4. Header: x-session-affinity / x-session-id / x-opencode-session (OpenCode)
//  5. Header: x-conversation-id (CodeBuddy)
//  6. Header: x-grok-conv-id (Grok groups only)
//  7. Body:   prompt_cache_key
//  8. Body:   Claude metadata session identity
//  9. Body:   content-based fallback (model + system + tools + first user message)
func (s *OpenAIGatewayService) GenerateSessionHash(c *gin.Context, body []byte) string {
	return s.generateSessionHash(c, nil, body, false)
}

// GenerateSessionHashForRequest derives the normal session hash and, when the
// burst-balance setting is enabled, tracks overlapping content-derived requests.
// Callers must pair a non-empty result with ReleaseOpenAIContentSessionRequest.
func (s *OpenAIGatewayService) GenerateSessionHashForRequest(c *gin.Context, groupID *int64, body []byte) string {
	return s.generateSessionHash(c, groupID, body, true)
}

func (s *OpenAIGatewayService) generateSessionHash(c *gin.Context, groupID *int64, body []byte, trackContentRequest bool) string {
	if c == nil {
		return ""
	}

	sessionID := explicitOpenAIRequestSessionID(c, body)
	contentDerived := false
	if sessionID == "" && len(body) > 0 {
		// Claude Code's metadata identity is a real conversation signal. It must
		// win over the content-derived fallback, whose stable-prefix assumptions
		// are not guaranteed for Claude Code's evolving instructions/tool state.
		if metadataSeed := deriveClaudeCodeMetadataSessionSeed(body); metadataSeed != "" {
			sessionID = metadataSeed
		} else {
			sessionID = deriveOpenAIContentSessionSeed(body)
			contentDerived = sessionID != ""
		}
	}
	if sessionID == "" {
		return ""
	}

	currentHash, legacyHash := deriveOpenAISessionHashes(sessionID)
	metadata := openAISessionHashMetadata{
		legacyHash:     legacyHash,
		contentDerived: contentDerived,
	}
	if trackContentRequest && contentDerived && c.Request != nil {
		metadata.contentRequestTracked, metadata.contentRequestConcurrent, metadata.contentRequestOverflow =
			s.beginOpenAIContentSessionRequest(c.Request.Context(), groupID, currentHash)
	}
	attachOpenAISessionHashMetadataToGin(c, metadata)
	return currentHash
}

// GenerateSessionHashWithFallback 先按常规信号生成会话哈希；
// 当未携带 session_id/conversation_id/prompt_cache_key 时，使用 fallbackSeed 生成稳定哈希。
// 该方法用于 WS ingress，避免会话信号缺失时发生跨账号漂移。
func (s *OpenAIGatewayService) GenerateSessionHashWithFallback(c *gin.Context, body []byte, fallbackSeed string) string {
	sessionHash := s.GenerateSessionHash(c, body)
	if sessionHash != "" {
		return sessionHash
	}

	seed := strings.TrimSpace(fallbackSeed)
	if seed == "" {
		return ""
	}

	currentHash, legacyHash := deriveOpenAISessionHashes(seed)
	attachOpenAILegacySessionHashToGin(c, legacyHash)
	return currentHash
}

// GenerateSessionHashWithFallbackForRequest is the request-lifetime tracking
// variant used by the WebSocket ingress handler.
func (s *OpenAIGatewayService) GenerateSessionHashWithFallbackForRequest(
	c *gin.Context,
	groupID *int64,
	body []byte,
	fallbackSeed string,
) string {
	sessionHash := s.GenerateSessionHashForRequest(c, groupID, body)
	if sessionHash != "" {
		return sessionHash
	}
	seed := strings.TrimSpace(fallbackSeed)
	if seed == "" {
		return ""
	}
	currentHash, legacyHash := deriveOpenAISessionHashes(seed)
	attachOpenAILegacySessionHashToGin(c, legacyHash)
	return currentHash
}

func resolveOpenAIUpstreamOriginator(c *gin.Context, isOfficialClient bool) string {
	if c != nil {
		if originator := strings.TrimSpace(c.GetHeader("originator")); originator != "" {
			return originator
		}
	}
	if isOfficialClient {
		return "codex_cli_rs"
	}
	return "opencode"
}

// BindStickySession sets session -> account binding with standard TTL.
func (s *OpenAIGatewayService) BindStickySession(ctx context.Context, groupID *int64, sessionHash string, accountID int64) error {
	if sessionHash == "" || accountID <= 0 {
		return nil
	}
	ttl := openaiStickySessionTTL
	if s != nil && s.cfg != nil && s.cfg.Gateway.OpenAIWS.StickySessionTTLSeconds > 0 {
		ttl = time.Duration(s.cfg.Gateway.OpenAIWS.StickySessionTTLSeconds) * time.Second
	}
	return s.setStickySessionAccountID(ctx, groupID, sessionHash, accountID, ttl)
}

// SelectAccount selects an OpenAI account with sticky session support
func (s *OpenAIGatewayService) SelectAccount(ctx context.Context, groupID *int64, sessionHash string) (*Account, error) {
	return s.SelectAccountForModel(ctx, groupID, sessionHash, "")
}

// SelectAccountForModel selects an account supporting the requested model
func (s *OpenAIGatewayService) SelectAccountForModel(ctx context.Context, groupID *int64, sessionHash string, requestedModel string) (*Account, error) {
	return s.SelectAccountForModelWithExclusions(ctx, groupID, sessionHash, requestedModel, nil)
}

// SelectAccountForModelWithExclusions selects an account supporting the requested model while excluding specified accounts.
// SelectAccountForModelWithExclusions 选择支持指定模型的账号，同时排除指定的账号。
func (s *OpenAIGatewayService) SelectAccountForModelWithExclusions(ctx context.Context, groupID *int64, sessionHash string, requestedModel string, excludedIDs map[int64]struct{}) (*Account, error) {
	ctx = s.withOpenAIRoutingModelContext(ctx, groupID, requestedModel, false)
	return s.selectAccountForModelWithExclusions(s.withOpenAIQuotaAutoPauseContext(ctx), groupID, PlatformOpenAI, sessionHash, requestedModel, excludedIDs, false, 0, "", false)
}

// noAvailableOpenAISelectionError builds the standard "no account available" error
// while preserving the compact-specific error when applicable.
func normalizeOpenAICompatiblePlatform(platform string) string {
	switch platform {
	case PlatformGrok, PlatformKimi, PlatformZhipu, PlatformDeepseek, PlatformMiniMax, PlatformOpenCodeGo:
		return platform
	default:
		return PlatformOpenAI
	}
}

// details carries an optional machine-parseable exclusion summary (e.g.
// "pool=2, filtered: quota_auto_pause_7d=1 runtime_blocked=1") appended in
// parentheses. It is for server-side logs / ops diagnostics only: handlers
// never forward this error text to OpenAI-platform clients (they respond with
// the generic classification message). Callers that must preserve the legacy
// message pass "".
func noAvailableOpenAISelectionError(requestedModel string, compactBlocked bool, details string) error {
	if compactBlocked {
		return ErrNoAvailableCompactAccounts
	}
	message := "no available OpenAI accounts"
	if requestedModel != "" {
		message = fmt.Sprintf("no available OpenAI accounts supporting model: %s", requestedModel)
	}
	if details != "" {
		message += " (" + details + ")"
	}
	return openAINoAvailableSelectionError{message: message}
}

type openAINoAvailableSelectionError struct {
	message string
}

func (e openAINoAvailableSelectionError) Error() string {
	return e.message
}

func (e openAINoAvailableSelectionError) Unwrap() error {
	return ErrNoAvailableAccounts
}

// openAICompactSupportTier classifies an OpenAI-compatible account by compact capability.
// 0 = explicitly unsupported, 1 = unknown / not yet probed, 2 = explicitly supported.
func openAICompactSupportTier(account *Account) int {
	if account == nil {
		return 0
	}
	if account.IsGrok() {
		return 2
	}
	if !account.IsOpenAI() {
		return 0
	}
	supported, known := account.OpenAICompactSupportKnown()
	if !known {
		return 1
	}
	if supported {
		return 2
	}
	return 0
}

// isOpenAICompatibleAccountEligibleForRequest 判断 OpenAI 兼容账号是否满足本次请求的调度条件。
// 检查内容包括：平台匹配、账号可用性、quota 自动暂停、spark 路由限制、模型支持及端点能力。
//
// 注意：对 spark 影子账号，调用方还须额外调用 parentHealthyForShadow(account, lookup)
// 检查母账号凭据可用性；该检查未内置于本函数，以避免注入 DB 依赖。
func isOpenAICompatibleAccountEligibleForRequest(ctx context.Context, account *Account, platform string, requestedModel string, requireCompact bool, requiredCapability OpenAIEndpointCapability) bool {
	platform = normalizeOpenAICompatiblePlatform(platform)
	if account == nil || !codexContinuationSchedulingMatches(ctx, account) || account.Platform != platform || !account.IsOpenAICompatible() || !account.IsSchedulableForModelWithContext(ctx, requestedModel) {
		return false
	}
	if vetoed, _ := profitControlVetoReason(ctx, account); vetoed {
		return false
	}
	if account.IsOpenAI() {
		if paused, reason := shouldAutoPauseOpenAIAccountByQuota(ctx, account); paused {
			// Debug level: this fires per-candidate on the scheduling hot path, so Info
			// would amplify into log spam once several accounts cross the threshold.
			slog.Debug("account_auto_paused_by_quota",
				"account_id", account.ID,
				"window", reason.window,
				"threshold", reason.threshold,
				"utilization", reason.utilization,
			)
			return false
		}
	}
	if account.IsGrok() {
		if paused, reason := shouldAutoPauseGrokAccountByQuota(account); paused {
			slog.Debug("grok_account_auto_paused_by_quota",
				"account_id", account.ID,
				"window", reason.window,
				"threshold", reason.threshold,
				"utilization", reason.utilization,
			)
			return false
		}
	}
	if requestedModel != "" && !supportsOpenAIRequestModel(account, requestedModel, openAIRequestModelForSupport(ctx, requestedModel), requireCompact) {
		return false
	}
	if account.IsGrok() && requiredCapability == OpenAIEndpointCapabilityGrokMediaGeneration {
		eligible, reason := account.GrokMediaGenerationEligibility()
		if !eligible {
			slog.Debug("grok_media_account_ineligible", "account_id", account.ID, "reason", reason)
			return false
		}
	} else if !account.SupportsOpenAIEndpointCapability(requiredCapability) {
		return false
	}
	if requireCompact && openAICompactSupportTier(account) == 0 {
		return false
	}
	return true
}

type openAIQuotaAutoPauseDecision struct {
	window      string
	threshold   float64
	utilization float64
}

func shouldAutoPauseGrokAccountByQuota(account *Account) (bool, openAIQuotaAutoPauseDecision) {
	if account == nil || !account.IsGrok() || account.Type != AccountTypeOAuth {
		return false, openAIQuotaAutoPauseDecision{}
	}
	snapshot, err := grokQuotaSnapshotFromExtra(account.Extra)
	if err != nil || snapshot == nil {
		return false, openAIQuotaAutoPauseDecision{}
	}
	now := time.Now()
	if grokQuotaSnapshotStaleForPause(snapshot, now) {
		return false, openAIQuotaAutoPauseDecision{}
	}
	if grokQuotaRetryAfterActive(snapshot, now) {
		return true, openAIQuotaAutoPauseDecision{window: "retry_after", threshold: 1, utilization: 1}
	}
	if paused, decision := shouldAutoPauseGrokQuotaWindow("requests", snapshot.Requests, now); paused {
		return true, decision
	}
	if paused, decision := shouldAutoPauseGrokQuotaWindow("tokens", snapshot.Tokens, now); paused {
		return true, decision
	}
	return false, openAIQuotaAutoPauseDecision{}
}

func grokQuotaRetryAfterActive(snapshot *xai.QuotaSnapshot, now time.Time) bool {
	if snapshot == nil || snapshot.RetryAfterSeconds == nil || *snapshot.RetryAfterSeconds <= 0 {
		return false
	}
	if strings.TrimSpace(snapshot.UpdatedAt) == "" {
		return true
	}
	updatedAt, err := parseTime(snapshot.UpdatedAt)
	if err != nil {
		return true
	}
	retryAfterUntil := updatedAt.Add(time.Duration(*snapshot.RetryAfterSeconds) * time.Second)
	return now.Before(retryAfterUntil)
}

func shouldAutoPauseGrokQuotaWindow(name string, window *xai.QuotaWindow, now time.Time) (bool, openAIQuotaAutoPauseDecision) {
	if window == nil || window.Limit == nil || window.Remaining == nil || *window.Limit <= 0 {
		return false, openAIQuotaAutoPauseDecision{}
	}
	if window.ResetUnix != nil && *window.ResetUnix > 0 && !now.Before(time.Unix(*window.ResetUnix, 0)) {
		return false, openAIQuotaAutoPauseDecision{}
	}
	utilization := float64(*window.Limit-*window.Remaining) / float64(*window.Limit)
	if *window.Remaining <= 0 || utilization >= 1 {
		return true, openAIQuotaAutoPauseDecision{window: name, threshold: 1, utilization: utilization}
	}
	return false, openAIQuotaAutoPauseDecision{}
}

func grokQuotaSnapshotStaleForPause(snapshot *xai.QuotaSnapshot, now time.Time) bool {
	if snapshot == nil || strings.TrimSpace(snapshot.UpdatedAt) == "" {
		return false
	}
	updatedAt, err := parseTime(snapshot.UpdatedAt)
	if err != nil {
		return false
	}
	return now.Sub(updatedAt) >= openAICodexAutoPauseStaleAfter
}

func shouldAutoPauseOpenAIAccountByQuota(ctx context.Context, account *Account) (bool, openAIQuotaAutoPauseDecision) {
	if account == nil || !account.IsOpenAI() {
		return false, openAIQuotaAutoPauseDecision{}
	}
	// The opt-in Codex prewarm-continuation flow must reach upstream even when
	// the locally cached 5h/7d utilization crosses an auto-pause threshold.
	// Other schedulability checks remain owned by their existing gates.
	if account.IsCodexPrewarmContinuationEnabled() {
		return false, openAIQuotaAutoPauseDecision{}
	}
	// Per-account explicit-disable flags must take precedence over the global default.
	// Without these, leaving the account threshold blank means "use global default",
	// so an admin has no way to exempt a single account from auto-pause once a global
	// default exists. The disable flag is per-window so an account can opt out of
	// only 5h or only 7d auto-pause.
	disabled5h := resolveAccountExtraBool(account.Extra, "auto_pause_5h_disabled")
	disabled7d := resolveAccountExtraBool(account.Extra, "auto_pause_7d_disabled")
	threshold5h, threshold7d := resolveOpenAIQuotaAutoPauseThresholds(ctx, account)
	now := time.Now()
	if !disabled5h && threshold5h > 0 {
		if utilization, ok := resolveOpenAIQuotaUtilization(account.Extra, "5h", now); ok && utilization >= threshold5h {
			return true, openAIQuotaAutoPauseDecision{window: "5h", threshold: threshold5h, utilization: utilization}
		}
	}
	if !disabled7d && threshold7d > 0 {
		if utilization, ok := resolveOpenAIQuotaUtilization(account.Extra, "7d", now); ok && utilization >= threshold7d {
			return true, openAIQuotaAutoPauseDecision{window: "7d", threshold: threshold7d, utilization: utilization}
		}
	}
	return false, openAIQuotaAutoPauseDecision{}
}

// resolveAccountExtraBool reads a bool-like value from account extra, tolerating
// the few shapes JSON unmarshalling may produce (real bool, "true"/"false"
// strings, 0/1 numbers).
func resolveAccountExtraBool(extra map[string]any, key string) bool {
	if len(extra) == 0 {
		return false
	}
	value, ok := extra[key]
	if !ok || value == nil {
		return false
	}
	switch v := value.(type) {
	case bool:
		return v
	case string:
		parsed, err := strconv.ParseBool(strings.TrimSpace(v))
		return err == nil && parsed
	case float64:
		return v != 0
	case float32:
		return v != 0
	case int:
		return v != 0
	case int64:
		return v != 0
	case json.Number:
		if i, err := v.Int64(); err == nil {
			return i != 0
		}
	}
	return false
}

func resolveOpenAIQuotaAutoPauseThresholds(ctx context.Context, account *Account) (float64, float64) {
	threshold5h, _ := resolveAccountExtraNumber(account.Extra, "auto_pause_5h_threshold")
	threshold7d, _ := resolveAccountExtraNumber(account.Extra, "auto_pause_7d_threshold")
	threshold5h = clamp01(threshold5h)
	threshold7d = clamp01(threshold7d)
	if threshold5h > 0 && threshold7d > 0 {
		return threshold5h, threshold7d
	}
	settings := openAIQuotaAutoPauseSettingsFromContext(ctx)
	if threshold5h <= 0 {
		threshold5h = clamp01(settings.DefaultThreshold5h)
	}
	if threshold7d <= 0 {
		threshold7d = clamp01(settings.DefaultThreshold7d)
	}
	return threshold5h, threshold7d
}

func resolveAccountExtraNumber(extra map[string]any, keys ...string) (float64, bool) {
	if len(extra) == 0 {
		return 0, false
	}
	for _, key := range keys {
		value, ok := extra[key]
		if !ok || value == nil {
			continue
		}
		switch v := value.(type) {
		case float64:
			return v, true
		case float32:
			return float64(v), true
		case int:
			return float64(v), true
		case int64:
			return float64(v), true
		case json.Number:
			parsed, err := v.Float64()
			if err == nil {
				return parsed, true
			}
		case string:
			parsed, err := strconv.ParseFloat(strings.TrimSpace(v), 64)
			if err == nil {
				return parsed, true
			}
		}
	}
	return 0, false
}

// resolveOpenAIQuotaUtilization returns the current utilization ratio (0..1) for the
// given Codex usage window. ok=false means there is no usable signal to pause on:
// either no snapshot exists, the window has rolled over, or an old snapshot has
// no known future reset. The stale guard matters because a paused account stops
// receiving requests, so its snapshot is never refreshed from upstream headers —
// without this check an old used_percent would keep the account paused forever even
// after the real window reset.
func resolveOpenAIQuotaUtilization(extra map[string]any, window string, now time.Time) (float64, bool) {
	usedPercent := readOpenAIQuotaUsedPercent(extra, window)
	if usedPercent <= 0 {
		return 0, false
	}
	if openAIQuotaWindowReset(extra, window, now) {
		return 0, false
	}
	// 快照过于陈旧且没有明确的未来重置时间时，不再据此暂停。放行后下一次响应头
	// 会刷新快照实现自愈，避免账号在错误/过期的 used% 上被永久跳过（issue #2994）。
	if openAICodexSnapshotStaleForPause(extra, now) && !openAIQuotaWindowResetPending(extra, window, now) {
		return 0, false
	}
	return usedPercent / 100, true
}

func openAIQuotaWindowResetPending(extra map[string]any, window string, now time.Time) bool {
	resetAt, ok := openAICodexWindowResetAt(extra, window)
	return ok && now.Before(resetAt)
}

// openAICodexSnapshotStaleForPause reports whether the Codex usage snapshot is stale
// enough that it should no longer keep an account auto-paused. It anchors on
// codex_usage_updated_at (always written by buildCodexUsageExtraUpdates). A missing or
// unparseable timestamp returns false (treated as fresh, so the account stays paused) —
// this is deliberate: it prevents any snapshot without a write time from silently escaping
// auto-pause, and a genuinely-exhausted account that is actively served refreshes the
// timestamp on every response so it never crosses the staleness bound.
func openAICodexSnapshotStaleForPause(extra map[string]any, now time.Time) bool {
	if len(extra) == 0 {
		return false
	}
	updatedRaw, ok := extra["codex_usage_updated_at"]
	if !ok {
		return false
	}
	updatedAt, err := parseTime(fmt.Sprint(updatedRaw))
	if err != nil {
		return false
	}
	return now.Sub(updatedAt) >= openAICodexAutoPauseStaleAfter
}

// openAIQuotaWindowReset reports whether the Codex usage window's reset time has
// already passed relative to now. It prefers the absolute codex_<window>_reset_at
// timestamp and falls back to codex_<window>_reset_after_seconds anchored at
// codex_usage_updated_at, mirroring AccountUsageService's window-progress logic.
func openAIQuotaWindowReset(extra map[string]any, window string, now time.Time) bool {
	resetAt, ok := openAICodexWindowResetAt(extra, window)
	return ok && !now.Before(resetAt)
}

// Absolute reset timestamps take precedence. Relative durations are anchored
// to the snapshot sample time so scoring cannot slide the reset into the future.
func openAICodexWindowResetAt(extra map[string]any, window string) (time.Time, bool) {
	if len(extra) == 0 {
		return time.Time{}, false
	}
	if resetAtRaw, ok := extra["codex_"+window+"_reset_at"]; ok {
		if resetAt, err := parseTime(fmt.Sprint(resetAtRaw)); err == nil {
			return resetAt, true
		}
	}
	resetAfter := parseExtraInt(extra["codex_"+window+"_reset_after_seconds"])
	if resetAfter <= 0 {
		return time.Time{}, false
	}
	updatedAt, err := parseTime(fmt.Sprint(extra["codex_usage_updated_at"]))
	if err != nil {
		return time.Time{}, false
	}
	return updatedAt.Add(time.Duration(resetAfter) * time.Second), true
}

func readOpenAIQuotaUsedPercent(extra map[string]any, window string) float64 {
	if len(extra) == 0 {
		return 0
	}
	if value, ok := resolveAccountExtraNumber(extra, "codex_"+window+"_used_percent"); ok {
		return value
	}
	return 0
}

type openAIQuotaAutoPauseCtxKey struct{}

func withOpenAIQuotaAutoPauseSettings(ctx context.Context, settings OpsOpenAIAccountQuotaAutoPauseSettings) context.Context {
	if ctx == nil {
		ctx = context.Background()
	}
	return context.WithValue(ctx, openAIQuotaAutoPauseCtxKey{}, settings)
}

func openAIQuotaAutoPauseSettingsFromContext(ctx context.Context) OpsOpenAIAccountQuotaAutoPauseSettings {
	if ctx == nil {
		return OpsOpenAIAccountQuotaAutoPauseSettings{}
	}
	settings, _ := ctx.Value(openAIQuotaAutoPauseCtxKey{}).(OpsOpenAIAccountQuotaAutoPauseSettings)
	return settings
}

func (s *OpenAIGatewayService) withOpenAIQuotaAutoPauseContext(ctx context.Context) context.Context {
	if s == nil || s.settingService == nil {
		return ctx
	}
	return withOpenAIQuotaAutoPauseSettings(ctx, s.settingService.GetOpenAIQuotaAutoPauseSettings(ctx))
}

// withOpenAIRoutingModelContext resolves a group channel alias before account
// selection. The client-facing model remains the scheduler's requested model;
// the context carries only the model that will be sent upstream so empty-map
// OAuth accounts do not absorb genuinely unknown direct requests.
func (s *OpenAIGatewayService) withOpenAIRoutingModelContext(ctx context.Context, groupID *int64, requestedModel string, requireCompact bool) context.Context {
	if s == nil || groupID == nil || s.channelService == nil || strings.TrimSpace(requestedModel) == "" {
		return ctx
	}
	if existing, ok := openAIForwardModelFromContext(ctx); ok && strings.TrimSpace(existing.model) != "" {
		return ctx
	}
	mapping := s.channelService.ResolveChannelMapping(ctx, *groupID, requestedModel)
	if !mapping.Mapped || strings.TrimSpace(mapping.MappedModel) == "" || strings.TrimSpace(mapping.MappedModel) == strings.TrimSpace(requestedModel) {
		return ctx
	}
	return WithOpenAIForwardModel(ctx, mapping.MappedModel, requireCompact)
}

// prioritizeOpenAICompactAccounts re-orders a slice so that accounts with known
// compact support are tried first, followed by unknown, then explicitly unsupported.
// The relative order within each tier is preserved.
func prioritizeOpenAICompactAccounts(accounts []*Account) []*Account {
	if len(accounts) == 0 {
		return nil
	}
	supported := make([]*Account, 0, len(accounts))
	unknown := make([]*Account, 0, len(accounts))
	unsupported := make([]*Account, 0, len(accounts))
	for _, account := range accounts {
		switch openAICompactSupportTier(account) {
		case 2:
			supported = append(supported, account)
		case 1:
			unknown = append(unknown, account)
		default:
			unsupported = append(unsupported, account)
		}
	}
	out := make([]*Account, 0, len(accounts))
	out = append(out, supported...)
	out = append(out, unknown...)
	out = append(out, unsupported...)
	return out
}

// resolveOpenAIAccountUpstreamModelForRequest mirrors Forward's model chain so
// upstream channel restrictions evaluate the model that will actually be sent.
func resolveOpenAIAccountUpstreamModelForRequest(account *Account, requestedModel string, requireCompact bool) string {
	// Raw Chat Completions fallback runs before passthrough and never applies
	// compact_model_mapping, even if the passthrough flag is also present.
	if shouldForwardOpenAIResponsesViaRawChatCompletions(account) {
		upstreamModel := resolveOpenAIForwardModel(account, requestedModel, "")
		return normalizeOpenAIModelForUpstream(account, upstreamModel)
	}

	// Passthrough preserves the channel-mapped body model. The explicit Codex
	// continuation bundle disables passthrough in Forward, so keep that local
	// invariant here as well.
	if account != nil && account.IsOpenAIPassthroughEnabled() && !account.IsCodexPrewarmContinuationEnabled() {
		upstreamModel := strings.TrimSpace(requestedModel)
		if upstreamModel == "" {
			return ""
		}
		if requireCompact {
			return resolveOpenAICompactForwardModel(account, upstreamModel)
		}
		return upstreamModel
	}

	upstreamModel := resolveOpenAIForwardModel(account, requestedModel, "")
	if upstreamModel == "" {
		return ""
	}
	if requireCompact {
		compactModel := resolveOpenAICompactForwardModel(account, upstreamModel)
		if compactModel != upstreamModel {
			return compactModel
		}
	}
	return normalizeOpenAIModelForUpstream(account, upstreamModel)
}

func (s *OpenAIGatewayService) selectAccountForModelWithExclusions(ctx context.Context, groupID *int64, platform string, sessionHash string, requestedModel string, excludedIDs map[int64]struct{}, requireCompact bool, stickyAccountID int64, requiredCapability OpenAIEndpointCapability, preferLowUpstreamRate bool) (*Account, error) {
	account, _, err := s.selectAccountForModelWithExclusionsAndStreamHealth(ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact, stickyAccountID, requiredCapability, preferLowUpstreamRate)
	return account, err
}

func (s *OpenAIGatewayService) selectAccountForModelWithExclusionsAndStreamHealth(ctx context.Context, groupID *int64, platform string, sessionHash string, requestedModel string, excludedIDs map[int64]struct{}, requireCompact bool, stickyAccountID int64, requiredCapability OpenAIEndpointCapability, preferLowUpstreamRate bool) (*Account, bool, error) {
	ctx = s.withOpenAIRoutingModelContext(ctx, groupID, requestedModel, requireCompact)
	ctx = withSchedulerCandidateExclusions(ctx, excludedIDs)
	platform = normalizeOpenAICompatiblePlatform(platform)
	ctx = s.withOpenAISchedulerCandidateFilter(ctx, groupID, platform, requestedModel, requireCompact, requiredCapability)
	if s.checkChannelPricingRestriction(ctx, groupID, requestedModel) {
		slog.Warn("channel pricing restriction blocked request",
			"group_id", derefGroupID(groupID),
			"model", requestedModel)
		return nil, false, fmt.Errorf("%w supporting model: %s (channel pricing restriction)", ErrNoAvailableAccounts, requestedModel)
	}

	// 1. 尝试粘性会话命中
	// Try sticky session hit
	if account := s.tryStickySessionHit(ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact, stickyAccountID, requiredCapability); account != nil {
		return account, isOpenAIStreamScheduling(ctx), nil
	}

	// 2. 获取可调度的 OpenAI 账号
	// Get schedulable OpenAI accounts
	accounts, err := s.listSchedulableAccounts(ctx, groupID, platform)
	if err != nil {
		return nil, false, fmt.Errorf("query accounts failed: %w", err)
	}

	// 3. 按 compact 能力、上游倍率、优先级、渠道 LRU 和账号 LRU 选择最佳账号
	selected, compactBlocked, hasHealthyStreamAccount := s.selectBestAccount(ctx, groupID, platform, accounts, requestedModel, excludedIDs, requireCompact, requiredCapability, preferLowUpstreamRate)

	if selected == nil {
		return nil, hasHealthyStreamAccount, noAvailableOpenAISelectionError(requestedModel, compactBlocked, "")
	}

	hydrated, err := s.hydrateSelectedAccount(ctx, selected)
	if err != nil {
		return nil, hasHealthyStreamAccount, err
	}

	// 4. 设置粘性会话绑定
	// Set sticky session binding
	if sessionHash != "" && !openAIStickyFailoverPreservationEnabled(ctx) {
		_ = s.setStickySessionAccountID(ctx, groupID, sessionHash, selected.ID, openaiStickySessionTTL)
	}

	return hydrated, hasHealthyStreamAccount, nil
}

// tryStickySessionHit 尝试从粘性会话获取账号。
// 如果命中且账号可用则返回账号；如果账号不可用则清理会话并返回 nil。
//
// tryStickySessionHit attempts to get account from sticky session.
// Returns account if hit and usable; clears session and returns nil if account is unavailable.
func (s *OpenAIGatewayService) tryStickySessionHit(ctx context.Context, groupID *int64, platform string, sessionHash, requestedModel string, excludedIDs map[int64]struct{}, requireCompact bool, stickyAccountID int64, requiredCapability OpenAIEndpointCapability) *Account {
	if sessionHash == "" {
		return nil
	}
	platform = normalizeOpenAICompatiblePlatform(platform)

	accountID := stickyAccountID
	if accountID <= 0 {
		var err error
		accountID, err = s.getStickySessionAccountID(ctx, groupID, sessionHash)
		if err != nil || accountID <= 0 {
			return nil
		}
	}

	if _, excluded := excludedIDs[accountID]; excluded {
		return nil
	}

	account, err := s.getSchedulableAccount(ctx, accountID)
	if err != nil {
		return nil
	}

	// 检查账号是否需要清理粘性会话
	// Check if sticky session should be cleared
	if shouldClearStickySession(account, requestedModel) {
		_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		return nil
	}

	// 验证账号是否可用于当前请求
	// Verify account is usable for current request
	if !isOpenAICompatibleAccountEligibleForRequest(ctx, account, platform, requestedModel, false, requiredCapability) {
		return nil
	}
	if !parentHealthyForShadow(account, s.parentAccountLookup(ctx)) {
		_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		return nil
	}
	if s.isOpenAIAccountRequestRuntimeBlocked(account, requestedModel) {
		_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		return nil
	}
	if isOpenAIStreamScheduling(ctx) {
		if _, degraded := s.openAIStreamCandidateTier(account.ID, time.Now()); degraded {
			return nil
		}
	}
	account = s.recheckSelectedOpenAIAccountFromDB(ctx, account, groupID, platform, requestedModel, requireCompact, requiredCapability)
	if account == nil || !s.openAIAccountMatchesSchedulingGroup(account, groupID) {
		_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		return nil
	}
	if groupID != nil && s.needsUpstreamChannelRestrictionCheck(ctx, groupID) &&
		s.isUpstreamModelRestrictedByChannel(ctx, *groupID, account, requestedModel, requireCompact) {
		_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		return nil
	}

	// 刷新会话 TTL 并返回账号
	// Refresh session TTL and return account
	_ = s.refreshStickySessionTTL(ctx, groupID, sessionHash, openaiStickySessionTTL)
	return account
}

// selectBestAccount 从候选账号中选择最佳账号（compact 能力 + 优先级 + 渠道/账号 LRU）。
// 返回 nil 表示无可用账号。
//
// selectBestAccount selects the best account by compact capability, priority,
// channel LRU, then account LRU.
// Returns nil if no available account. The second return reports whether at
// least one candidate was filtered out solely because it lacks compact support
// (only meaningful when requireCompact=true).
func (s *OpenAIGatewayService) selectBestAccount(ctx context.Context, groupID *int64, platform string, accounts []Account, requestedModel string, excludedIDs map[int64]struct{}, requireCompact bool, requiredCapability OpenAIEndpointCapability, preferLowUpstreamRate bool) (*Account, bool, bool) {
	platform = normalizeOpenAICompatiblePlatform(platform)
	eligible := make([]*Account, 0, len(accounts))
	bestCompactTier := -1
	compactBlocked := false
	needsUpstreamCheck := s.needsUpstreamChannelRestrictionCheck(ctx, groupID)

	for i := range accounts {
		acc := &accounts[i]

		// 跳过被排除的账号
		// Skip excluded accounts
		if _, excluded := excludedIDs[acc.ID]; excluded {
			continue
		}

		fresh := s.resolveFreshSchedulableOpenAIAccount(ctx, acc, platform, requestedModel, false, requiredCapability)
		if fresh == nil {
			continue
		}
		fresh = s.recheckSelectedOpenAIAccountFromDB(ctx, fresh, groupID, platform, requestedModel, false, requiredCapability)
		if fresh == nil {
			continue
		}
		if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, fresh, requestedModel, requireCompact) {
			continue
		}
		compactTier := 0
		if requireCompact {
			compactTier = openAICompactSupportTier(fresh)
			if compactTier == 0 {
				compactBlocked = true
				continue
			}
		}
		if compactTier > bestCompactTier {
			bestCompactTier = compactTier
			eligible = eligible[:0]
		}
		if compactTier == bestCompactTier {
			eligible = append(eligible, fresh)
		}
	}
	if len(eligible) == 0 {
		return nil, compactBlocked, false
	}
	hasHealthyStreamAccount := s.hasHealthyOpenAIStreamAccount(ctx, eligible)
	if isOpenAIStreamScheduling(ctx) {
		now := time.Now()
		bestTier, _ := s.openAIStreamCandidateTier(eligible[0].ID, now)
		for _, account := range eligible[1:] {
			if tier, _ := s.openAIStreamCandidateTier(account.ID, now); tier < bestTier {
				bestTier = tier
			}
		}
		tierCandidates := eligible[:0]
		for _, account := range eligible {
			if tier, _ := s.openAIStreamCandidateTier(account.ID, now); tier == bestTier {
				tierCandidates = append(tierCandidates, account)
			}
		}
		eligible = tierCandidates
	}

	rateOrder := openAILegacyUpstreamRateOrder{}
	if preferLowUpstreamRate {
		rateOrder = newOpenAILegacyUpstreamRateOrder(eligible, time.Now(), s.openAIOAuthSchedulingRateMultiplier(ctx))
	}
	if rateOrder.enabled {
		bestRate := eligible[0]
		for _, account := range eligible[1:] {
			if rateOrder.compare(account, bestRate) < 0 {
				bestRate = account
			}
		}
		rateCandidates := eligible[:0]
		for _, account := range eligible {
			if rateOrder.compare(account, bestRate) == 0 {
				rateCandidates = append(rateCandidates, account)
			}
		}
		eligible = rateCandidates
	}

	minPriority := eligible[0].Priority
	for _, account := range eligible[1:] {
		if account.Priority < minPriority {
			minPriority = account.Priority
		}
	}
	priorityCandidates := eligible[:0]
	for _, account := range eligible {
		if account.Priority == minPriority {
			priorityCandidates = append(priorityCandidates, account)
		}
	}
	return selectOpenAIAccountByChannelLRU(priorityCandidates), compactBlocked, hasHealthyStreamAccount
}

// SelectAccountWithLoadAwareness selects an account with load-awareness and wait plan.
func (s *OpenAIGatewayService) SelectAccountWithLoadAwareness(ctx context.Context, groupID *int64, sessionHash string, requestedModel string, excludedIDs map[int64]struct{}) (*AccountSelectionResult, error) {
	candidates, routed := apiKeyGroupRoutingCandidates(ctx, groupID)
	if !routed {
		return s.selectAccountWithLoadAwareness(s.withOpenAIQuotaAutoPauseContext(ctx), groupID, PlatformOpenAI, sessionHash, requestedModel, excludedIDs, false, "", true, false)
	}
	lastErr := ErrNoAvailableAccounts
	for i := range candidates {
		candidateID := candidates[i].GroupID
		selection, err := s.selectAccountWithLoadAwareness(
			s.withOpenAIQuotaAutoPauseContext(withAPIKeyGroupRoutingAttempt(ctx, candidates[i])),
			&candidateID,
			PlatformOpenAI,
			sessionHash,
			requestedModel,
			excludedIDs,
			false,
			"",
			true,
			false,
		)
		if err == nil && selection != nil && selection.Account != nil {
			markAPIKeyGroupRoutingSelected(ctx, candidateID)
			return selection, nil
		}
		if err != nil {
			lastErr = err
			if !errors.Is(err, ErrNoAvailableAccounts) && !errors.Is(err, ErrNoAvailableCompactAccounts) {
				return nil, err
			}
		}
	}
	return nil, lastErr
}

func (s *OpenAIGatewayService) selectLegacyStickyAccountBeforePoolScan(
	ctx context.Context,
	groupID *int64,
	platform string,
	sessionHash string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requireCompact bool,
	requiredCapability OpenAIEndpointCapability,
	requiredImageCapability OpenAIImagesCapability,
	requiredTransport OpenAIUpstreamTransport,
	accountID int64,
	needsUpstreamCheck bool,
	cfg config.GatewaySchedulingConfig,
	forceSticky bool,
	preserveStickyBinding bool,
) (*AccountSelectionResult, bool, bool, error) {
	if accountID <= 0 || s.concurrencyService == nil {
		return nil, false, false, nil
	}
	if _, excluded := excludedIDs[accountID]; excluded {
		return nil, false, false, nil
	}
	account, err := s.getSchedulableAccount(ctx, accountID)
	if err != nil {
		return nil, false, false, nil
	}
	if account == nil {
		if !preserveStickyBinding {
			_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		}
		return nil, false, true, nil
	}
	if shouldClearStickySession(account, requestedModel) || !isOpenAICompatibleAccountEligibleForRequest(ctx, account, platform, requestedModel, false, requiredCapability) {
		if !preserveStickyBinding {
			_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		}
		return nil, false, true, nil
	}
	if !accountSupportsOpenAICapabilities(account, requiredCapability, requiredImageCapability) ||
		!s.isOpenAIAccountTransportCompatible(account, requiredTransport) {
		return nil, false, false, nil
	}
	account = s.recheckSelectedOpenAIAccountFromDB(ctx, account, groupID, platform, requestedModel, requireCompact, requiredCapability)
	if account == nil || !s.openAIAccountMatchesSchedulingGroup(account, groupID) || s.isOpenAIAccountRequestRuntimeBlocked(account, requestedModel) {
		if !preserveStickyBinding {
			_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		}
		return nil, false, true, nil
	}
	if !accountSupportsOpenAICapabilities(account, requiredCapability, requiredImageCapability) ||
		!s.isOpenAIAccountTransportCompatible(account, requiredTransport) {
		return nil, false, false, nil
	}
	if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, account, requestedModel, requireCompact) {
		if !preserveStickyBinding {
			_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		}
		return nil, false, true, nil
	}
	if !parentHealthyForShadow(account, s.parentAccountLookup(ctx)) {
		if !preserveStickyBinding {
			_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
		}
		return nil, false, true, nil
	}
	if _, degraded := s.openAIStreamCandidateTier(account.ID, time.Now()); isOpenAIStreamScheduling(ctx) && degraded {
		return nil, false, false, nil
	}

	result, acquireErr := s.tryAcquireAccountSlot(ctx, accountID, account.Concurrency)
	if errors.Is(acquireErr, ErrPriorityAdmissionUnavailable) {
		return nil, false, false, acquireErr
	}
	if acquireErr == nil && result != nil && result.Acquired {
		selection, selectErr := s.newAcquiredSelectionResult(ctx, account, result.ReleaseFunc)
		if selectErr != nil {
			return nil, false, false, selectErr
		}
		if !preserveStickyBinding {
			_ = s.refreshStickySessionTTL(ctx, groupID, sessionHash, openaiStickySessionTTL)
		}
		return selection, true, false, nil
	}
	if !forceSticky {
		waitingCount, _ := s.concurrencyService.GetAccountWaitingCount(ctx, accountID)
		if waitingCount >= cfg.StickySessionMaxWaiting {
			return nil, false, false, nil
		}
	}
	selection, selectErr := s.newSelectionResult(ctx, account, false, nil, &AccountWaitPlan{
		AccountID:      accountID,
		MaxConcurrency: account.Concurrency,
		Timeout:        cfg.StickySessionWaitTimeout,
		MaxWaiting:     cfg.StickySessionMaxWaiting,
	})
	return selection, true, false, selectErr
}

// selectOpenAIContentSessionBurstCandidates continues high-concurrency content
// spreading without returning to a full account-pool scan. Candidates were
// previously selected through the normal scheduler and are still validated for
// this exact request before their slot is acquired.
func (s *OpenAIGatewayService) selectOpenAIContentSessionBurstCandidates(
	ctx context.Context,
	groupID *int64,
	platform string,
	sessionHash string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requireCompact bool,
	requiredTransport OpenAIUpstreamTransport,
	requiredCapability OpenAIEndpointCapability,
	requiredImageCapability OpenAIImagesCapability,
) (*AccountSelectionResult, error) {
	candidates, count := s.nextOpenAIContentSessionBurstCandidates(ctx, groupID, sessionHash)
	if count == 0 {
		return nil, nil
	}

	cfg := s.schedulingConfig()
	needsUpstreamCheck := s.needsUpstreamChannelRestrictionCheck(ctx, groupID)
	var waitSelection *AccountSelectionResult
	for i := 0; i < count; i++ {
		selection, handled, invalidated, selectErr := s.selectLegacyStickyAccountBeforePoolScan(
			ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact,
			requiredCapability, requiredImageCapability, requiredTransport, candidates[i], needsUpstreamCheck, cfg, true, true,
		)
		if selectErr != nil {
			return nil, selectErr
		}
		if invalidated {
			s.dropOpenAIContentSessionCandidate(ctx, groupID, sessionHash, candidates[i])
		}
		if !handled || selection == nil || selection.Account == nil {
			continue
		}
		if selection.Acquired {
			return selection, nil
		}
		if waitSelection == nil {
			waitSelection = selection
		}
	}
	return waitSelection, nil
}

func (s *OpenAIGatewayService) selectAccountWithLoadAwareness(ctx context.Context, groupID *int64, platform string, sessionHash string, requestedModel string, excludedIDs map[int64]struct{}, requireCompact bool, requiredCapability OpenAIEndpointCapability, useUpstreamTokenCost bool, contentSessionConcurrent bool) (*AccountSelectionResult, error) {
	ctx = s.withOpenAIRoutingModelContext(ctx, groupID, requestedModel, requireCompact)
	ctx = withSchedulerCandidateExclusions(ctx, excludedIDs)
	platform = normalizeOpenAICompatiblePlatform(platform)
	if s.checkChannelPricingRestriction(ctx, groupID, requestedModel) {
		slog.Warn("channel pricing restriction blocked request",
			"group_id", derefGroupID(groupID),
			"model", requestedModel)
		return nil, fmt.Errorf("%w supporting model: %s (channel pricing restriction)", ErrNoAvailableAccounts, requestedModel)
	}

	cfg := s.schedulingConfig()
	preserveStickyBinding := openAIStickyFailoverPreservationEnabled(ctx)
	preferLowUpstreamRate := useUpstreamTokenCost && s.isOpenAILowUpstreamRatePriorityEnabled(ctx)
	needsUpstreamCheck := s.needsUpstreamChannelRestrictionCheck(ctx, groupID)
	var stickyAccountID int64
	if sessionHash != "" && s.cache != nil {
		if accountID, err := s.getStickySessionAccountID(ctx, groupID, sessionHash); err == nil {
			stickyAccountID = accountID
		}
	}
	contentSessionOverflow := openAIContentSessionRequestOverflow(ctx)
	if !contentSessionConcurrent && sessionHash != "" {
		selection, handled, invalidated, stickyErr := s.selectLegacyStickyAccountBeforePoolScan(
			ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact,
			requiredCapability, "", OpenAIUpstreamTransportAny, stickyAccountID, needsUpstreamCheck, cfg, contentSessionOverflow || preserveStickyBinding, false,
		)
		if stickyErr != nil {
			return nil, stickyErr
		}
		if handled {
			return selection, nil
		}
		if invalidated {
			stickyAccountID = 0
		}
	}
	if openAIContentSessionRequestTracked(ctx) {
		releaseLoadBalance, acquireErr := s.acquireOpenAIContentSessionLoadBalance(ctx)
		if acquireErr != nil {
			return nil, acquireErr
		}
		defer releaseLoadBalance()

		// The sticky binding can be created while an overflow request waits. Check
		// again after admission before falling through to a full candidate scan.
		if contentSessionOverflow && sessionHash != "" {
			refreshedStickyID, stickyErr := s.getStickySessionAccountID(ctx, groupID, sessionHash)
			if stickyErr == nil && refreshedStickyID > 0 {
				selection, handled, invalidated, stickyErr := s.selectLegacyStickyAccountBeforePoolScan(
					ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact,
					requiredCapability, "", OpenAIUpstreamTransportAny, refreshedStickyID, needsUpstreamCheck, cfg, true, false,
				)
				if stickyErr != nil {
					return nil, stickyErr
				}
				if handled {
					return selection, nil
				}
				if invalidated {
					stickyAccountID = 0
				}
			}
		}
	}
	if s.concurrencyService == nil || !cfg.LoadBatchEnabled {
		account, hasHealthyStreamAccount, err := s.selectAccountForModelWithExclusionsAndStreamHealth(ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact, stickyAccountID, requiredCapability, preferLowUpstreamRate)
		if err != nil {
			return nil, err
		}
		result, err := s.tryAcquireOpenAIStreamAwareAccountSlot(ctx, account, hasHealthyStreamAccount)
		if errors.Is(err, ErrPriorityAdmissionUnavailable) {
			return nil, err
		}
		if err == nil && result == nil && hasHealthyStreamAccount && isOpenAIStreamScheduling(ctx) {
			// A concurrent request may have claimed the due recovery probe after
			// selection. Re-select once so this request falls back to a healthy
			// account instead of following the stale degraded ordering.
			account, hasHealthyStreamAccount, err = s.selectAccountForModelWithExclusionsAndStreamHealth(ctx, groupID, platform, sessionHash, requestedModel, excludedIDs, requireCompact, stickyAccountID, requiredCapability, preferLowUpstreamRate)
			if err != nil {
				return nil, err
			}
			result, err = s.tryAcquireOpenAIStreamAwareAccountSlot(ctx, account, hasHealthyStreamAccount)
			if errors.Is(err, ErrPriorityAdmissionUnavailable) {
				return nil, err
			}
		}
		if err == nil && result != nil && result.Acquired {
			return s.newAcquiredSelectionResult(ctx, account, result.ReleaseFunc)
		}
		if stickyAccountID > 0 && stickyAccountID == account.ID && s.concurrencyService != nil {
			waitingCount, _ := s.concurrencyService.GetAccountWaitingCount(ctx, account.ID)
			if waitingCount < cfg.StickySessionMaxWaiting {
				return s.newSelectionResult(ctx, account, false, nil, &AccountWaitPlan{
					AccountID:      account.ID,
					MaxConcurrency: account.Concurrency,
					Timeout:        cfg.StickySessionWaitTimeout,
					MaxWaiting:     cfg.StickySessionMaxWaiting,
				})
			}
		}
		return s.newSelectionResult(ctx, account, false, nil, &AccountWaitPlan{
			AccountID:      account.ID,
			MaxConcurrency: account.Concurrency,
			Timeout:        cfg.FallbackWaitTimeout,
			MaxWaiting:     cfg.FallbackMaxWaiting,
		})
	}

	ctx = s.withOpenAISchedulerCandidateFilter(ctx, groupID, platform, requestedModel, requireCompact, requiredCapability)
	accounts, err := s.listSchedulableAccounts(ctx, groupID, platform)
	if err != nil {
		return nil, err
	}
	if len(accounts) == 0 {
		return nil, ErrNoAvailableAccounts
	}

	isExcluded := func(accountID int64) bool {
		if excludedIDs == nil {
			return false
		}
		_, excluded := excludedIDs[accountID]
		return excluded
	}

	// ============ Layer 1: Sticky session ============
	// A healthy sticky account whose bounded wait queue is full may spill one
	// request into Layer 2. Keep that spillover temporary so a short burst does
	// not migrate the conversation to a cache-cold account.
	stickyCapacitySpillover := false
	if sessionHash != "" && !contentSessionConcurrent {
		accountID := stickyAccountID
		if accountID > 0 && !isExcluded(accountID) {
			account, err := s.getSchedulableAccount(ctx, accountID)
			if err == nil {
				clearSticky := shouldClearStickySession(account, requestedModel)
				if clearSticky {
					_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
				}
				if !clearSticky && isOpenAICompatibleAccountEligibleForRequest(ctx, account, platform, requestedModel, false, requiredCapability) {
					account = s.recheckSelectedOpenAIAccountFromDB(ctx, account, groupID, platform, requestedModel, requireCompact, requiredCapability)
					if account == nil {
						_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
					} else if !s.openAIAccountMatchesSchedulingGroup(account, groupID) {
						_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
					} else if s.isOpenAIAccountRequestRuntimeBlocked(account, requestedModel) {
						_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
					} else if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, account, requestedModel, requireCompact) {
						_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
					} else if !parentHealthyForShadow(account, s.parentAccountLookup(ctx)) {
						_ = s.deleteStickySessionAccountID(ctx, groupID, sessionHash)
					} else if _, degraded := s.openAIStreamCandidateTier(account.ID, time.Now()); isOpenAIStreamScheduling(ctx) && degraded {
						// Let load balancing decide whether this degraded sticky account is
						// due for a recovery probe or needed as the only fallback.
					} else {
						result, err := s.tryAcquireAccountSlot(ctx, accountID, account.Concurrency)
						if errors.Is(err, ErrPriorityAdmissionUnavailable) {
							return nil, err
						}
						if err == nil && result != nil && result.Acquired {
							selection, selectErr := s.newAcquiredSelectionResult(ctx, account, result.ReleaseFunc)
							if selectErr != nil {
								return nil, selectErr
							}
							_ = s.refreshStickySessionTTL(ctx, groupID, sessionHash, openaiStickySessionTTL)
							return selection, nil
						}

						waitingCount, _ := s.concurrencyService.GetAccountWaitingCount(ctx, accountID)
						if waitingCount < cfg.StickySessionMaxWaiting {
							return s.newSelectionResult(ctx, account, false, nil, &AccountWaitPlan{
								AccountID:      accountID,
								MaxConcurrency: account.Concurrency,
								Timeout:        cfg.StickySessionWaitTimeout,
								MaxWaiting:     cfg.StickySessionMaxWaiting,
							})
						}
						stickyCapacitySpillover = true
					}
				}
			}
		}
	}

	// ============ Layer 2: Load-aware selection ============
	// Per-pass parent-health cache to avoid repeated DB calls when multiple shadow
	// accounts share the same parent.
	parentCacheL2 := make(map[int64]*Account)
	parentLookupL2 := func(id int64) *Account {
		if a, ok := parentCacheL2[id]; ok {
			return a
		}
		if s.accountRepo == nil {
			return nil
		}
		a, _ := s.accountRepo.GetByID(ctx, id)
		parentCacheL2[id] = a
		return a
	}
	baseCandidateCount := 0
	candidates := make([]*Account, 0, len(accounts))
	for i := range accounts {
		acc := &accounts[i]
		if isExcluded(acc.ID) {
			continue
		}
		// Scheduler snapshots can be temporarily stale (bucket rebuild is throttled);
		// re-check schedulability here so recently rate-limited/overloaded accounts
		// are not selected again before the bucket is rebuilt.
		if !isOpenAICompatibleAccountEligibleForRequest(ctx, acc, platform, requestedModel, false, requiredCapability) {
			continue
		}
		if !parentHealthyForShadow(acc, parentLookupL2) {
			continue
		}
		if s.isOpenAIAccountRequestRuntimeBlocked(acc, requestedModel) {
			continue
		}
		if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, acc, requestedModel, requireCompact) {
			continue
		}
		baseCandidateCount++
		candidates = append(candidates, acc)
	}

	if len(candidates) == 0 {
		return nil, ErrNoAvailableAccounts
	}
	hasHealthyStreamAccount := s.hasHealthyOpenAIStreamAccount(ctx, candidates)
	rateOrder := openAILegacyUpstreamRateOrder{}
	if preferLowUpstreamRate {
		rateOrder = newOpenAILegacyUpstreamRateOrder(candidates, time.Now(), s.openAIOAuthSchedulingRateMultiplier(ctx))
	}

	accountLoads := make([]AccountWithConcurrency, 0, len(candidates))
	for _, acc := range candidates {
		accountLoads = append(accountLoads, AccountWithConcurrency{
			ID:             acc.ID,
			MaxConcurrency: acc.EffectiveLoadFactor(),
		})
	}

	tryAcquireFromLoadMap := func(loadMap map[int64]*AccountLoadInfo) (*AccountSelectionResult, bool, error) {
		var available []accountWithLoad
		for _, acc := range candidates {
			loadInfo := loadMap[acc.ID]
			if loadInfo == nil {
				loadInfo = &AccountLoadInfo{AccountID: acc.ID}
			}
			if loadInfo.LoadRate < 100 {
				available = append(available, accountWithLoad{
					account:  acc,
					loadInfo: loadInfo,
				})
			}
		}

		if len(available) == 0 {
			// The snapshot may be stale and report every account at capacity.
			// Mark the pass as attempted so the caller performs one uncached
			// Redis read before falling back to a wait plan. Without this, a
			// transiently full snapshot could pin the request to an arbitrary
			// account while another OAuth account is already idle.
			return nil, true, nil
		}

		sort.SliceStable(available, func(i, j int) bool {
			a, b := available[i], available[j]
			if a.account.Priority != b.account.Priority {
				return a.account.Priority < b.account.Priority
			}
			if a.loadInfo.LoadRate != b.loadInfo.LoadRate {
				return a.loadInfo.LoadRate < b.loadInfo.LoadRate
			}
			switch {
			case a.account.LastUsedAt == nil && b.account.LastUsedAt != nil:
				return true
			case a.account.LastUsedAt != nil && b.account.LastUsedAt == nil:
				return false
			case a.account.LastUsedAt == nil && b.account.LastUsedAt == nil:
				return false
			default:
				return a.account.LastUsedAt.Before(*b.account.LastUsedAt)
			}
		})
		shuffleWithinSortGroups(available)
		available = interleaveOpenAIAPIKeyChannelsByLoad(available)
		if rateOrder.enabled {
			sort.SliceStable(available, func(i, j int) bool {
				return rateOrder.compare(available[i].account, available[j].account) < 0
			})
		}

		selectionOrder := make([]accountWithLoad, 0, len(available))
		if requireCompact {
			appendTier := func(out []accountWithLoad, tier int) []accountWithLoad {
				for _, item := range available {
					if openAICompactSupportTier(item.account) == tier {
						out = append(out, item)
					}
				}
				return out
			}
			selectionOrder = appendTier(selectionOrder, 2)
			selectionOrder = appendTier(selectionOrder, 1)
			// tier 0 候选作为兜底追加：DB recheck 时若发现 cache tier 0 实际
			// 已升级为 1/2（探测刚跑完，cache 尚未刷新），仍可正常命中。
			selectionOrder = appendTier(selectionOrder, 0)
		} else {
			selectionOrder = append(selectionOrder, available...)
		}
		if isOpenAIStreamScheduling(ctx) {
			now := time.Now()
			sort.SliceStable(selectionOrder, func(i, j int) bool {
				left, _ := s.openAIStreamCandidateTier(selectionOrder[i].account.ID, now)
				right, _ := s.openAIStreamCandidateTier(selectionOrder[j].account.ID, now)
				return left < right
			})
		}

		for _, item := range selectionOrder {
			fresh := s.resolveFreshSchedulableOpenAIAccount(ctx, item.account, platform, requestedModel, false, requiredCapability)
			if fresh == nil {
				continue
			}
			fresh = s.recheckSelectedOpenAIAccountFromDB(ctx, fresh, groupID, platform, requestedModel, requireCompact, requiredCapability)
			if fresh == nil {
				continue
			}
			if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, fresh, requestedModel, requireCompact) {
				continue
			}
			result, err := s.tryAcquireOpenAIStreamAwareAccountSlot(ctx, fresh, hasHealthyStreamAccount)
			if errors.Is(err, ErrPriorityAdmissionUnavailable) {
				return nil, true, err
			}
			if err == nil && result != nil && result.Acquired {
				selection, selectErr := s.newAcquiredSelectionResult(ctx, fresh, result.ReleaseFunc)
				if selectErr != nil {
					return nil, true, selectErr
				}
				if sessionHash != "" && !contentSessionConcurrent && !preserveStickyBinding && !stickyCapacitySpillover {
					_ = s.setStickySessionAccountID(ctx, groupID, sessionHash, fresh.ID, openaiStickySessionTTL)
				}
				return selection, true, nil
			}
			if result != nil && result.PriorityAdmissionTerminal {
				return priorityAdmissionTerminalSelection(fresh, cfg.FallbackWaitTimeout, cfg.FallbackMaxWaiting), true, nil
			}
		}
		return nil, true, nil
	}

	loadMap, err := s.concurrencyService.GetAccountsLoadBatch(ctx, accountLoads)
	if err != nil {
		ordered := append([]*Account(nil), candidates...)
		sortAccountsByPriorityAndLastUsed(ordered, false)
		ordered = interleaveOpenAIAPIKeyChannels(ordered)
		if rateOrder.enabled {
			sort.SliceStable(ordered, func(i, j int) bool {
				return rateOrder.compare(ordered[i], ordered[j]) < 0
			})
		}
		if requireCompact {
			ordered = prioritizeOpenAICompactAccounts(ordered)
		}
		s.sortOpenAIStreamAccounts(ctx, ordered)
		for _, acc := range ordered {
			fresh := s.resolveFreshSchedulableOpenAIAccount(ctx, acc, platform, requestedModel, false, requiredCapability)
			if fresh == nil {
				continue
			}
			fresh = s.recheckSelectedOpenAIAccountFromDB(ctx, fresh, groupID, platform, requestedModel, requireCompact, requiredCapability)
			if fresh == nil {
				continue
			}
			if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, fresh, requestedModel, requireCompact) {
				continue
			}
			result, err := s.tryAcquireOpenAIStreamAwareAccountSlot(ctx, fresh, hasHealthyStreamAccount)
			if errors.Is(err, ErrPriorityAdmissionUnavailable) {
				return nil, err
			}
			if err == nil && result != nil && result.Acquired {
				selection, selectErr := s.newAcquiredSelectionResult(ctx, fresh, result.ReleaseFunc)
				if selectErr != nil {
					return nil, selectErr
				}
				if sessionHash != "" && !contentSessionConcurrent && !preserveStickyBinding && !stickyCapacitySpillover {
					_ = s.setStickySessionAccountID(ctx, groupID, sessionHash, fresh.ID, openaiStickySessionTTL)
				}
				return selection, nil
			}
			if result != nil && result.PriorityAdmissionTerminal {
				return priorityAdmissionTerminalSelection(fresh, cfg.FallbackWaitTimeout, cfg.FallbackMaxWaiting), nil
			}
		}
	} else {
		if selection, attempted, selectErr := tryAcquireFromLoadMap(loadMap); selectErr != nil {
			return nil, selectErr
		} else if selection != nil {
			return selection, nil
		} else if attempted {
			if freshLoadMap, loadErr := s.concurrencyService.GetAccountsLoadBatchFresh(ctx, accountLoads); loadErr == nil {
				if selection, _, selectErr := tryAcquireFromLoadMap(freshLoadMap); selectErr != nil {
					return nil, selectErr
				} else if selection != nil {
					return selection, nil
				}
			}
		}
	}

	// ============ Layer 3: Fallback wait ============
	sortAccountsByPriorityAndLastUsed(candidates, false)
	candidates = interleaveOpenAIAPIKeyChannels(candidates)
	if rateOrder.enabled {
		sort.SliceStable(candidates, func(i, j int) bool {
			return rateOrder.compare(candidates[i], candidates[j]) < 0
		})
	}
	if requireCompact {
		candidates = prioritizeOpenAICompactAccounts(candidates)
	}
	s.sortOpenAIStreamAccounts(ctx, candidates)
	for _, acc := range candidates {
		if s.shouldSkipOpenAIStreamWait(ctx, acc.ID, hasHealthyStreamAccount) {
			continue
		}
		fresh := s.resolveFreshSchedulableOpenAIAccount(ctx, acc, platform, requestedModel, false, requiredCapability)
		if fresh == nil {
			continue
		}
		fresh = s.recheckSelectedOpenAIAccountFromDB(ctx, fresh, groupID, platform, requestedModel, requireCompact, requiredCapability)
		if fresh == nil {
			continue
		}
		if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(ctx, *groupID, fresh, requestedModel, requireCompact) {
			continue
		}
		return s.newSelectionResult(ctx, fresh, false, nil, &AccountWaitPlan{
			AccountID:      fresh.ID,
			MaxConcurrency: fresh.Concurrency,
			Timeout:        cfg.FallbackWaitTimeout,
			MaxWaiting:     cfg.FallbackMaxWaiting,
		})
	}

	if requireCompact && baseCandidateCount > 0 {
		return nil, ErrNoAvailableCompactAccounts
	}
	return nil, ErrNoAvailableAccounts
}

func (s *OpenAIGatewayService) listSchedulableAccounts(ctx context.Context, groupID *int64, platform string) ([]Account, error) {
	platform = normalizeOpenAICompatiblePlatform(platform)
	if s.schedulerSnapshot != nil {
		accounts, _, err := s.schedulerSnapshot.ListSchedulableAccounts(ctx, groupID, platform, false)
		if err != nil {
			return nil, err
		}
		return s.concurrencyService.applyCPAPoolCapacityBatch(ctx, accounts), nil
	}
	var accounts []Account
	var err error
	if s.cfg != nil && s.cfg.RunMode == config.RunModeSimple {
		accounts, err = s.accountRepo.ListSchedulableByPlatform(ctx, platform)
	} else if groupID != nil {
		accounts, err = s.accountRepo.ListSchedulableByGroupIDAndPlatform(ctx, *groupID, platform)
	} else {
		accounts, err = s.accountRepo.ListSchedulableUngroupedByPlatform(ctx, platform)
	}
	if err != nil {
		return nil, fmt.Errorf("query accounts failed: %w", err)
	}
	return s.concurrencyService.applyCPAPoolCapacityBatch(ctx, accounts), nil
}

func (s *OpenAIGatewayService) withOpenAISchedulerCandidateFilter(ctx context.Context, groupID *int64, platform, requestedModel string, requireCompact bool, requiredCapability OpenAIEndpointCapability) context.Context {
	ctx = s.withOpenAIRoutingModelContext(ctx, groupID, requestedModel, requireCompact)
	requestCtx := ctx
	parentLookup := s.parentAccountLookup(requestCtx)
	needsUpstreamCheck := groupID != nil && s.needsUpstreamChannelRestrictionCheck(requestCtx, groupID)
	return withSchedulerCandidatePredicate(ctx, func(account *Account) bool {
		if !s.codexContinuationCandidateMatches(requestCtx, account) ||
			!isOpenAICompatibleAccountEligibleForRequest(withoutCodexContinuationSchedulingAffinity(requestCtx), account, platform, requestedModel, false, requiredCapability) ||
			!openAIStickyAccountMatchesGroup(account, groupID) ||
			s.isOpenAIAccountRuntimeBlocked(account) ||
			!parentHealthyForShadow(account, parentLookup) {
			return false
		}
		if requireCompact && resolveOpenAIAccountUpstreamModelForRequest(account, requestedModel, true) == "" {
			return false
		}
		if needsUpstreamCheck && s.isUpstreamModelRestrictedByChannel(requestCtx, *groupID, account, requestedModel, requireCompact) {
			return false
		}
		return true
	})
}

func (s *OpenAIGatewayService) tryAcquireAccountSlot(ctx context.Context, accountID int64, maxConcurrency int) (*AcquireResult, error) {
	if s.concurrencyService == nil {
		return &AcquireResult{Acquired: true, ReleaseFunc: func() {}}, nil
	}
	if tier, ok := RequestSchedulingTierFromContextOK(ctx); ok && s.concurrencyService.PriorityAdmissionEnabledForRequest(ctx) {
		return s.concurrencyService.AcquireAccountSlotForTier(ctx, accountID, maxConcurrency, tier)
	}
	return s.concurrencyService.AcquireAccountSlot(ctx, accountID, maxConcurrency)
}

func (s *OpenAIGatewayService) resolveFreshSchedulableOpenAIAccount(ctx context.Context, account *Account, platform string, requestedModel string, requireCompact bool, requiredCapability OpenAIEndpointCapability) *Account {
	if account == nil {
		return nil
	}
	platform = normalizeOpenAICompatiblePlatform(platform)

	fresh := account
	if s.schedulerSnapshot != nil {
		current, err := s.getSchedulableAccount(ctx, account.ID)
		if err != nil || current == nil {
			return nil
		}
		fresh = current
	}

	if !isOpenAICompatibleAccountEligibleForRequest(ctx, fresh, platform, requestedModel, requireCompact, requiredCapability) {
		return nil
	}
	if !parentHealthyForShadow(fresh, s.parentAccountLookup(ctx)) {
		return nil
	}
	if s.isOpenAIAccountRequestRuntimeBlocked(fresh, requestedModel) {
		return nil
	}
	if s.isOpenAIProxyStreamQuarantined(ctx, fresh) {
		return nil
	}
	capped, available := s.concurrencyService.applyCPAPoolCapacity(ctx, fresh)
	if !available {
		return nil
	}
	return capped
}

// parentAccountLookup 返回供 parentHealthyForShadow 使用的母账号解析闭包:经 accountRepo
// 按 ID 取当前 Account(repo 为空时 fail-closed 返回 nil)。统一调度/粘连各路径的母账号解析,
// 取代各调用点重复内联的同一闭包(历史上 recheck 等路径还漏写过 accountRepo==nil 守卫)。
// L2 候选循环改用带 per-pass 缓存的 parentLookupL2,不走此方法。
func (s *OpenAIGatewayService) parentAccountLookup(ctx context.Context) func(int64) *Account {
	return func(id int64) *Account {
		if s.accountRepo == nil {
			return nil
		}
		a, _ := s.accountRepo.GetByID(ctx, id)
		return a
	}
}

func (s *OpenAIGatewayService) recheckSelectedOpenAIAccountFromDB(ctx context.Context, account *Account, groupID *int64, platform string, requestedModel string, requireCompact bool, requiredCapability OpenAIEndpointCapability) *Account {
	if account == nil {
		return nil
	}
	platform = normalizeOpenAICompatiblePlatform(platform)
	if s.schedulerSnapshot == nil || s.accountRepo == nil {
		if !isOpenAICompatibleAccountEligibleForRequest(ctx, account, platform, requestedModel, requireCompact, requiredCapability) {
			return nil
		}
		if !parentHealthyForShadow(account, s.parentAccountLookup(ctx)) {
			return nil
		}
		if s.isOpenAIProxyStreamQuarantined(ctx, account) {
			return nil
		}
		capped, available := s.concurrencyService.applyCPAPoolCapacity(ctx, account)
		if !available {
			return nil
		}
		return capped
	}

	latest, err := s.accountRepo.GetByID(ctx, account.ID)
	if err != nil || latest == nil {
		return nil
	}
	if !s.openAIAccountMatchesSchedulingGroup(latest, groupID) {
		return nil
	}
	if !isOpenAICompatibleAccountEligibleForRequest(ctx, latest, platform, requestedModel, requireCompact, requiredCapability) {
		return nil
	}
	if !parentHealthyForShadow(latest, s.parentAccountLookup(ctx)) {
		return nil
	}
	if s.isOpenAIAccountRequestRuntimeBlocked(latest, requestedModel) {
		return nil
	}
	if s.isOpenAIProxyStreamQuarantined(ctx, latest) {
		return nil
	}
	capped, available := s.concurrencyService.applyCPAPoolCapacity(ctx, latest)
	if !available {
		return nil
	}
	return capped
}

func (s *OpenAIGatewayService) openAIAccountMatchesSchedulingGroup(account *Account, groupID *int64) bool {
	if s != nil && s.cfg != nil && s.cfg.RunMode == config.RunModeSimple {
		return account != nil
	}
	return openAIStickyAccountMatchesGroup(account, groupID)
}

func (s *OpenAIGatewayService) getSchedulableAccount(ctx context.Context, accountID int64) (*Account, error) {
	var (
		account *Account
		err     error
	)
	if s.schedulerSnapshot != nil {
		account, err = s.schedulerSnapshot.GetAccount(ctx, accountID)
	} else {
		account, err = s.accountRepo.GetByID(ctx, accountID)
	}
	if err != nil || account == nil {
		return account, err
	}
	return account, nil
}

func (s *OpenAIGatewayService) hydrateSelectedAccount(ctx context.Context, account *Account) (*Account, error) {
	if account == nil || s.schedulerSnapshot == nil {
		return account, nil
	}
	hydrated, err := s.schedulerSnapshot.GetAccount(ctx, account.ID)
	if err != nil {
		return nil, err
	}
	if hydrated == nil {
		return nil, fmt.Errorf("selected openai account %d not found during hydration", account.ID)
	}
	return hydrated, nil
}

func (s *OpenAIGatewayService) newSelectionResult(ctx context.Context, account *Account, acquired bool, release func(), waitPlan *AccountWaitPlan) (*AccountSelectionResult, error) {
	hydrated, err := s.hydrateSelectedAccount(ctx, account)
	if err != nil {
		return nil, err
	}
	return attachSelectionProfitGate(ctx, &AccountSelectionResult{
		Account:     hydrated,
		Acquired:    acquired,
		ReleaseFunc: release,
		WaitPlan:    waitPlan,
	}), nil
}

func (s *OpenAIGatewayService) newAcquiredSelectionResult(ctx context.Context, account *Account, release func()) (*AccountSelectionResult, error) {
	selection, err := s.newSelectionResult(ctx, account, true, release, nil)
	if err != nil && release != nil {
		release()
	}
	return selection, err
}

func (s *OpenAIGatewayService) schedulingConfig() config.GatewaySchedulingConfig {
	if s.cfg != nil {
		return s.cfg.Gateway.Scheduling
	}
	return config.GatewaySchedulingConfig{
		StickySessionMaxWaiting:  3,
		StickySessionWaitTimeout: 45 * time.Second,
		FallbackWaitTimeout:      30 * time.Second,
		FallbackMaxWaiting:       100,
		LoadBatchEnabled:         true,
		SlotCleanupInterval:      30 * time.Second,
	}
}
