package service

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/Wei-Shaw/sub2api/internal/platform/config"

	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/require"
	"github.com/tidwall/gjson"
)

func TestApplyOpenAICodexSemanticRequestHeaders(t *testing.T) {
	tests := []struct {
		name         string
		body         string
		wantSubagent string
		wantGuardian string
		wantMemgen   string
	}{
		{
			name:         "guardian reviewer",
			body:         `{"client_metadata":{"x-openai-subagent":"guardian","x-codex-turn-metadata":"{\"thread_source\":\"guardian_review\",\"turn_trigger\":\"approval\"}"}}`,
			wantSubagent: "guardian",
			wantGuardian: "reviewer",
		},
		{
			name:         "guardian classifier",
			body:         `{"client_metadata":{"x-openai-subagent":"guardian","x-codex-turn-metadata":"{\"thread_source\":\"guardian_classifier\",\"turn_trigger\":\"guardian_classifier\"}"}}`,
			wantSubagent: "guardian",
			wantGuardian: "classifier",
		},
		{
			name:         "memory consolidation",
			body:         `{"client_metadata":{"x-openai-subagent":"memory_consolidation","x-codex-turn-metadata":"{\"request_kind\":\"memory\",\"thread_source\":\"memory_consolidation\",\"turn_trigger\":\"memory_consolidation\"}"}}`,
			wantSubagent: "memory_consolidation",
			wantMemgen:   "true",
		},
		{
			name:         "ordinary compact subagent",
			body:         `{"client_metadata":{"x-openai-subagent":"compact"}}`,
			wantSubagent: "compact",
		},
		{
			name:         "mismatched spoof is cleared",
			body:         `{"client_metadata":{"x-openai-subagent":"guardian","x-codex-turn-metadata":"{\"thread_source\":\"ordinary\",\"turn_trigger\":\"guardian_classifier\"}"}}`,
			wantSubagent: "guardian",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			headers := http.Header{
				"X-Codex-Guardian":        []string{"forged"},
				"X-Openai-Memgen-Request": []string{"forged"},
				"X-Openai-Subagent":       []string{"forged"},
			}
			c, _ := gin.CreateTestContext(httptest.NewRecorder())
			c.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
			if tt.wantGuardian != "" {
				c.Request.Header.Set(openAICodexGuardianHeader, tt.wantGuardian)
			}
			if tt.wantMemgen != "" {
				c.Request.Header.Set(openAIMemgenRequestHeader, tt.wantMemgen)
			}
			applyOpenAICodexSemanticRequestHeaders(headers, c, &Account{Platform: PlatformOpenAI, Type: AccountTypeOAuth}, []byte(tt.body))
			require.Equal(t, tt.wantSubagent, headers.Get("x-openai-subagent"))
			require.Equal(t, tt.wantGuardian, headers.Get(openAICodexGuardianHeader))
			require.Equal(t, tt.wantMemgen, headers.Get(openAIMemgenRequestHeader))
		})
	}
}

func TestOpenAICodexRawTurnMetadataHeaderIsBoundedAndAccountScoped(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	c.Request.Header.Set("session-id", "client-session")

	headers := make(http.Header)
	headers.Set(openAIWSTurnMetadataHeader, `{"turn_id":"forged-turn","window_id":"forged-window","sandbox":"danger-full-access","guardian_credits_requested":true,"turn_trigger":"guardian_classifier","subagent_kind":"guardian","workspaces":[{"path":"/Users/alice/private/repo","associated_remote_urls":["https://example.com/org/repo.git?token=secret#fragment"],"access_token":"drop-me"}],"custom":{"nested":true}}`)
	account := &Account{ID: 92, Platform: PlatformOpenAI, Type: AccountTypeOAuth}

	applyOpenAICodexSemanticRequestHeaders(headers, c, account, nil)
	metadata := headers.Get(openAIWSTurnMetadataHeader)
	require.True(t, gjson.Valid(metadata))
	require.Empty(t, gjson.Get(metadata, "turn_id").String())
	require.Empty(t, gjson.Get(metadata, "window_id").String())
	require.Empty(t, gjson.Get(metadata, "sandbox").String())
	require.False(t, gjson.Get(metadata, "guardian_credits_requested").Exists())
	require.Equal(t, "guardian_classifier", gjson.Get(metadata, "turn_trigger").String())
	require.NotEqual(t, "client-session", gjson.Get(metadata, "session_id").String())
	require.NotEqual(t, "forged-window", gjson.Get(metadata, "window_id").String())
	require.Equal(t, resolveConvergedInstallationID(account), gjson.Get(metadata, "installation_id").String())
	require.Equal(t, "workspace:redacted", gjson.Get(metadata, "workspaces.0.path").String())
	require.Equal(t, "https://example.com/org/repo.git", gjson.Get(metadata, "workspaces.0.associated_remote_urls.0").String())
	require.False(t, gjson.Get(metadata, "workspaces.0.access_token").Exists())
	require.False(t, strings.Contains(metadata, "/Users/alice"))
	require.False(t, strings.Contains(metadata, "token=secret"))

	invalidHeaders := make(http.Header)
	invalidHeaders.Set(openAIWSTurnMetadataHeader, "not-json")
	applyOpenAICodexSemanticRequestHeaders(invalidHeaders, c, account, nil)
	require.Empty(t, invalidHeaders.Get(openAIWSTurnMetadataHeader))

	bodyHeaders := make(http.Header)
	bodyHeaders.Set(openAIWSTurnMetadataHeader, "not-json")
	body := []byte(`{"client_metadata":{"x-codex-turn-metadata":"{\"thread_source\":\"body\"}"}}`)
	applyOpenAICodexSemanticRequestHeaders(bodyHeaders, c, account, body)
	require.Equal(t, "body", gjson.Get(bodyHeaders.Get(openAIWSTurnMetadataHeader), "thread_source").String())
}

func TestOpenAIRequestBuildReconstructsIsolatedParentAndGuardianHeaders(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	c.Request.Header.Set("x-codex-parent-thread-id", "forged-direct-parent")
	c.Request.Header.Set(openAICodexGuardianHeader, "reviewer")
	c.Request.Header.Set(openAIMemgenRequestHeader, "true")

	body := []byte(`{
		"model":"gpt-5.6-sol",
		"client_metadata":{
			"session_id":"client-session",
			"thread_id":"client-thread",
			"x-codex-parent-thread-id":"client-parent",
			"x-openai-subagent":"guardian",
			"x-codex-turn-metadata":"{\"parent_thread_id\":\"client-parent\",\"thread_source\":\"guardian_review\"}"
		}
	}`)
	account := &Account{
		ID:       81,
		Platform: PlatformOpenAI,
		Type:     AccountTypeOAuth,
		Credentials: map[string]any{
			"chatgpt_account_id": "principal-81",
		},
	}

	req, err := (&OpenAIGatewayService{}).buildUpstreamRequest(
		context.Background(), c, account, body, "token", false, "", true,
	)
	require.NoError(t, err)
	parent := req.Header.Get("x-codex-parent-thread-id")
	require.NotEmpty(t, parent)
	require.NotEqual(t, "client-parent", parent)
	require.NotEqual(t, "forged-direct-parent", parent)
	require.Equal(t, "guardian", req.Header.Get("x-openai-subagent"))
	require.Equal(t, "reviewer", req.Header.Get(openAICodexGuardianHeader))
	require.Empty(t, req.Header.Get(openAIMemgenRequestHeader))

	rebuiltBody, err := io.ReadAll(req.Body)
	require.NoError(t, err)
	if req.Header.Get("Content-Encoding") == "zstd" {
		rebuiltBody = decodeZstdBody(t, rebuiltBody)
	}
	require.Equal(t, parent, gjson.GetBytes(rebuiltBody, "client_metadata.x-codex-parent-thread-id").String())
	turnMetadata := gjson.GetBytes(rebuiltBody, "client_metadata.x-codex-turn-metadata").String()
	require.Equal(t, parent, gjson.Get(turnMetadata, "parent_thread_id").String())
	require.NotContains(t, string(rebuiltBody), "forged-direct-parent")
}

func TestOpenAIRequestBuildAddsMemgenOnlyForConsistentMemoryMetadata(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	c.Request.Header.Set(openAIMemgenRequestHeader, "true")
	body := []byte(`{
		"model":"gpt-5.6-sol",
		"client_metadata":{
			"x-openai-subagent":"memory_consolidation",
			"x-codex-turn-metadata":"{\"request_kind\":\"memory\",\"thread_source\":\"memory_consolidation\",\"turn_trigger\":\"memory_consolidation\"}"
		}
	}`)
	account := &Account{ID: 82, Platform: PlatformOpenAI, Type: AccountTypeOAuth}

	req, err := (&OpenAIGatewayService{}).buildUpstreamRequest(
		context.Background(), c, account, body, "token", false, "", true,
	)
	require.NoError(t, err)
	require.Equal(t, "memory_consolidation", req.Header.Get("x-openai-subagent"))
	require.Equal(t, "true", req.Header.Get(openAIMemgenRequestHeader))
	require.Empty(t, req.Header.Get(openAICodexGuardianHeader))
}

func TestOpenAIWSCompatibilityIncludesRouteAuthAndSemanticHeaders(t *testing.T) {
	baseHeaders := http.Header{
		"Authorization":                         []string{"Bearer token-a"},
		"X-Openai-Account-Routing-Override":     []string{"us"},
		"X-Openai-Subagent":                     []string{"guardian"},
		"X-Codex-Guardian":                      []string{"reviewer"},
		"X-Responsesapi-Include-Timing-Metrics": []string{"true"},
	}
	base := openAIWSAcquireRequest{WSURL: "wss://workspace.example.com/backend-api/codex/responses", Headers: baseHeaders}
	baseKey := openAIWSAcquireCompatibility(base)

	mutations := []struct {
		name   string
		mutate func(*openAIWSAcquireRequest)
	}{
		{name: "target URL", mutate: func(req *openAIWSAcquireRequest) { req.WSURL = "wss://other.example.com/backend-api/codex/responses" }},
		{name: "authorization", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set("Authorization", "Bearer token-b") }},
		{name: "routing override", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set(openAIAccountRoutingOverrideHeader, "us_cr") }},
		{name: "responses lite", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set(responsesLiteHeaderKey, "true") }},
		{name: "websocket beta", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set("OpenAI-Beta", "responses_websockets=2026-02-04") }},
		{name: "subagent", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set("x-openai-subagent", "compact") }},
		{name: "guardian", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set(openAICodexGuardianHeader, "classifier") }},
		{name: "memgen", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Set(openAIMemgenRequestHeader, "true") }},
		{name: "timing metrics", mutate: func(req *openAIWSAcquireRequest) { req.Headers.Del("x-responsesapi-include-timing-metrics") }},
	}

	for _, tt := range mutations {
		t.Run(tt.name, func(t *testing.T) {
			req := openAIWSAcquireRequest{WSURL: base.WSURL, Headers: base.Headers.Clone()}
			tt.mutate(&req)
			require.NotEqual(t, baseKey, openAIWSAcquireCompatibility(req))
		})
	}
}

func TestOpenAICodexDesktopHeadersDropCallerOwnedRoutingAndProofState(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/responses", nil)
	headers := make(http.Header)
	for _, name := range []string{
		"X-OpenAI-Account-Routing-Override",
		"X-OpenAI-Attach-Integrity-State",
		"X-OAI-IS",
		"X-OAI-IS-Pending-Updates",
		"X-OAI-IS-Client-Observation",
		"X-OAI-IS-Update",
		"x-local-routing-key",
		"X-OpenAI-Expected-Account-Id",
	} {
		headers.Set(name, "caller-controlled")
	}

	normalizeOpenAICodexDesktopIdentityHeaders(headers, c, &Account{Platform: PlatformOpenAI, Type: AccountTypeOAuth})
	applyOpenAIWorkspaceRoutingHeader(headers, nil)
	for _, name := range []string{
		"X-OpenAI-Account-Routing-Override",
		"X-OpenAI-Attach-Integrity-State",
		"X-OAI-IS",
		"X-OAI-IS-Pending-Updates",
		"X-OAI-IS-Client-Observation",
		"X-OAI-IS-Update",
		"x-local-routing-key",
		"X-OpenAI-Expected-Account-Id",
	} {
		require.Empty(t, headers.Get(name), name)
	}
}

func TestOpenAIWSPoolRebuildsHandshakeWhenOAuthPrincipalChanges(t *testing.T) {
	for _, field := range []string{"chatgpt_account_id", "chatgpt_user_id", "plan_type", "chatgpt-account-id", "x-openai-fedramp"} {
		t.Run(field, func(t *testing.T) {
			cfg := &config.Config{}
			cfg.Gateway.OpenAIWS.MaxConnsPerAccount = 1
			cfg.Gateway.OpenAIWS.MaxIdlePerAccount = 1
			pool := newOpenAIWSConnPool(cfg)
			pool.setClientDialerForTest(&openAIWSFakeDialer{})
			t.Cleanup(pool.Close)
			account := &Account{ID: 101, Platform: PlatformOpenAI, Type: AccountTypeOAuth,
				Credentials: map[string]any{"chatgpt_account_id": "workspace-a", "chatgpt_user_id": "user-a", "plan_type": "team"}}
			headers := make(http.Header)
			headers.Set("Authorization", "Bearer opaque-token")
			headers.Set("chatgpt-account-id", "workspace-a")
			req := openAIWSAcquireRequest{Account: account,
				WSURL: "wss://chatgpt.com/backend-api/codex/responses", Headers: headers}
			ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
			defer cancel()
			first, err := pool.Acquire(ctx, req)
			require.NoError(t, err)
			firstID := first.ConnID()
			first.Release()
			same, err := pool.Acquire(ctx, req)
			require.NoError(t, err)
			require.Equal(t, firstID, same.ConnID(), "an unchanged principal must retain its socket")
			same.Release()

			// Keep the local account ID, URL and opaque token unchanged. A new
			// principal or actual workspace header must still force a new dial.
			updated := *account
			updated.Credentials = shallowCopyMap(account.Credentials)
			req.Account = &updated
			req.Headers = headers.Clone()
			switch field {
			case "plan_type":
				updated.Credentials[field] = "plus"
			case "chatgpt_account_id", "chatgpt_user_id":
				updated.Credentials[field] = "changed-principal"
			default:
				req.Headers.Set(field, "changed-header")
			}
			rebuilt, err := pool.Acquire(ctx, req)
			require.NoError(t, err)
			defer rebuilt.Release()
			require.NotEqual(t, firstID, rebuilt.ConnID())
			select {
			case <-first.conn.closedCh:
			default:
				t.Fatal("the old idle socket must be closed before replacing its principal")
			}
		})
	}
}

func TestOpenAIWSHeadersReconstructResponsesLiteFromHandshakeOrPayload(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodGet, "/v1/responses", nil)
	c.Request.Header.Set(responsesLiteHeader, "true")

	service := &OpenAIGatewayService{}
	account := &Account{Platform: PlatformOpenAI, Type: AccountTypeAPIKey}
	headers, _, err := service.buildOpenAIWSHeaders(
		context.Background(),
		c,
		account,
		"token",
		OpenAIWSProtocolDecision{Transport: OpenAIUpstreamTransportResponsesWebsocketV2},
		true,
		"",
		"",
		"",
		"gpt-5.6-sol",
		"",
	)
	require.NoError(t, err)
	require.Equal(t, "true", headers.Get(responsesLiteHeader))

	// A client may carry the signal only in the WS response.create metadata.
	c.Request.Header.Del(responsesLiteHeader)
	stageCodexOutboundSessionBody(c, []byte(`{"client_metadata":{"ws_request_header_x_openai_internal_codex_responses_lite":"true"}}`))
	headers, _, err = service.buildOpenAIWSHeaders(
		context.Background(),
		c,
		account,
		"token",
		OpenAIWSProtocolDecision{Transport: OpenAIUpstreamTransportResponsesWebsocketV2},
		true,
		"",
		"",
		"",
		"gpt-5.6-sol",
		"",
	)
	require.NoError(t, err)
	require.Equal(t, "true", headers.Get(responsesLiteHeader))
}

func TestOpenAICodexLatestMetadataKeysRemainTypedInFullProjection(t *testing.T) {
	metadata := map[string]any{
		"x-codex-ws-stream-request-start-ms": int64(123),
		"guardian_credits_requested":         true,
		"parent_response_id":                 "resp-parent",
		"x-codex-turn-metadata":              `{"forked_from_ordinal_exclusive":7,"turn_trigger":"guardian_classifier","history_ingest_requested":true,"analytics_enabled":false}`,
	}
	ids := &codexFingerprintIDs{
		mode:           codexFingerprintFull,
		fullSimulation: true,
		installationID: "11111111-1111-4111-8111-111111111111",
		sessionID:      "22222222-2222-7222-8222-222222222222",
		threadID:       "33333333-3333-7333-8333-333333333333",
		turnID:         "44444444-4444-7444-8444-444444444444",
		windowID:       "33333333-3333-7333-8333-333333333333:1",
	}

	require.True(t, applyCodexFingerprintClientMetadataMap(metadata, ids))
	require.Equal(t, "123", metadata["x-codex-ws-stream-request-start-ms"])
	require.Equal(t, "true", metadata["guardian_credits_requested"])
	require.Equal(t, "resp-parent", metadata["parent_response_id"])
	turnMetadata, ok := metadata["x-codex-turn-metadata"].(string)
	require.True(t, ok)
	require.Equal(t, int64(7), gjson.Get(turnMetadata, "forked_from_ordinal_exclusive").Int())
	require.True(t, gjson.Get(turnMetadata, "history_ingest_requested").Bool())
	require.Equal(t, gjson.False, gjson.Get(turnMetadata, "analytics_enabled").Type)
	require.Equal(t, "guardian_classifier", gjson.Get(turnMetadata, "turn_trigger").String())
	require.False(t, strings.Contains(turnMetadata, `"history_ingest_requested":"true"`))
}

func TestCodexLineageHTTPHeaderMatchesProjectedBody(t *testing.T) {
	for _, full := range []bool{false, true} {
		for _, passthrough := range []bool{false, true} {
			t.Run(fmt.Sprintf("full=%t/passthrough=%t", full, passthrough), func(t *testing.T) {
				c := newCodexSessionHeaderTestContext(t, "/v1/responses")
				c.Request.Header.Set("session-id", "client-session")
				body := []byte(`{"model":"gpt-5.5","input":"hi","client_metadata":{"parent_turn_id":"parent","root_turn_id":"root","x-codex-turn-metadata":"{\"parent_turn_id\":\"parent\",\"root_turn_id\":\"root\"}"}}`)
				account := &Account{ID: 403, Platform: PlatformOpenAI, Type: AccountTypeOAuth}
				var ids *codexFingerprintIDs
				if full {
					ids = &codexFingerprintIDs{mode: codexFingerprintFull, fullSimulation: true, identitySecret: "test-secret", principalKey: "principal", installationID: "install", sessionID: "session", threadID: "thread", turnID: "turn", windowID: "thread:1"}
					var err error
					body, _, err = applyCodexFingerprintClientMetadataToBody(body, ids, c)
					require.NoError(t, err)
				}
				svc := &OpenAIGatewayService{}
				var req *http.Request
				var err error
				if passthrough {
					req, err = svc.buildUpstreamRequestOpenAIPassthroughWithFingerprint(context.Background(), c, account, body, "token", ids)
				} else {
					req, err = svc.buildUpstreamRequestWithFingerprint(context.Background(), c, account, body, "token", false, "", true, ids)
				}
				require.NoError(t, err)
				out, err := io.ReadAll(req.Body)
				require.NoError(t, err)
				if req.Header.Get("Content-Encoding") == "zstd" {
					out = decodeZstdBody(t, out)
				}
				turn := gjson.GetBytes(out, "client_metadata.x-codex-turn-metadata").String()
				for _, key := range []string{"parent_turn_id", "root_turn_id"} {
					want := gjson.Get(turn, key).String()
					require.NotEmpty(t, want)
					require.Equal(t, want, gjson.GetBytes(out, "client_metadata."+key).String(), key+" outer projection")
					require.Equal(t, want, gjson.Get(req.Header.Get(openAIWSTurnMetadataHeader), key).String(), key+" header projection")
				}
			})
		}
	}
}

func TestCodexLineageSharedTurnIDNamespace(t *testing.T) {
	ids := &codexFingerprintIDs{mode: codexFingerprintFull, fullSimulation: true, identitySecret: "test-secret", principalKey: "principal", installationID: "install", sessionID: "session", threadID: "thread", turnID: "turn"}
	metadata := map[string]any{"parent_turn_id": "parent", "root_turn_id": "parent"}
	body, err := json.Marshal(map[string]any{"client_metadata": metadata})
	require.NoError(t, err)
	out, _, err := applyCodexFingerprintClientMetadataToBody(body, ids)
	require.NoError(t, err)
	turn := gjson.GetBytes(out, "client_metadata.x-codex-turn-metadata").String()
	require.Equal(t, gjson.Get(turn, "parent_turn_id").String(), gjson.Get(turn, "root_turn_id").String())
}
