package service

import (
	"fmt"

	"github.com/Wei-Shaw/sub2api/internal/domain"
)

// Status constants
const (
	StatusActive   = domain.StatusActive
	StatusDisabled = domain.StatusDisabled
	StatusError    = domain.StatusError
	StatusUnused   = domain.StatusUnused
	StatusUsed     = domain.StatusUsed
	StatusExpired  = domain.StatusExpired
)

// Role constants
const (
	RoleAdmin = domain.RoleAdmin
	RoleUser  = domain.RoleUser
)

// Affiliate rebate settings
const (
	AffiliateRebateRateDefault          = 20.0
	AffiliateRebateRateMin              = 0.0
	AffiliateRebateRateMax              = 100.0
	AffiliateEnabledDefault             = false // 邀请返利总开关默认关闭
	AffiliateRebateFreezeHoursDefault   = 0     // 0 = 不冻结（向后兼容）
	AffiliateRebateFreezeHoursMax       = 720   // 最大 30 天
	AffiliateRebateDurationDaysDefault  = 0     // 0 = 永久有效
	AffiliateRebateDurationDaysMax      = 3650  // ~10 年
	AffiliateRebatePerInviteeCapDefault = 0.0   // 0 = 无上限
	AdminRechargeRebateEnabledDefault   = false // 管理员充值默认不产生返利
)

// Platform constants
const (
	PlatformAnthropic   = domain.PlatformAnthropic
	PlatformOpenAI      = domain.PlatformOpenAI
	PlatformGemini      = domain.PlatformGemini
	PlatformAntigravity = domain.PlatformAntigravity
	PlatformGrok        = domain.PlatformGrok
	PlatformKimi        = domain.PlatformKimi
	PlatformZhipu       = domain.PlatformZhipu
	PlatformDeepseek    = domain.PlatformDeepseek
	PlatformMiniMax     = domain.PlatformMiniMax
	PlatformOpenCodeGo  = domain.PlatformOpenCodeGo
	PlatformTypeSafe    = domain.PlatformTypeSafe
	PlatformComposite   = domain.PlatformComposite
)

const (
	AccountModePayG   = domain.AccountModePayG
	AccountModeCoding = domain.AccountModeCoding
	AccountModeZen    = domain.AccountModeZen
	AccountModeGo     = domain.AccountModeGo
)

const (
	APIProtocolChatCompletions = "chat_completions"
	APIProtocolAnthropic       = "anthropic"
	APIProtocolResponses       = "responses"
	APIProtocolAdaptive        = "adaptive"
)

const (
	DefaultKimiPayGBaseURL    = "https://api.moonshot.cn/v1"
	DefaultKimiCodingBaseURL  = "https://api.kimi.com/coding/v1"
	DefaultZhipuPayGBaseURL   = "https://open.bigmodel.cn/api/paas/v4"
	DefaultZhipuCodingBaseURL = "https://open.bigmodel.cn/api/coding/paas/v4"
	DefaultDeepseekBaseURL    = "https://api.deepseek.com"
	DefaultMiniMaxBaseURL     = "https://api.minimaxi.com/v1"
	DefaultOpenCodeGoBaseURL  = "https://opencode.ai/zen/go/v1"
	DefaultOpenCodeZenBaseURL = "https://opencode.ai/zen/v1"

	DefaultKimiPayGAnthropicBaseURL    = "https://api.moonshot.cn/anthropic"
	DefaultKimiCodingAnthropicBaseURL  = "https://api.kimi.com/coding"
	DefaultZhipuAnthropicBaseURL       = "https://open.bigmodel.cn/api/anthropic"
	DefaultDeepseekAnthropicBaseURL    = "https://api.deepseek.com/anthropic"
	DefaultMiniMaxAnthropicBaseURL     = "https://api.minimaxi.com/anthropic"
	DefaultOpenCodeGoAnthropicBaseURL  = "https://opencode.ai/zen/go"
	DefaultOpenCodeZenAnthropicBaseURL = "https://opencode.ai/zen"
)

func IsCNProvider(platform string) bool {
	switch platform {
	case PlatformKimi, PlatformZhipu, PlatformDeepseek, PlatformMiniMax:
		return true
	default:
		return false
	}
}

func IsOpenCodeGo(platform string) bool {
	return platform == PlatformOpenCodeGo
}

func IsMultiProtocolAPIKeyProvider(platform string) bool {
	return IsCNProvider(platform) || IsOpenCodeGo(platform)
}

// AllowedQuotaPlatforms 是允许设置 user × platform quota 的平台列表（单一权威来源）。
// ent/schema/user_platform_quota.go 的 Validate 函数独立维护（构建期约束），
// 若新增平台需同步修改该 schema。
var AllowedQuotaPlatforms = []string{
	PlatformAnthropic,
	PlatformOpenAI,
	PlatformGemini,
	PlatformAntigravity,
	PlatformGrok,
	PlatformKimi,
	PlatformZhipu,
	PlatformDeepseek,
	PlatformMiniMax,
	PlatformOpenCodeGo,
	PlatformTypeSafe,
}

// IsAllowedQuotaPlatform 报告 s 是否为合法的 quota platform 标识。
func IsAllowedQuotaPlatform(s string) bool {
	for _, p := range AllowedQuotaPlatforms {
		if p == s {
			return true
		}
	}
	return false
}

// Account type constants
const (
	AccountTypeOAuth          = domain.AccountTypeOAuth          // OAuth类型账号（full scope: profile + inference）
	AccountTypeSetupToken     = domain.AccountTypeSetupToken     // Setup Token类型账号（inference only scope）
	AccountTypeAPIKey         = domain.AccountTypeAPIKey         // API Key类型账号
	AccountTypeUpstream       = domain.AccountTypeUpstream       // 上游透传类型账号（通过 Base URL + API Key 连接上游）
	AccountTypeBedrock        = domain.AccountTypeBedrock        // AWS Bedrock 类型账号（通过 SigV4 签名或 API Key 连接 Bedrock，由 credentials.auth_mode 区分）
	AccountTypeServiceAccount = domain.AccountTypeServiceAccount // Google Service Account 类型账号（用于 Vertex AI）
)

// Redeem type constants
const (
	RedeemTypeBalance          = domain.RedeemTypeBalance
	RedeemTypeConcurrency      = domain.RedeemTypeConcurrency
	RedeemTypeSubscription     = domain.RedeemTypeSubscription
	RedeemTypeInvitation       = domain.RedeemTypeInvitation
	RedeemTypeAffiliateBalance = "affiliate_balance"
)

// PromoCode status constants
const (
	PromoCodeStatusActive   = domain.PromoCodeStatusActive
	PromoCodeStatusDisabled = domain.PromoCodeStatusDisabled
)

// Admin adjustment type constants
const (
	AdjustmentTypeAdminBalance     = domain.AdjustmentTypeAdminBalance     // 管理员调整余额
	AdjustmentTypeAdminConcurrency = domain.AdjustmentTypeAdminConcurrency // 管理员调整并发数
)

// Group subscription type constants
const (
	SubscriptionTypeStandard     = domain.SubscriptionTypeStandard     // 标准计费模式（按余额扣费）
	SubscriptionTypeSubscription = domain.SubscriptionTypeSubscription // 订阅模式（按限额控制）
)

// Subscription status constants
const (
	SubscriptionStatusActive    = domain.SubscriptionStatusActive
	SubscriptionStatusExpired   = domain.SubscriptionStatusExpired
	SubscriptionStatusSuspended = domain.SubscriptionStatusSuspended
	// SubscriptionStatusRevoked 是 soft-deleted 订阅的 API 展示态，不写入 status 字段。
	SubscriptionStatusRevoked = "revoked"
)

// LinuxDoConnectSyntheticEmailDomain 是 LinuxDo Connect 用户的合成邮箱后缀（RFC 保留域名）。
const LinuxDoConnectSyntheticEmailDomain = "@linuxdo-connect.invalid"

// OIDCConnectSyntheticEmailDomain 是 OIDC 用户的合成邮箱后缀（RFC 保留域名）。
const OIDCConnectSyntheticEmailDomain = "@oidc-connect.invalid"

// WeChatConnectSyntheticEmailDomain 是 WeChat Connect 用户的合成邮箱后缀（RFC 保留域名）。
const WeChatConnectSyntheticEmailDomain = "@wechat-connect.invalid"

// DingTalkConnectSyntheticEmailDomain 是 DingTalk Connect 用户的合成邮箱后缀（RFC 保留域名）。
const DingTalkConnectSyntheticEmailDomain = "@dingtalk-connect.invalid"

// Setting keys
const (
	// 注册设置
	SettingKeyRegistrationEnabled              = "registration_enabled"                // 是否开放注册
	SettingKeyEmailVerifyEnabled               = "email_verify_enabled"                // 是否开启邮件验证
	SettingKeyRegistrationEmailSuffixWhitelist = "registration_email_suffix_whitelist" // 注册邮箱后缀白名单（JSON 数组）
	SettingKeyPromoCodeEnabled                 = "promo_code_enabled"                  // 是否启用优惠码功能
	SettingKeyPasswordResetEnabled             = "password_reset_enabled"              // 是否启用忘记密码功能（需要先开启邮件验证）
	SettingKeyFrontendURL                      = "frontend_url"                        // 前端基础URL，用于生成邮件中的重置密码链接
	SettingKeyInvitationCodeEnabled            = "invitation_code_enabled"             // 是否启用邀请码注册
	SettingKeyAffiliateEnabled                 = "affiliate_enabled"                   // 邀请返利功能总开关
	SettingKeyAffiliateRebateRate              = "affiliate_rebate_rate"               // 邀请返利比例（百分比，0-100）
	SettingKeyAffiliateRebateFreezeHours       = "affiliate_rebate_freeze_hours"       // 返利冻结期（小时，0=不冻结）
	SettingKeyAffiliateRebateDurationDays      = "affiliate_rebate_duration_days"      // 返利有效期（天，0=永久）
	SettingKeyAffiliateRebatePerInviteeCap     = "affiliate_rebate_per_invitee_cap"    // 单人返利上限（0=无上限）
	SettingKeyAffiliateAdminRechargeEnabled    = "affiliate_admin_recharge_enabled"    // 管理员充值是否产生返利
	SettingKeyRiskControlEnabled               = "risk_control_enabled"                // 是否启用风控中心入口与审计链路
	SettingKeyCloudflareIngressSettings        = "cloudflare_ingress_settings"         // 无效鉴权的 Cloudflare 边缘封禁设置（JSON）
	SettingKeyContentModerationConfig          = "content_moderation_config"           // 内容审计配置（JSON）
	SettingKeyCyberSessionBlockEnabled         = "cyber_session_block_enabled"         // cyber 命中后会话级自动屏蔽总开关(默认关)
	SettingKeyCyberSessionBlockTTLSeconds      = "cyber_session_block_ttl_seconds"     // 会话屏蔽 TTL 秒数(默认 3600)
	SettingKeyLoginAgreementEnabled            = "login_agreement_enabled"             // 登录前是否要求同意条款
	SettingKeyLoginAgreementMode               = "login_agreement_mode"                // 条款确认展示模式：modal / checkbox
	SettingKeyLoginAgreementUpdatedAt          = "login_agreement_updated_at"          // 条款更新日期（展示用）
	SettingKeyLoginAgreementDocuments          = "login_agreement_documents"           // 条款文档列表（JSON，Markdown 内容）

	// 邮件服务设置
	SettingKeySMTPHost     = "smtp_host"      // SMTP服务器地址
	SettingKeySMTPPort     = "smtp_port"      // SMTP端口
	SettingKeySMTPUsername = "smtp_username"  // SMTP用户名
	SettingKeySMTPPassword = "smtp_password"  // SMTP密码（加密存储）
	SettingKeySMTPFrom     = "smtp_from"      // 发件人地址
	SettingKeySMTPFromName = "smtp_from_name" // 发件人名称
	SettingKeySMTPUseTLS   = "smtp_use_tls"   // 是否使用TLS

	// 人机验证设置。各验证渠道互斥，由设置更新接口强制校验。
	SettingKeyTurnstileEnabled             = "turnstile_enabled"    // 是否启用 Cloudflare Turnstile
	SettingKeyTurnstileSiteKey             = "turnstile_site_key"   // Turnstile Site Key
	SettingKeyTurnstileSecretKey           = "turnstile_secret_key" // Turnstile Secret Key
	SettingKeyRecaptchaEnabled             = "recaptcha_enabled"    // 是否启用 Google reCAPTCHA
	SettingKeyRecaptchaSiteKey             = "recaptcha_site_key"   // reCAPTCHA Site Key
	SettingKeyRecaptchaSecretKey           = "recaptcha_secret_key" // reCAPTCHA Secret Key
	SettingKeyCapEnabled                   = "cap_enabled"          // 是否启用 Cap
	SettingKeyCapAPIEndpoint               = "cap_api_endpoint"     // Cap 站点 API Endpoint
	SettingKeyCapSecretKey                 = "cap_secret_key"       // Cap Site Secret Key
	SettingKeyTencentCaptchaEnabled        = "tencent_captcha_enabled"
	SettingKeyTencentCaptchaAppID          = "tencent_captcha_app_id"
	SettingKeyTencentCaptchaAppSecretKey   = "tencent_captcha_app_secret_key"
	SettingKeyTencentCaptchaCloudSecretID  = "tencent_captcha_cloud_secret_id"
	SettingKeyTencentCaptchaCloudSecretKey = "tencent_captcha_cloud_secret_key"
	SettingKeyTencentCaptchaRegion         = "tencent_captcha_region"
	SettingKeyAliyunCaptchaEnabled         = "aliyun_captcha_enabled"
	SettingKeyAliyunCaptchaAccessKeyID     = "aliyun_captcha_access_key_id"
	SettingKeyAliyunCaptchaAccessKeySecret = "aliyun_captcha_access_key_secret"
	SettingKeyAliyunCaptchaSceneID         = "aliyun_captcha_scene_id"
	SettingKeyAliyunCaptchaPrefix          = "aliyun_captcha_prefix"
	SettingKeyAliyunCaptchaRegion          = "aliyun_captcha_region"
	SettingKeyLocalCaptchaEnabled          = "local_captcha_enabled" // 是否启用本地图片验证码

	// API Key IP 访问控制设置
	SettingKeyAPIKeyACLTrustForwardedIP = "api_key_acl_trust_forwarded_ip" // API Key IP 白/黑名单是否信任转发 IP
	SettingKeyClientIPResolutionMode    = "client_ip_resolution_mode"
	SettingKeyClientIPTrustedProxies    = "client_ip_trusted_proxies"

	// TOTP 双因素认证设置
	SettingKeyTotpEnabled    = "totp_enabled"    // 是否启用 TOTP 2FA 功能
	SettingKeyPasskeyEnabled = "passkey_enabled" // 是否启用 Passkey 登录（仍要求有效的 WebAuthn 部署配置）

	// 会话安全设置
	SettingKeySessionBindingEnabled = "session_binding_enabled" // 会话 IP/UA 绑定（变更即失效），默认关闭

	// 敏感操作 step-up 2FA 设置
	SettingKeyStepUpEnabled = "step_up_enabled" // 敏感操作（导出/备份/S3配置/提升管理员等）要求 step-up 2FA，默认关闭

	// 面板 API 限流设置（JSON：PanelRateLimitSettings）
	SettingKeyPanelRateLimitSettings = "panel_rate_limit_settings"

	// 操作审计日志设置
	SettingKeyAuditLogRetentionDays = "audit_log_retention_days" // 审计日志保留天数（<=0 永久保留），默认 180

	// LinuxDo Connect OAuth 登录设置
	SettingKeyLinuxDoConnectEnabled      = "linuxdo_connect_enabled"
	SettingKeyLinuxDoConnectClientID     = "linuxdo_connect_client_id"
	SettingKeyLinuxDoConnectClientSecret = "linuxdo_connect_client_secret"
	SettingKeyLinuxDoConnectRedirectURL  = "linuxdo_connect_redirect_url"

	// DingTalk Connect OAuth 登录设置
	SettingKeyDingTalkConnectEnabled                 = "dingtalk_connect_enabled"
	SettingKeyDingTalkConnectClientID                = "dingtalk_connect_client_id"
	SettingKeyDingTalkConnectClientSecret            = "dingtalk_connect_client_secret"
	SettingKeyDingTalkConnectRedirectURL             = "dingtalk_connect_redirect_url"
	SettingKeyDingTalkConnectCorpRestrictionPolicy   = "dingtalk_connect_corp_restriction_policy"
	SettingKeyDingTalkConnectInternalCorpID          = "dingtalk_connect_internal_corp_id"
	SettingKeyDingTalkConnectBypassRegistration      = "dingtalk_connect_bypass_registration"
	SettingKeyDingTalkConnectSyncCorpEmail           = "dingtalk_connect_sync_corp_email"
	SettingKeyDingTalkConnectSyncDisplayName         = "dingtalk_connect_sync_display_name"
	SettingKeyDingTalkConnectSyncDept                = "dingtalk_connect_sync_dept"
	SettingKeyDingTalkConnectSyncCorpEmailAttrKey    = "dingtalk_connect_sync_corp_email_attr_key"
	SettingKeyDingTalkConnectSyncDisplayNameAttrKey  = "dingtalk_connect_sync_display_name_attr_key"
	SettingKeyDingTalkConnectSyncDeptAttrKey         = "dingtalk_connect_sync_dept_attr_key"
	SettingKeyDingTalkConnectSyncCorpEmailAttrName   = "dingtalk_connect_sync_corp_email_attr_name"
	SettingKeyDingTalkConnectSyncDisplayNameAttrName = "dingtalk_connect_sync_display_name_attr_name"
	SettingKeyDingTalkConnectSyncDeptAttrName        = "dingtalk_connect_sync_dept_attr_name"

	// WeChat Connect OAuth 登录设置
	SettingKeyWeChatConnectEnabled             = "wechat_connect_enabled"
	SettingKeyWeChatConnectAppID               = "wechat_connect_app_id"
	SettingKeyWeChatConnectAppSecret           = "wechat_connect_app_secret"
	SettingKeyWeChatConnectOpenAppID           = "wechat_connect_open_app_id"
	SettingKeyWeChatConnectOpenAppSecret       = "wechat_connect_open_app_secret"
	SettingKeyWeChatConnectMPAppID             = "wechat_connect_mp_app_id"
	SettingKeyWeChatConnectMPAppSecret         = "wechat_connect_mp_app_secret"
	SettingKeyWeChatConnectMobileAppID         = "wechat_connect_mobile_app_id"
	SettingKeyWeChatConnectMobileAppSecret     = "wechat_connect_mobile_app_secret"
	SettingKeyWeChatConnectOpenEnabled         = "wechat_connect_open_enabled"
	SettingKeyWeChatConnectMPEnabled           = "wechat_connect_mp_enabled"
	SettingKeyWeChatConnectMobileEnabled       = "wechat_connect_mobile_enabled"
	SettingKeyWeChatConnectMode                = "wechat_connect_mode"
	SettingKeyWeChatConnectScopes              = "wechat_connect_scopes"
	SettingKeyWeChatConnectRedirectURL         = "wechat_connect_redirect_url"
	SettingKeyWeChatConnectFrontendRedirectURL = "wechat_connect_frontend_redirect_url"

	// Generic OIDC OAuth 登录设置
	SettingKeyOIDCConnectEnabled              = "oidc_connect_enabled"
	SettingKeyOIDCConnectProviderName         = "oidc_connect_provider_name"
	SettingKeyOIDCConnectClientID             = "oidc_connect_client_id"
	SettingKeyOIDCConnectClientSecret         = "oidc_connect_client_secret"
	SettingKeyOIDCConnectIssuerURL            = "oidc_connect_issuer_url"
	SettingKeyOIDCConnectDiscoveryURL         = "oidc_connect_discovery_url"
	SettingKeyOIDCConnectAuthorizeURL         = "oidc_connect_authorize_url"
	SettingKeyOIDCConnectTokenURL             = "oidc_connect_token_url"
	SettingKeyOIDCConnectUserInfoURL          = "oidc_connect_userinfo_url"
	SettingKeyOIDCConnectJWKSURL              = "oidc_connect_jwks_url"
	SettingKeyOIDCConnectScopes               = "oidc_connect_scopes"
	SettingKeyOIDCConnectRedirectURL          = "oidc_connect_redirect_url"
	SettingKeyOIDCConnectFrontendRedirectURL  = "oidc_connect_frontend_redirect_url"
	SettingKeyOIDCConnectTokenAuthMethod      = "oidc_connect_token_auth_method"
	SettingKeyOIDCConnectUsePKCE              = "oidc_connect_use_pkce"
	SettingKeyOIDCConnectValidateIDToken      = "oidc_connect_validate_id_token"
	SettingKeyOIDCConnectAllowedSigningAlgs   = "oidc_connect_allowed_signing_algs"
	SettingKeyOIDCConnectClockSkewSeconds     = "oidc_connect_clock_skew_seconds"
	SettingKeyOIDCConnectRequireEmailVerified = "oidc_connect_require_email_verified"
	SettingKeyOIDCConnectUserInfoEmailPath    = "oidc_connect_userinfo_email_path"
	SettingKeyOIDCConnectUserInfoIDPath       = "oidc_connect_userinfo_id_path"
	SettingKeyOIDCConnectUserInfoUsernamePath = "oidc_connect_userinfo_username_path"

	// GitHub / Google 邮箱快捷登录设置
	SettingKeyGitHubOAuthEnabled             = "github_oauth_enabled"
	SettingKeyGitHubOAuthClientID            = "github_oauth_client_id"
	SettingKeyGitHubOAuthClientSecret        = "github_oauth_client_secret"
	SettingKeyGitHubOAuthRedirectURL         = "github_oauth_redirect_url"
	SettingKeyGitHubOAuthFrontendRedirectURL = "github_oauth_frontend_redirect_url"
	SettingKeyGoogleOAuthEnabled             = "google_oauth_enabled"
	SettingKeyGoogleOAuthClientID            = "google_oauth_client_id"
	SettingKeyGoogleOAuthClientSecret        = "google_oauth_client_secret"
	SettingKeyGoogleOAuthRedirectURL         = "google_oauth_redirect_url"
	SettingKeyGoogleOAuthFrontendRedirectURL = "google_oauth_frontend_redirect_url"

	// OEM设置
	SettingKeySiteName                    = "site_name"                     // 网站名称
	SettingKeySiteLogo                    = "site_logo"                     // 网站Logo (base64)
	SettingKeySiteSubtitle                = "site_subtitle"                 // 网站副标题
	SettingKeyAPIBaseURL                  = "api_base_url"                  // API端点地址（用于客户端配置和导入）
	SettingKeyContactInfo                 = "contact_info"                  // 客服联系方式
	SettingKeyDocURL                      = "doc_url"                       // 文档链接
	SettingKeyHomeContent                 = "home_content"                  // 首页内容（清洗后的展示型 HTML，或 URL 作为沙箱 iframe src）
	SettingKeyCompactHomeEnabled          = "compact_home_enabled"          // 是否启用内置简洁首页
	SettingKeyHideCcsImportButton         = "hide_ccs_import_button"        // 是否隐藏 API Keys 页面的导入 CCS 按钮
	SettingKeyPurchaseSubscriptionEnabled = "purchase_subscription_enabled" // 是否展示"购买订阅"页面入口
	SettingKeyPurchaseSubscriptionURL     = "purchase_subscription_url"     // "购买订阅"页面 URL（作为 iframe src）
	SettingKeyTableDefaultPageSize        = "table_default_page_size"       // 表格默认每页条数
	SettingKeyTablePageSizeOptions        = "table_page_size_options"       // 表格可选每页条数（JSON 数组）
	SettingKeyCustomMenuItems             = "custom_menu_items"             // 自定义菜单项（JSON 数组）
	SettingKeyCustomEndpoints             = "custom_endpoints"              // 自定义端点列表（JSON 数组）

	// 默认配置
	SettingKeyDefaultConcurrency   = "default_concurrency"    // 新用户默认并发量
	SettingKeyDefaultBalance       = "default_balance"        // 新用户默认余额
	SettingKeyDefaultSubscriptions = "default_subscriptions"  // 新用户默认订阅列表（JSON）
	SettingKeyDefaultUserRPMLimit  = "default_user_rpm_limit" // 新用户默认 RPM 限制（0 = 不限制）

	// 第三方认证来源默认授予配置
	SettingKeyAuthSourceDefaultEmailBalance             = "auth_source_default_email_balance"
	SettingKeyAuthSourceDefaultEmailConcurrency         = "auth_source_default_email_concurrency"
	SettingKeyAuthSourceDefaultEmailSubscriptions       = "auth_source_default_email_subscriptions"
	SettingKeyAuthSourceDefaultEmailGrantOnSignup       = "auth_source_default_email_grant_on_signup"
	SettingKeyAuthSourceDefaultEmailGrantOnFirstBind    = "auth_source_default_email_grant_on_first_bind"
	SettingKeyAuthSourceDefaultLinuxDoBalance           = "auth_source_default_linuxdo_balance"
	SettingKeyAuthSourceDefaultLinuxDoConcurrency       = "auth_source_default_linuxdo_concurrency"
	SettingKeyAuthSourceDefaultLinuxDoSubscriptions     = "auth_source_default_linuxdo_subscriptions"
	SettingKeyAuthSourceDefaultLinuxDoGrantOnSignup     = "auth_source_default_linuxdo_grant_on_signup"
	SettingKeyAuthSourceDefaultLinuxDoGrantOnFirstBind  = "auth_source_default_linuxdo_grant_on_first_bind"
	SettingKeyAuthSourceDefaultOIDCBalance              = "auth_source_default_oidc_balance"
	SettingKeyAuthSourceDefaultOIDCConcurrency          = "auth_source_default_oidc_concurrency"
	SettingKeyAuthSourceDefaultOIDCSubscriptions        = "auth_source_default_oidc_subscriptions"
	SettingKeyAuthSourceDefaultOIDCGrantOnSignup        = "auth_source_default_oidc_grant_on_signup"
	SettingKeyAuthSourceDefaultOIDCGrantOnFirstBind     = "auth_source_default_oidc_grant_on_first_bind"
	SettingKeyAuthSourceDefaultWeChatBalance            = "auth_source_default_wechat_balance"
	SettingKeyAuthSourceDefaultWeChatConcurrency        = "auth_source_default_wechat_concurrency"
	SettingKeyAuthSourceDefaultWeChatSubscriptions      = "auth_source_default_wechat_subscriptions"
	SettingKeyAuthSourceDefaultWeChatGrantOnSignup      = "auth_source_default_wechat_grant_on_signup"
	SettingKeyAuthSourceDefaultWeChatGrantOnFirstBind   = "auth_source_default_wechat_grant_on_first_bind"
	SettingKeyAuthSourceDefaultGitHubBalance            = "auth_source_default_github_balance"
	SettingKeyAuthSourceDefaultGitHubConcurrency        = "auth_source_default_github_concurrency"
	SettingKeyAuthSourceDefaultGitHubSubscriptions      = "auth_source_default_github_subscriptions"
	SettingKeyAuthSourceDefaultGitHubGrantOnSignup      = "auth_source_default_github_grant_on_signup"
	SettingKeyAuthSourceDefaultGitHubGrantOnFirstBind   = "auth_source_default_github_grant_on_first_bind"
	SettingKeyAuthSourceDefaultGoogleBalance            = "auth_source_default_google_balance"
	SettingKeyAuthSourceDefaultGoogleConcurrency        = "auth_source_default_google_concurrency"
	SettingKeyAuthSourceDefaultGoogleSubscriptions      = "auth_source_default_google_subscriptions"
	SettingKeyAuthSourceDefaultGoogleGrantOnSignup      = "auth_source_default_google_grant_on_signup"
	SettingKeyAuthSourceDefaultGoogleGrantOnFirstBind   = "auth_source_default_google_grant_on_first_bind"
	SettingKeyAuthSourceDefaultDingTalkBalance          = "auth_source_default_dingtalk_balance"
	SettingKeyAuthSourceDefaultDingTalkConcurrency      = "auth_source_default_dingtalk_concurrency"
	SettingKeyAuthSourceDefaultDingTalkSubscriptions    = "auth_source_default_dingtalk_subscriptions"
	SettingKeyAuthSourceDefaultDingTalkGrantOnSignup    = "auth_source_default_dingtalk_grant_on_signup"
	SettingKeyAuthSourceDefaultDingTalkGrantOnFirstBind = "auth_source_default_dingtalk_grant_on_first_bind"
	SettingKeyForceEmailOnThirdPartySignup              = "force_email_on_third_party_signup"

	// 管理员 API Key
	SettingKeyAdminAPIKey = "admin_api_key" // 全局管理员 API Key（用于外部系统集成）

	// Gemini 配额策略（JSON）
	SettingKeyGeminiQuotaPolicy = "gemini_quota_policy"

	// Model fallback settings
	SettingKeyEnableModelFallback      = "enable_model_fallback"
	SettingKeyFallbackModelAnthropic   = "fallback_model_anthropic"
	SettingKeyFallbackModelOpenAI      = "fallback_model_openai"
	SettingKeyFallbackModelGemini      = "fallback_model_gemini"
	SettingKeyFallbackModelAntigravity = "fallback_model_antigravity"

	// Request identity patch (Claude -> Gemini systemInstruction injection)
	SettingKeyEnableIdentityPatch = "enable_identity_patch"
	SettingKeyIdentityPatchPrompt = "identity_patch_prompt"

	// =========================
	// Ops Monitoring (vNext)
	// =========================

	// SettingKeyOpsMonitoringEnabled is a DB-backed soft switch to enable/disable ops module at runtime.
	SettingKeyOpsMonitoringEnabled = "ops_monitoring_enabled"

	// SettingKeyOpsRealtimeMonitoringEnabled controls realtime features (e.g. WS/QPS push).
	SettingKeyOpsRealtimeMonitoringEnabled = "ops_realtime_monitoring_enabled"

	// SettingKeyOpsQueryModeDefault controls the default query mode for ops dashboard (auto/raw/preagg).
	SettingKeyOpsQueryModeDefault = "ops_query_mode_default"

	// SettingKeyOpsEmailNotificationConfig stores JSON config for ops email notifications.
	SettingKeyOpsEmailNotificationConfig = "ops_email_notification_config"

	// SettingKeyOpsAlertRuntimeSettings stores JSON config for ops alert evaluator runtime settings.
	SettingKeyOpsAlertRuntimeSettings = "ops_alert_runtime_settings"

	// SettingKeyOpsMetricsIntervalSeconds controls the ops metrics collector interval (>=60).
	SettingKeyOpsMetricsIntervalSeconds = "ops_metrics_interval_seconds"

	// SettingKeyOpsAdvancedSettings stores JSON config for ops advanced settings (data retention, aggregation).
	SettingKeyOpsAdvancedSettings = "ops_advanced_settings"

	// SettingKeyOpsRuntimeLogConfig stores JSON config for runtime log settings.
	SettingKeyOpsRuntimeLogConfig = "ops_runtime_log_config"

	// =========================
	// Channel Monitor (渠道监控)
	// =========================

	// SettingKeyChannelMonitorEnabled is a DB-backed soft switch for the channel monitor feature.
	// When false: runner skips scheduling and user-facing endpoints return an empty list.
	SettingKeyChannelMonitorEnabled = "channel_monitor_enabled"

	// SettingKeyChannelMonitorDefaultIntervalSeconds controls the default interval (seconds)
	// pre-filled when creating a new channel monitor from the admin UI. Range: [15, 3600].
	SettingKeyChannelMonitorDefaultIntervalSeconds = "channel_monitor_default_interval_seconds"

	// SettingKeyChannelMonitorLatencyUnit controls how channel monitor latency values
	// are displayed in the admin and user-facing UI. Allowed values: "ms" or "s".
	SettingKeyChannelMonitorLatencyUnit = "channel_monitor_latency_unit"

	// SettingKeyChannelMonitorPublicShareEnabled controls whether administrators can
	// expose a copyable public status link for the channel monitor read-only view.
	// Defaults to false (opt-in share surface).
	SettingKeyChannelMonitorPublicShareEnabled = "channel_monitor_public_share_enabled"

	// SettingKeyChannelMonitorPublicShareRequireAuth controls whether the public
	// status link requires a logged-in user. When false, anonymous visitors can
	// access the read-only status data through the share endpoints.
	SettingKeyChannelMonitorPublicShareRequireAuth = "channel_monitor_public_share_require_auth"

	// SettingKeyAvailableChannelsEnabled is a DB-backed soft switch for the "Available Channels"
	// user-facing aggregate view. When false: user endpoint returns an empty list and the
	// sidebar entry is hidden. Defaults to false (opt-in feature).
	SettingKeyAvailableChannelsEnabled = "available_channels_enabled"

	// SettingKeySupportChatEnabled is a DB-backed soft switch for the online support chat
	// entry points. When false: user/admin sidebar entries are hidden and frontend routes
	// redirect away. Defaults to false (explicit opt-in feature).
	SettingKeySupportChatEnabled = "support_chat_enabled"

	// Support-chat retention is an explicit opt-in because it permanently deletes
	// ordinary messages. Zero days keeps messages indefinitely even when enabled.
	SettingKeySupportChatRetentionEnabled = "support_chat_retention_enabled"
	SettingKeySupportChatRetentionDays    = "support_chat_retention_days"

	// SettingKeyModelPlazaEnabled is a DB-backed soft switch for the Model Plaza page
	// (public group/model pricing showcase). When false: the plaza endpoint returns 404
	// and the header entry is hidden. Defaults to false (opt-in feature).
	SettingKeyModelPlazaEnabled = "model_plaza_enabled"

	// SettingKeyModelPlazaRequireAuth controls whether the Model Plaza page requires a
	// logged-in user. When false the page is public and anonymous visitors see only
	// non-exclusive groups.
	SettingKeyModelPlazaRequireAuth = "model_plaza_require_auth"

	// SettingKeyModelPlazaAutoPublicModels controls whether public groups are
	// automatically populated from their platform defaults and schedulable account
	// model mappings. Channel pricing remains authoritative when configured.
	SettingKeyModelPlazaAutoPublicModels = "model_plaza_auto_public_models"

	// SettingKeyModelPlazaDescription stores the Markdown blurb rendered at the top of
	// the Model Plaza page (global pricing notes, exchange rate, promotions, ...).
	SettingKeyModelPlazaDescription = "model_plaza_description"

	// SettingKeyMediaStudioEnabled is a DB-backed soft switch for the Media Studio page.
	// It is opt-in so rolling upgrades do not expose a new generation workspace unexpectedly.
	SettingKeyMediaStudioEnabled = "media_studio_enabled"

	// SettingKeyActivityCenterEnabled is a DB-backed soft switch for the user-facing Activity Center page.
	// It is opt-in so rolling upgrades do not expose a new campaign workspace unexpectedly.
	SettingKeyActivityCenterEnabled = "activity_center_enabled"

	// SettingKeyCustomModelConfigEnabled enables the custom model configuration feature,
	// allowing administrators to manually configure model capabilities (image, video, audio).
	SettingKeyCustomModelConfigEnabled = "custom_model_config_enabled"

	// SettingKeyIPv6EgressUIEnabled is retained for API/database compatibility.
	// It is now the administrator-controlled IPv6 egress master switch: it gates
	// the management surface, account routing, and HE tunnel actions together.
	SettingKeyIPv6EgressUIEnabled = "ipv6_egress_ui_enabled"

	// SettingKeyUpstreamBillingProbeSettings stores the global enable switch and interval
	// for probing remote Sub2API API-key billing metadata.
	SettingKeyUpstreamBillingProbeSettings = "upstream_billing_probe_settings"

	// SettingKeyProxyAutoAssignmentSettings stores the opt-in proxy-pool policy.
	SettingKeyProxyAutoAssignmentSettings = "proxy_auto_assignment_settings"
	// SettingKeyProxyAutoAssignmentCursor serializes round-robin reservations across instances.
	SettingKeyProxyAutoAssignmentCursor = "proxy_auto_assignment_cursor"

	// Account inspection settings and latest persisted run snapshot.
	SettingKeyAccountInspectionSettings = "account_inspection_settings"
	SettingKeyAccountInspectionState    = "account_inspection_state"
	// Account quality monitoring has an independent policy and run snapshot.
	SettingKeyAccountQualitySettings = "account_quality_settings"
	SettingKeyAccountQualityState    = "account_quality_state"

	// Account quality routing markers are stored in accounts.extra so existing
	// account rows and scheduler snapshots remain backward compatible.
	AccountQualityOriginalGroupsExtraKey = "account_quality_original_group_ids"
	AccountQualityRoutingGroupExtraKey   = "account_quality_routing_group_id"

	// SettingKeyOllamaCloudUsageSettings stores the opt-in global runner switch and interval.
	SettingKeyOllamaCloudUsageSettings = "ollama_cloud_usage_settings"

	// =========================
	// Overload Cooldown (529)
	// =========================

	// SettingKeyOverloadCooldownSettings stores JSON config for 529 overload cooldown handling.
	SettingKeyOverloadCooldownSettings = "overload_cooldown_settings"

	// SettingKeyRateLimit429CooldownSettings stores JSON config for 429 fallback cooldown handling.
	SettingKeyRateLimit429CooldownSettings = "rate_limit_429_cooldown_settings"
	// SettingKeyOAuth401CleanupSettings stores the opt-in gateway OAuth 401 deletion policy.
	SettingKeyOAuth401CleanupSettings = "oauth_401_cleanup_settings"

	// SettingKeyGlobalTempUnschedulableEnabled controls all temporary account scheduling pauses.
	SettingKeyGlobalTempUnschedulableEnabled = "global_temp_unschedulable_enabled"

	// =========================
	// Stream Timeout Handling
	// =========================

	// SettingKeyStreamTimeoutSettings stores JSON config for stream timeout handling.
	SettingKeyStreamTimeoutSettings = "stream_timeout_settings"

	// =========================
	// Request Rectifier (请求整流器)
	// =========================

	// SettingKeyRectifierSettings stores JSON config for rectifier settings (thinking signature + budget).
	SettingKeyRectifierSettings = "rectifier_settings"

	// =========================
	// Beta Policy Settings
	// =========================

	// SettingKeyBetaPolicySettings stores JSON config for beta policy rules.
	SettingKeyBetaPolicySettings = "beta_policy_settings"

	// SettingKeyOpenAIFastPolicySettings stores JSON config for OpenAI
	// service_tier (fast/flex) policy rules. Mirrors BetaPolicySettings but
	// targets OpenAI's body-level service_tier field instead of Claude's
	// anthropic-beta header.
	SettingKeyOpenAIFastPolicySettings = "openai_fast_policy_settings"

	// =========================
	// Claude Code Version Check
	// =========================

	// SettingKeyMinClaudeCodeVersion 最低 Claude Code 版本号要求 (semver, 如 "2.1.0"，空值=不检查)
	SettingKeyMinClaudeCodeVersion = "min_claude_code_version"
	// SettingKeyMinCodexVersion 最低 Codex 引擎版本要求 (semver, 如 "0.141.0"，空值=不检查)
	SettingKeyMinCodexVersion = "min_codex_version"
	// SettingKeyMaxCodexVersion 最高 Codex 引擎版本限制 (semver, 如 "0.200.0"，空值=不检查)
	SettingKeyMaxCodexVersion = "max_codex_version"
	// SettingKeyCodexCLIOnlyBlacklist codex_cli_only 全局黑名单（[]AllowedClientEntry JSON，OR deny）。
	SettingKeyCodexCLIOnlyBlacklist = "codex_cli_only_blacklist"
	// SettingKeyCodexCLIOnlyWhitelist codex_cli_only 全局白名单（[]AllowedClientEntry JSON，双因子 AND allow）。
	SettingKeyCodexCLIOnlyWhitelist = "codex_cli_only_whitelist"
	// SettingKeyCodexCLIOnlyAllowAppServerClients App Server 开关：对未列名客户端开闸（默认 false；仅显式 "true" 开）。
	SettingKeyCodexCLIOnlyAllowAppServerClients = "codex_cli_only_allow_app_server_clients"
	// SettingKeyCodexCLIOnlyAllowBodyEngineFingerprint 引擎门 body 通道开关：接受 client_metadata 引擎指纹（默认 false；仅显式 "true" 开）。(已废弃，迁移并入信号列表)
	SettingKeyCodexCLIOnlyAllowBodyEngineFingerprint = "codex_cli_only_allow_body_engine_fingerprint"
	// SettingKeyCodexCLIOnlyEngineFingerprintSignals codex_cli_only 引擎指纹门信号列表（[]EngineFingerprintSignal JSON）。
	// 勾选(required)信号之间 AND;每条 match 变体行内 OR;缺失/空/非法 → 默认种子(只勾 x-codex-)。
	SettingKeyCodexCLIOnlyEngineFingerprintSignals = "codex_cli_only_engine_fingerprint_signals"

	// SettingKeyMaxClaudeCodeVersion 最高 Claude Code 版本号限制 (semver, 如 "3.0.0"，空值=不检查)
	SettingKeyMaxClaudeCodeVersion = "max_claude_code_version"

	// SettingKeyAllowUngroupedKeyScheduling 允许未分组 API Key 调度（默认 false：未分组 Key 返回 403）
	SettingKeyAllowUngroupedKeyScheduling = "allow_ungrouped_key_scheduling"
	// SettingKeyOpenAILowUpstreamRatePriorityEnabled 旧调度是否按上游 token 倍率优先。
	SettingKeyOpenAILowUpstreamRatePriorityEnabled = "openai_low_upstream_rate_priority_enabled"
	// SettingKeyOpenAIOAuthSchedulingRateMultiplier OAuth 账号参与成本调度时使用的参考倍率。
	SettingKeyOpenAIOAuthSchedulingRateMultiplier = "openai_oauth_scheduling_rate_multiplier"
	// SettingKeyOpenAIContentSessionBurstBalanceEnabled 是否分散内容派生会话的重叠请求。
	SettingKeyOpenAIContentSessionBurstBalanceEnabled = "openai_content_session_burst_balance_enabled"
	SettingKeyOpenAISessionIDRateLimitEnabled         = "openai_session_id_rate_limit_enabled"
	SettingKeyOpenAISessionIDRateLimitPerMinute       = "openai_session_id_rate_limit_per_minute"
	// The OAuth gateway limiter is one Redis-backed token bucket shared by every
	// instance and every OpenAI OAuth account. It is independent of the
	// per-account explicit Session ID limiter above.
	SettingKeyOpenAIOAuthGatewayRateLimitEnabled = "openai_oauth_gateway_rate_limit_enabled"
	SettingKeyOpenAIOAuthGatewayRateLimitRPM     = "openai_oauth_gateway_rate_limit_rpm"
	SettingKeyOpenAIOAuthGatewayRateLimitBurst   = "openai_oauth_gateway_rate_limit_burst"
	// Request integrity observation only records field names whose protected
	// semantics changed; it never stores request content or blocks a request.
	SettingKeyOpenAIRequestIntegrityObserveEnabled = "openai_request_integrity_observe_enabled"
	// SettingKeyOpenAIAdvancedSchedulerStickyWeightedEnabled OpenAI 高级调度下是否启用粘性加权。
	SettingKeyOpenAIAdvancedSchedulerStickyWeightedEnabled = "openai_advanced_scheduler_sticky_weighted_enabled"
	// SettingKeyOpenAIAdvancedSchedulerSubscriptionPriorityEnabled OpenAI 高级调度下是否优先使用订阅账号池。
	SettingKeyOpenAIAdvancedSchedulerSubscriptionPriorityEnabled = "openai_advanced_scheduler_subscription_priority_enabled"
	SettingKeyOpenAIAdvancedSchedulerLBTopK                      = "openai_advanced_scheduler_lb_top_k"
	SettingKeyOpenAIAdvancedSchedulerWeightPriority              = "openai_advanced_scheduler_weight_priority"
	SettingKeyOpenAIAdvancedSchedulerWeightLoad                  = "openai_advanced_scheduler_weight_load"
	SettingKeyOpenAIAdvancedSchedulerWeightQueue                 = "openai_advanced_scheduler_weight_queue"
	SettingKeyOpenAIAdvancedSchedulerWeightErrorRate             = "openai_advanced_scheduler_weight_error_rate"
	SettingKeyOpenAIAdvancedSchedulerWeightTTFT                  = "openai_advanced_scheduler_weight_ttft"
	SettingKeyOpenAIAdvancedSchedulerWeightReset                 = "openai_advanced_scheduler_weight_reset"
	SettingKeyOpenAIAdvancedSchedulerWeightQuotaHeadroom         = "openai_advanced_scheduler_weight_quota_headroom"
	SettingKeyOpenAIAdvancedSchedulerWeightUpstreamCost          = "openai_advanced_scheduler_weight_upstream_cost"
	SettingKeyOpenAIAdvancedSchedulerWeightPreviousResponse      = "openai_advanced_scheduler_weight_previous_response"
	SettingKeyOpenAIAdvancedSchedulerWeightSessionSticky         = "openai_advanced_scheduler_weight_session_sticky"
	// SettingKeySchedulerV2Enabled controls the mutually exclusive, all-platform scheduler engine.
	SettingKeySchedulerV2Enabled        = "scheduler_v2_enabled"
	SettingKeySchedulerV2CandidateLimit = "scheduler_v2_candidate_limit"
	SettingKeySchedulerV2ScanLimit      = "scheduler_v2_scan_limit"
	// SettingKeyRequestPriorityAdmissionEnabled controls user-tier-aware request admission.
	SettingKeyRequestPriorityAdmissionEnabled = "request_priority_admission_enabled"
	// SettingKeyRequestPriorityPendingLimitPerInstance caps process-local queued requests.
	SettingKeyRequestPriorityPendingLimitPerInstance = "request_priority_pending_limit_per_instance"
	// SettingKeyRequestPriorityPendingMiBPerInstance caps process-local buffered request bodies.
	SettingKeyRequestPriorityPendingMiBPerInstance = "request_priority_pending_mib_per_instance"

	// SettingKeyBackendModeEnabled Backend 模式：禁用用户注册和自助服务，仅管理员可登录
	SettingKeyBackendModeEnabled = "backend_mode_enabled"

	// SettingKeyStreamModePerformanceEnabled coalesces downstream SSE flushes at event boundaries.
	SettingKeyStreamModePerformanceEnabled = "stream_mode_performance_enabled"
	// SettingKeyOpenAIWSModeRouterV2Enabled controls the OpenAI WS account-mode router.
	// When absent, runtime behavior falls back to gateway.openai_ws.mode_router_v2_enabled.
	SettingKeyOpenAIWSModeRouterV2Enabled = "openai_ws_mode_router_v2_enabled"
	// SettingKeyCodexSimulationSettings stores the admin-managed Codex OAuth
	// simulation switches, state TTL, and server-generated identity secret.
	// When absent, runtime behavior falls back to gateway.codex_simulation.
	SettingKeyCodexSimulationSettings = "codex_simulation_settings"
	// SettingKeyOpenAIVisibleOutputTTFTEnabled controls whether OpenAI TTFT is
	// measured from the first client-usable value (true) or the legacy semantic
	// output event classifier (false). Missing values default to true.
	SettingKeyOpenAIVisibleOutputTTFTEnabled = "openai_visible_output_ttft_enabled"
	SettingKeyOpenAIRequestTimezoneEnabled   = "openai_request_timezone_enabled"
	SettingKeyOpenAIRequestTimezone          = "openai_request_timezone"
	// SettingKeyOpenAIOAuthForceRelayEnabled forces OpenAI OAuth/Codex model
	// traffic through the administrator-selected relay. OAuth authorization and
	// token refresh endpoints intentionally do not use this setting.
	SettingKeyOpenAIOAuthForceRelayEnabled = "openai_oauth_force_relay_enabled"
	// SettingKeyOpenAIOAuthForceRelayBaseURL stores the relay base URL before the
	// endpoint-specific /responses, /models, or /alpha/search suffix.
	SettingKeyOpenAIOAuthForceRelayBaseURL = "openai_oauth_force_relay_base_url"

	// Gateway Forwarding Behavior
	// SettingKeyEnableFingerprintUnification 是否统一 OAuth 账号的 X-Stainless-* 指纹头（默认 true）
	SettingKeyEnableFingerprintUnification = "enable_fingerprint_unification"
	// SettingKeyEnableMetadataPassthrough 是否透传客户端原始 metadata.user_id（默认 false）
	SettingKeyEnableMetadataPassthrough = "enable_metadata_passthrough"
	// SettingKeyEnableCCHSigning 已废弃（no-op）：新版 Claude Code CLI 已取消 cch 签名字段，
	// 网关随之不再注入/签名 cch（见 buildBillingAttributionText）。保留该 key 仅为向后兼容，
	// 开关不再产生任何效果。
	SettingKeyEnableCCHSigning = "enable_cch_signing"
	// SettingKeyEnableClaudeOAuthSystemPromptInjection 是否对 Claude OAuth mimic 路径注入 Claude Code system blocks（默认 true）
	SettingKeyEnableClaudeOAuthSystemPromptInjection = "enable_claude_oauth_system_prompt_injection"
	// SettingKeyClaudeOAuthSystemPrompt Claude OAuth mimic 路径注入的通用扩展 system prompt（空值使用内置默认）
	SettingKeyClaudeOAuthSystemPrompt = "claude_oauth_system_prompt"
	// SettingKeyClaudeOAuthSystemPromptBlocks Claude OAuth mimic 路径注入的 system blocks JSON 配置（空值使用内置默认）
	SettingKeyClaudeOAuthSystemPromptBlocks = "claude_oauth_system_prompt_blocks"
	// SettingKeyEnableAnthropicCacheTTL1hInjection 是否对 Anthropic OAuth/SetupToken 请求体注入 1h cache_control ttl（默认 false）
	SettingKeyEnableAnthropicCacheTTL1hInjection = "enable_anthropic_cache_ttl_1h_injection"
	// SettingKeyEnableClientDatelineNormalization 是否对 Anthropic OAuth/SetupToken 账号
	// 的 /v1/messages 请求体做客户端 dateline 归一化（默认 true）。
	// 归一化把 system prompt / <system-reminder> 块中 "Today's date is …" 语句里的
	// 非 ASCII 撇号与 "/" 日期分隔符还原为 ASCII 撇号 + "-" 分隔符，抹除某些客户端
	// 在检测到非官方 base URL 时注入的 3 bit 隐写指纹。仅适用于 Anthropic OAuth/SetupToken
	// 账号；API Key 账号不受影响。
	SettingKeyEnableClientDatelineNormalization = "enable_client_dateline_normalization"
	// SettingKeyRewriteMessageCacheControl 是否改写 messages[*].content[*].cache_control（默认 false）
	SettingKeyRewriteMessageCacheControl = "rewrite_message_cache_control"
	// SettingKeyAntigravityUserAgentVersion Antigravity 上游 User-Agent 版本号（空值使用环境变量/默认值）
	SettingKeyAntigravityUserAgentVersion = "antigravity_user_agent_version"
	// SettingKeyOpenAICodexUserAgent OpenAI Codex 完整 User-Agent（空值使用内置默认）。
	// 自定义值保留引擎版本和应用构建号；固定/同步版本仅用于默认 CLI UA。
	SettingKeyOpenAICodexUserAgent = "openai_codex_user_agent"
	// SettingKeyOpenAICodexClientVersion 是管理员固定的出站 Codex 客户端版本。
	// 空值依次回退到自动同步值和编译期默认值。
	SettingKeyOpenAICodexClientVersion = "openai_codex_client_version"
	// SettingKeyOpenAICodexClientVersionSynced 由版本同步任务独占写入。
	SettingKeyOpenAICodexClientVersionSynced = "openai_codex_client_version_synced"
	// SettingKeyOpenAICodexVersionAutoSyncEnabled 控制官方稳定版自动同步，默认开启。
	SettingKeyOpenAICodexVersionAutoSyncEnabled = "openai_codex_version_auto_sync_enabled"
	// SettingKeyOpenAIAllowClaudeCodeCodexPlugin 已废弃：历史全局开关只作为升级迁移输入读取。
	// 迁移后等价规则写入 SettingKeyCodexCLIOnlyWhitelist，不再参与运行时判定。
	SettingKeyOpenAIAllowClaudeCodeCodexPlugin = "openai_allow_claude_code_codex_plugin"

	// 余额不足提醒
	SettingKeyBalanceLowNotifyEnabled     = "balance_low_notify_enabled"      // 全局开关
	SettingKeyBalanceLowNotifyThreshold   = "balance_low_notify_threshold"    // 默认阈值（USD）
	SettingKeyBalanceLowNotifyRechargeURL = "balance_low_notify_recharge_url" // 充值页面 URL

	// 订阅到期提醒
	SettingKeySubscriptionExpiryNotifyEnabled = "subscription_expiry_notify_enabled" // 订阅到期提醒全局开关，默认开启

	// 账号限额通知
	SettingKeyAccountQuotaNotifyEnabled = "account_quota_notify_enabled" // 全局开关
	SettingKeyAccountQuotaNotifyEmails  = "account_quota_notify_emails"  // 管理员通知邮箱列表（JSON 数组）

	// Web Search Emulation
	SettingKeyWebSearchEmulationConfig = "web_search_emulation_config" // JSON 配置
)

// SettingKeyDefaultPlatformQuotas —— 系统全局：每用户 × 平台日/周/月 USD 上限（JSON）。
// 值为 map[platform]{daily,weekly,monthly}，null/缺省 = 不限制；0 = 禁用；>0 = USD 上限。
const SettingKeyDefaultPlatformQuotas = "default_platform_quotas"

// SettingKeyAuthSourcePlatformQuotas 返回某 auth source 的 platform quota JSON key。
// 形如 auth_source_default_{source}_platform_quotas
func SettingKeyAuthSourcePlatformQuotas(source string) string {
	return fmt.Sprintf("auth_source_default_%s_platform_quotas", source)
}

// QuotaDimension constants for spark shadow accounts.
const (
	QuotaDimensionGlobal = "global"
	QuotaDimensionSpark  = "spark"
)

// AdminAPIKeyPrefix is the prefix for admin API keys (distinct from user "sk-" keys).
const AdminAPIKeyPrefix = "admin-"

// SettingKeyAllowUserViewErrorRequests controls whether end users can view
// their own failed requests on the usage page. Default false (opt-in).
const SettingKeyAllowUserViewErrorRequests = "allow_user_view_error_requests"

// SettingKeyAllowUserViewUsageDetails controls whether end users can open
// detailed usage records and billing calculations. Default false (opt-in).
const SettingKeyAllowUserViewUsageDetails = "allow_user_view_usage_details"
