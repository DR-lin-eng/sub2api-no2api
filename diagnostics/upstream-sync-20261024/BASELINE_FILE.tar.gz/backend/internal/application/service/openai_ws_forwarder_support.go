package service

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

func (s *OpenAIGatewayService) isOpenAIWSGeneratePrewarmEnabled() bool {
	return s != nil && s.cfg != nil && s.cfg.Gateway.OpenAIWS.PrewarmGenerateEnabled
}

func (s *OpenAIGatewayService) shouldPerformOpenAIWSGeneratePrewarm(account *Account) bool {
	return s.isOpenAIWSGeneratePrewarmEnabled() || account.IsCodexPrewarmContinuationEnabled()
}

const codexPrewarmContinuationReasoningHeader = "X-CPA-Reasoning"

type openAIWSPrewarmFirstOutputGuard struct {
	c               *gin.Context
	startedAt       time.Time
	timeout         time.Duration
	originalModel   string
	reasoningEffort string
}

func applyCodexPrewarmContinuationReasoningOverride(c *gin.Context, account *Account, reqBody map[string]any) (bool, error) {
	if c == nil || account == nil || !account.IsCodexPrewarmContinuationEnabled() ||
		!strings.EqualFold(strings.TrimSpace(c.GetHeader(codexPrewarmContinuationReasoningHeader)), "none") {
		return false, nil
	}
	if reqBody == nil {
		return false, errors.New("apply Codex prewarm continuation reasoning override: request body is nil")
	}

	reasoning, exists := reqBody["reasoning"].(map[string]any)
	if !exists {
		if raw, present := reqBody["reasoning"]; present && raw != nil {
			return false, fmt.Errorf("apply Codex prewarm continuation reasoning override: reasoning must be an object")
		}
		reasoning = make(map[string]any, 1)
		reqBody["reasoning"] = reasoning
	}
	if effort, ok := reasoning["effort"].(string); ok && effort == "none" {
		return false, nil
	}
	reasoning["effort"] = "none"
	return true, nil
}

// performOpenAIWSGeneratePrewarm 在 WSv2 下执行可选的 generate=false 预热。
// 全局预热默认关闭；账号级 Codex 续发开关可独立启用空业务预热。
// 失败时按可恢复错误回退到 HTTP。
func (s *OpenAIGatewayService) performOpenAIWSGeneratePrewarm(
	ctx context.Context,
	lease *openAIWSConnLease,
	decision OpenAIWSProtocolDecision,
	payload map[string]any,
	previousResponseID string,
	reqBody map[string]any,
	account *Account,
	stateStore OpenAIWSStateStore,
	groupID int64,
	firstOutputGuard *openAIWSPrewarmFirstOutputGuard,
) error {
	if s == nil {
		return nil
	}
	if lease == nil || account == nil {
		logOpenAIWSModeInfo("prewarm_skip reason=invalid_state has_lease=%v has_account=%v", lease != nil, account != nil)
		return nil
	}
	connID := strings.TrimSpace(lease.ConnID())
	codexContinuationEnabled := account.IsCodexPrewarmContinuationEnabled()
	if !s.shouldPerformOpenAIWSGeneratePrewarm(account) {
		return nil
	}
	if decision.Transport != OpenAIUpstreamTransportResponsesWebsocketV2 {
		logOpenAIWSModeInfo(
			"prewarm_skip account_id=%d conn_id=%s reason=transport_not_v2 transport=%s",
			account.ID,
			connID,
			normalizeOpenAIWSLogValue(string(decision.Transport)),
		)
		return nil
	}
	if strings.TrimSpace(previousResponseID) != "" {
		logOpenAIWSModeInfo(
			"prewarm_skip account_id=%d conn_id=%s reason=has_previous_response_id previous_response_id=%s",
			account.ID,
			connID,
			truncateOpenAIWSLogValue(previousResponseID, openAIWSIDValueMaxLen),
		)
		return nil
	}
	if lease.IsPrewarmed() && !codexContinuationEnabled {
		logOpenAIWSModeInfo("prewarm_skip account_id=%d conn_id=%s reason=already_prewarmed", account.ID, connID)
		return nil
	}
	toolContinuation := NeedsToolContinuation(reqBody)
	if codexContinuationEnabled {
		// Tool definitions and tool_choice are stable prewarm properties. Only
		// existing tool-call/output context makes this an in-progress chain that
		// must not be replaced with a fresh empty prewarm.
		toolContinuation = hasCodexPrewarmBusinessContinuation(reqBody)
	}
	if toolContinuation {
		logOpenAIWSModeInfo("prewarm_skip account_id=%d conn_id=%s reason=tool_continuation", account.ID, connID)
		return nil
	}
	prewarmStart := time.Now()
	prewarmModel := strings.TrimSpace(openAIWSPayloadString(payload, "model"))
	if mapped := strings.TrimSpace(account.GetMappedModel(prewarmModel)); mapped != "" {
		prewarmModel = mapped
	}
	logOpenAIWSModeInfo("prewarm_start account_id=%d conn_id=%s", account.ID, connID)

	prewarmPayload := make(map[string]any, len(payload)+1)
	for k, v := range payload {
		prewarmPayload[k] = v
	}
	if codexContinuationEnabled {
		// Keep the stable request properties (model, instructions, tools, etc.)
		// while omitting all business input from the warmup request.
		prewarmPayload["input"] = []any{}
	}
	prewarmPayload["generate"] = false
	prewarmPayloadJSON := payloadAsJSONBytes(prewarmPayload)

	if err := lease.WriteJSONWithContextTimeout(ctx, prewarmPayload, s.openAIWSWriteTimeout()); err != nil {
		lease.MarkBroken()
		logOpenAIWSModeInfo(
			"prewarm_write_fail account_id=%d conn_id=%s cause=%s",
			account.ID,
			connID,
			truncateOpenAIWSLogValue(err.Error(), openAIWSLogValueMaxLen),
		)
		return wrapOpenAIWSFallback("prewarm_write", err)
	}
	logOpenAIWSModeInfo("prewarm_write_sent account_id=%d conn_id=%s payload_bytes=%d", account.ID, connID, len(prewarmPayloadJSON))

	prewarmResponseID := ""
	prewarmEventCount := 0
	prewarmTerminalCount := 0
	for {
		readCtx := ctx
		var cancelRead context.CancelFunc
		var firstOutputDeadline time.Time
		if firstOutputGuard != nil && firstOutputGuard.timeout > 0 {
			firstOutputDeadline = firstOutputGuard.startedAt.Add(firstOutputGuard.timeout)
			remaining := time.Until(firstOutputDeadline)
			if remaining <= 0 {
				lease.MarkBroken()
				return s.newOpenAIFirstOutputTimeoutError(
					ctx, firstOutputGuard.c, account, firstOutputGuard.startedAt,
					firstOutputGuard.originalModel, firstOutputGuard.reasoningEffort,
					firstOutputGuard.timeout, "websocket_prewarm", lease.HandshakeHeaders(),
				)
			}
			readCtx, cancelRead = context.WithTimeout(ctx, remaining)
		}
		message, readErr := lease.ReadMessageWithContextTimeout(readCtx, s.openAIWSReadTimeout())
		if cancelRead != nil {
			cancelRead()
		}
		if readErr != nil && !firstOutputDeadline.IsZero() && ctx.Err() == nil && !time.Now().Before(firstOutputDeadline) {
			lease.MarkBroken()
			return s.newOpenAIFirstOutputTimeoutError(
				ctx, firstOutputGuard.c, account, firstOutputGuard.startedAt,
				firstOutputGuard.originalModel, firstOutputGuard.reasoningEffort,
				firstOutputGuard.timeout, "websocket_prewarm", lease.HandshakeHeaders(),
			)
		}
		if readErr != nil {
			lease.MarkBroken()
			closeStatus, closeReason := summarizeOpenAIWSReadCloseError(readErr)
			logOpenAIWSModeInfo(
				"prewarm_read_fail account_id=%d conn_id=%s close_status=%s close_reason=%s cause=%s events=%d",
				account.ID,
				connID,
				closeStatus,
				closeReason,
				truncateOpenAIWSLogValue(readErr.Error(), openAIWSLogValueMaxLen),
				prewarmEventCount,
			)
			return wrapOpenAIWSFallback("prewarm_"+classifyOpenAIWSReadFallbackReason(readErr), readErr)
		}

		eventType, eventResponseID, _ := parseOpenAIWSEventEnvelope(message)
		if eventType == "" {
			continue
		}
		prewarmEventCount++
		if prewarmResponseID == "" && eventResponseID != "" {
			prewarmResponseID = eventResponseID
		}
		if prewarmEventCount <= openAIWSPrewarmEventLogHead || eventType == "error" || isOpenAIWSTerminalEvent(eventType) {
			logOpenAIWSModeInfo(
				"prewarm_event account_id=%d conn_id=%s idx=%d type=%s bytes=%d",
				account.ID,
				connID,
				prewarmEventCount,
				truncateOpenAIWSLogValue(eventType, openAIWSLogValueMaxLen),
				len(message),
			)
		}

		if eventType == "error" {
			errCodeRaw, errTypeRaw, errMsgRaw := parseOpenAIWSErrorEventFields(message)
			errMsg := strings.TrimSpace(errMsgRaw)
			if errMsg == "" {
				errMsg = "OpenAI websocket prewarm error"
			}
			fallbackReason, canFallback := classifyOpenAIWSErrorEventFromRaw(errCodeRaw, errTypeRaw, errMsgRaw)
			if fallbackReason != "upgrade_required" && fallbackReason != "ws_unsupported" &&
				fallbackReason != "ws_connection_limit_reached" && fallbackReason != "previous_response_not_found" &&
				fallbackReason != "invalid_encrypted_content" {
				if failoverErr := s.handleOpenAIWSPreOutputFailure(
					ctx,
					account,
					prewarmModel,
					openAIWSErrorHTTPStatusFromRaw(errCodeRaw, errTypeRaw),
					lease.HandshakeHeaders(),
					message,
					errMsg,
				); failoverErr != nil {
					lease.MarkBroken()
					return failoverErr
				}
			}
			s.persistOpenAIWSRateLimitSignal(ctx, account, lease.HandshakeHeaders(), message, errCodeRaw, errTypeRaw, errMsgRaw, prewarmModel)
			errCode, errType, errMessage := summarizeOpenAIWSErrorEventFieldsFromRaw(errCodeRaw, errTypeRaw, errMsgRaw)
			logOpenAIWSModeInfo(
				"prewarm_error_event account_id=%d conn_id=%s idx=%d fallback_reason=%s can_fallback=%v err_code=%s err_type=%s err_message=%s",
				account.ID,
				connID,
				prewarmEventCount,
				truncateOpenAIWSLogValue(fallbackReason, openAIWSLogValueMaxLen),
				canFallback,
				errCode,
				errType,
				errMessage,
			)
			lease.MarkBroken()
			if canFallback {
				return wrapOpenAIWSFallback("prewarm_"+fallbackReason, errors.New(errMsg))
			}
			return wrapOpenAIWSFallback("prewarm_error_event", errors.New(errMsg))
		}

		if isOpenAIWSTerminalEvent(eventType) {
			if normalizeOpenAIWSTerminalEvent(eventType) == "response.failed" {
				errCodeRaw, errTypeRaw, _ := parseOpenAIWSErrorEventFields(message)
				statusCode := openAIWSPayloadStatusCode(message)
				if statusCode == 0 {
					statusCode = openAIWSErrorHTTPStatusFromRaw(errCodeRaw, errTypeRaw)
				}
				if failoverErr := s.handleOpenAIWSPreOutputFailure(
					ctx,
					account,
					prewarmModel,
					statusCode,
					lease.HandshakeHeaders(),
					message,
					extractUpstreamErrorMessage(message),
				); failoverErr != nil {
					lease.MarkBroken()
					return failoverErr
				}
			}
			prewarmTerminalCount++
			break
		}
	}

	if codexContinuationEnabled {
		if prewarmResponseID == "" {
			lease.MarkBroken()
			return wrapOpenAIWSFallback("prewarm_missing_response_id", errors.New("OpenAI websocket prewarm completed without response id"))
		}
		rewrittenUserMessages := applyCodexPrewarmContinuationPayload(payload, prewarmResponseID)
		logOpenAIWSModeInfo(
			"prewarm_business_prepared account_id=%d conn_id=%s previous_response_id=%s user_roles_rewritten=%d instructions_preserved=%v",
			account.ID,
			connID,
			truncateOpenAIWSLogValue(prewarmResponseID, openAIWSIDValueMaxLen),
			rewrittenUserMessages,
			hasNonEmptyString(payload["instructions"]),
		)
	}

	lease.MarkPrewarmed()
	if prewarmResponseID != "" && stateStore != nil {
		ttl := s.openAIWSResponseStickyTTL()
		logOpenAIWSBindResponseAccountWarn(groupID, account.ID, prewarmResponseID, stateStore.BindResponseAccount(ctx, groupID, prewarmResponseID, account.ID, ttl))
		stateStore.BindResponseConn(prewarmResponseID, lease.ConnID(), ttl)
	}
	logOpenAIWSModeInfo(
		"prewarm_done account_id=%d conn_id=%s response_id=%s events=%d terminal_events=%d duration_ms=%d",
		account.ID,
		connID,
		truncateOpenAIWSLogValue(prewarmResponseID, openAIWSIDValueMaxLen),
		prewarmEventCount,
		prewarmTerminalCount,
		time.Since(prewarmStart).Milliseconds(),
	)
	return nil
}

func hasCodexPrewarmBusinessContinuation(reqBody map[string]any) bool {
	if len(reqBody) == 0 || hasNonEmptyString(reqBody["previous_response_id"]) {
		return hasNonEmptyString(reqBody["previous_response_id"])
	}
	input, ok := reqBody["input"].([]any)
	if !ok {
		return false
	}
	var callIDs map[string]struct{}
	var outputCallIDs map[string]struct{}
	for _, item := range input {
		itemMap, ok := item.(map[string]any)
		if !ok {
			continue
		}
		itemType := strings.TrimSpace(firstNonEmptyString(itemMap["type"]))
		if itemType == "item_reference" {
			return true
		}
		if isCodexToolCallContextItemType(itemType) {
			callID := strings.TrimSpace(firstNonEmptyString(itemMap["call_id"]))
			if callID != "" {
				if callIDs == nil {
					callIDs = make(map[string]struct{})
				}
				callIDs[callID] = struct{}{}
			}
			continue
		}
		if isCodexToolCallOutputItemType(itemType) {
			callID := strings.TrimSpace(firstNonEmptyString(itemMap["call_id"]))
			if callID == "" {
				return true
			}
			if outputCallIDs == nil {
				outputCallIDs = make(map[string]struct{})
			}
			outputCallIDs[callID] = struct{}{}
		}
	}
	for callID := range outputCallIDs {
		if _, ok := callIDs[callID]; !ok {
			return true
		}
	}
	for callID := range callIDs {
		if _, ok := outputCallIDs[callID]; !ok {
			return true
		}
	}
	return false
}

// applyCodexPrewarmContinuationPayload turns the business request into a
// continuation from the empty prewarm response. Native agent history keeps its
// structure; text-only user message roles become developer roles, while image
// messages remain user because ChatGPT Codex rejects input_image under
// developer. Top-level instructions stay in place so both WS writes retain the
// same stable fields.
func applyCodexPrewarmContinuationPayload(payload map[string]any, previousResponseID string) int {
	if len(payload) == 0 || strings.TrimSpace(previousResponseID) == "" {
		return 0
	}

	rewrittenUserMessages := rewriteCodexPrewarmContinuationUserRoles(payload)

	payload["previous_response_id"] = strings.TrimSpace(previousResponseID)
	delete(payload, "generate")
	return rewrittenUserMessages
}

func rewriteCodexPrewarmContinuationUserRoles(payload map[string]any) int {
	if len(payload) == 0 {
		return 0
	}
	switch typed := payload["input"].(type) {
	case nil:
		return 0
	case []any:
		rewritten := 0
		for _, item := range typed {
			if itemMap, ok := item.(map[string]any); ok && rewriteCodexPrewarmContinuationMessageRole(itemMap) {
				rewritten++
			}
		}
		return rewritten
	case []map[string]any:
		rewritten := 0
		for _, item := range typed {
			if rewriteCodexPrewarmContinuationMessageRole(item) {
				rewritten++
			}
		}
		return rewritten
	case map[string]any:
		if rewriteCodexPrewarmContinuationMessageRole(typed) {
			return 1
		}
		return 0
	case string:
		if typed == "" {
			payload["input"] = []any{}
			return 0
		}
		payload["input"] = []any{map[string]any{
			"type": "message",
			"role": "developer",
			"content": []any{
				map[string]any{
					"type": "input_text",
					"text": typed,
				},
			},
		}}
		return 1
	default:
		return 0
	}
}

func rewriteCodexPrewarmContinuationMessageRole(item map[string]any) bool {
	if item == nil {
		return false
	}
	role, _ := item["role"].(string)
	if !strings.EqualFold(strings.TrimSpace(role), "user") {
		return false
	}
	itemType, _ := item["type"].(string)
	itemType = strings.TrimSpace(itemType)
	if itemType != "" && itemType != "message" {
		return false
	}
	if hasOpenAIInputImageValue(item["content"]) {
		return false
	}
	item["role"] = "developer"
	return true
}

func payloadAsJSON(payload map[string]any) string {
	return string(payloadAsJSONBytes(payload))
}

func payloadAsJSONBytes(payload map[string]any) []byte {
	if len(payload) == 0 {
		return []byte("{}")
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return []byte("{}")
	}
	return body
}

func isOpenAIWSTerminalEvent(eventType string) bool {
	switch strings.TrimSpace(eventType) {
	case "response.completed", "response.done", "response.failed", "response.incomplete", "response.cancelled", "response.canceled":
		return true
	default:
		return false
	}
}

func normalizeOpenAIWSTerminalEvent(eventType string) string {
	switch strings.TrimSpace(eventType) {
	case "response.completed":
		return "response.completed"
	case "response.done":
		return "response.done"
	case "response.failed":
		return "response.failed"
	case "response.incomplete":
		return "response.incomplete"
	case "response.cancelled", "response.canceled":
		return "response.cancelled"
	default:
		return ""
	}
}

func openAIWSPayloadStatusCode(payload []byte) int {
	if len(payload) == 0 {
		return 0
	}
	status := int(gjson.GetBytes(payload, "response.error.status_code").Int())
	if status == 0 {
		status = int(gjson.GetBytes(payload, "response.error.status").Int())
	}
	if status == 0 {
		status = int(gjson.GetBytes(payload, "error.status_code").Int())
	}
	if status == 0 {
		status = int(gjson.GetBytes(payload, "error.status").Int())
	}
	return status
}

func openAIWSPayloadTransientStatus(payload []byte) int {
	status := openAIWSPayloadStatusCode(payload)
	if status == 0 {
		// Some upstreams only expose a semantic error code/type. Keep the
		// existing classification for those payloads below.
		return openAIWSPayloadSemanticTransientStatus(payload)
	}
	if shouldCooldownOpenAITransientUpstreamError(status, payload) {
		return status
	}
	return 0
}

func openAIWSPayloadSemanticTransientStatus(payload []byte) int {
	code := strings.ToLower(strings.TrimSpace(gjson.GetBytes(payload, "response.error.code").String()))
	errType := strings.ToLower(strings.TrimSpace(gjson.GetBytes(payload, "response.error.type").String()))
	if code == "" {
		code = strings.ToLower(strings.TrimSpace(gjson.GetBytes(payload, "error.code").String()))
	}
	if errType == "" {
		errType = strings.ToLower(strings.TrimSpace(gjson.GetBytes(payload, "error.type").String()))
	}
	switch {
	case code == "server_is_overloaded", code == "slow_down":
		return http.StatusServiceUnavailable
	case strings.Contains(code, "server_error"),
		strings.Contains(code, "internal_error"),
		strings.Contains(code, "upstream_error"),
		strings.Contains(errType, "server_error"),
		strings.Contains(errType, "internal_error"),
		strings.Contains(errType, "upstream_error"):
		return http.StatusInternalServerError
	default:
		return 0
	}
}

func shouldFailoverOpenAIWSPreOutputFailure(statusCode int, payload []byte) bool {
	return statusCode == http.StatusTooManyRequests ||
		shouldCooldownOpenAITransientUpstreamError(statusCode, payload)
}

func newOpenAIWSPreOutputFailoverError(statusCode int, headers http.Header, payload []byte, message string) *UpstreamFailoverError {
	if statusCode <= 0 {
		statusCode = http.StatusBadGateway
	}
	body := append([]byte(nil), payload...)
	if len(body) == 0 {
		errType := "upstream_error"
		if statusCode == http.StatusTooManyRequests {
			errType = "rate_limit_error"
		}
		body, _ = json.Marshal(map[string]any{
			"error": map[string]any{
				"type":    errType,
				"message": strings.TrimSpace(message),
			},
		})
	}
	return &UpstreamFailoverError{
		StatusCode:        statusCode,
		ResponseBody:      body,
		ResponseHeaders:   cloneHeader(headers),
		Scope:             GatewayFailureScopeAccount,
		NextAccountAction: NextAccountRetry,
	}
}

// handleOpenAIWSPreOutputFailure converts a retryable WS error before semantic
// output into the common account-failover contract.
func (s *OpenAIGatewayService) handleOpenAIWSPreOutputFailure(
	ctx context.Context,
	account *Account,
	canonicalModel string,
	statusCode int,
	headers http.Header,
	payload []byte,
	message string,
) *UpstreamFailoverError {
	if !shouldFailoverOpenAIWSPreOutputFailure(statusCode, payload) {
		return nil
	}
	s.handleOpenAIAccountUpstreamError(ctx, account, statusCode, headers, payload, canonicalModel)
	return newOpenAIWSPreOutputFailoverError(statusCode, headers, payload, message)
}

func (s *OpenAIGatewayService) handleOpenAIWSTerminalTransientFailure(ctx context.Context, account *Account, canonicalModel string, headers http.Header, payload []byte) string {
	eventType, _, _ := parseOpenAIWSEventEnvelope(payload)
	terminalEvent := normalizeOpenAIWSTerminalEvent(eventType)
	if terminalEvent != "response.failed" {
		return terminalEvent
	}
	status := openAIWSPayloadTransientStatus(payload)
	if status != 0 {
		s.handleOpenAIAccountUpstreamError(ctx, account, status, headers, payload, canonicalModel)
	}
	return terminalEvent
}

func (s *OpenAIGatewayService) handleOpenAIWSErrorEventTransientFailure(ctx context.Context, account *Account, canonicalModel string, headers http.Header, payload []byte) {
	eventType, _, _ := parseOpenAIWSEventEnvelope(payload)
	if eventType != "error" {
		return
	}
	status := openAIWSPayloadTransientStatus(payload)
	if status != 0 {
		s.handleOpenAIAccountUpstreamError(ctx, account, status, headers, payload, canonicalModel)
	}
}

func (s *OpenAIGatewayService) handleOpenAIWSDialTransientFailure(ctx context.Context, account *Account, canonicalModel string, err error) {
	var dialErr *openAIWSDialError
	if !errors.As(err, &dialErr) || dialErr == nil || !shouldCooldownOpenAITransientUpstreamError(dialErr.StatusCode, dialErr.ResponseBody) {
		return
	}
	s.handleOpenAIAccountUpstreamError(ctx, account, dialErr.StatusCode, dialErr.ResponseHeaders, dialErr.ResponseBody, canonicalModel)
}

func isOpenAIWSDialTokenExpired(err error) bool {
	var dialErr *openAIWSDialError
	if !errors.As(err, &dialErr) || dialErr == nil || dialErr.StatusCode != http.StatusUnauthorized {
		return false
	}
	return extractUpstreamErrorCode(dialErr.ResponseBody) == "token_expired"
}

func isOpenAIWSTokenExpiredEvent(payload []byte) bool {
	return extractUpstreamErrorCode(payload) == "token_expired"
}

func isOpenAIWSTokenEvent(eventType string) bool {
	eventType = strings.TrimSpace(eventType)
	return strings.HasSuffix(eventType, ".delta") ||
		eventType == "response.output_text.done" ||
		eventType == "response.function_call_arguments.done"
}

func replaceOpenAIWSMessageModel(message []byte, fromModel, toModel string) []byte {
	if len(message) == 0 {
		return message
	}
	if strings.TrimSpace(fromModel) == "" || strings.TrimSpace(toModel) == "" || fromModel == toModel {
		return message
	}
	if !bytes.Contains(message, []byte(`"model"`)) || !bytes.Contains(message, []byte(fromModel)) {
		return message
	}
	modelValues := gjson.GetManyBytes(message, "model", "response.model")
	replaceModel := modelValues[0].Exists() && modelValues[0].Str == fromModel
	replaceResponseModel := modelValues[1].Exists() && modelValues[1].Str == fromModel
	if !replaceModel && !replaceResponseModel {
		return message
	}
	updated := message
	if replaceModel {
		if next, err := sjson.SetBytes(updated, "model", toModel); err == nil {
			updated = next
		}
	}
	if replaceResponseModel {
		if next, err := sjson.SetBytes(updated, "response.model", toModel); err == nil {
			updated = next
		}
	}
	return updated
}

func populateOpenAIUsageFromResponseJSON(body []byte, usage *OpenAIUsage) {
	if usage == nil || len(body) == 0 {
		return
	}
	if parsed, ok := extractOpenAIUsageFromJSONBytes(body); ok {
		*usage = parsed
	}
}

func getOpenAIGroupIDFromContext(c *gin.Context) int64 {
	if c == nil {
		return 0
	}
	value, exists := c.Get("api_key")
	if !exists {
		return 0
	}
	apiKey, ok := value.(*APIKey)
	if !ok || apiKey == nil || apiKey.GroupID == nil {
		return 0
	}
	return *apiKey.GroupID
}

// SelectAccountByPreviousResponseID 按 previous_response_id 命中账号粘连。
// 未命中或账号不可用时返回 (nil, nil)，由调用方继续走常规调度。
func (s *OpenAIGatewayService) SelectAccountByPreviousResponseID(
	ctx context.Context,
	groupID *int64,
	previousResponseID string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requireCompact bool,
) (*AccountSelectionResult, error) {
	return s.selectAccountByPreviousResponseIDForCapability(ctx, groupID, previousResponseID, requestedModel, excludedIDs, "", requireCompact)
}

func (s *OpenAIGatewayService) selectAccountByPreviousResponseIDForCapability(
	ctx context.Context,
	groupID *int64,
	previousResponseID string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requiredCapability OpenAIEndpointCapability,
	requireCompact bool,
) (*AccountSelectionResult, error) {
	if s == nil {
		return nil, nil
	}
	accountID, account, responseID, store := s.resolveAccountByPreviousResponseIDForCapability(ctx, groupID, previousResponseID, requestedModel, excludedIDs, requiredCapability, requireCompact)
	if accountID <= 0 || account == nil || store == nil {
		return nil, nil
	}

	result, acquireErr := s.tryAcquireAccountSlot(ctx, accountID, account.Concurrency)
	if errors.Is(acquireErr, ErrPriorityAdmissionUnavailable) {
		return nil, acquireErr
	}
	if acquireErr == nil && result.Acquired {
		logOpenAIWSBindResponseAccountWarn(
			derefGroupID(groupID),
			accountID,
			responseID,
			store.BindResponseAccount(ctx, derefGroupID(groupID), responseID, accountID, s.openAIWSResponseStickyTTL()),
		)
		return &AccountSelectionResult{
			Account:     account,
			Acquired:    true,
			ReleaseFunc: result.ReleaseFunc,
		}, nil
	}

	cfg := s.schedulingConfig()
	if s.concurrencyService != nil {
		return &AccountSelectionResult{
			Account: account,
			WaitPlan: &AccountWaitPlan{
				AccountID:      accountID,
				MaxConcurrency: account.Concurrency,
				Timeout:        cfg.StickySessionWaitTimeout,
				MaxWaiting:     cfg.StickySessionMaxWaiting,
			},
		}, nil
	}
	return nil, nil
}

func (s *OpenAIGatewayService) ResolveAccountIDByPreviousResponseIDForScheduler(
	ctx context.Context,
	groupID *int64,
	previousResponseID string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requiredCapability OpenAIEndpointCapability,
	requireCompact bool,
) int64 {
	accountID, _, _, _ := s.resolveAccountByPreviousResponseIDForCapability(ctx, groupID, previousResponseID, requestedModel, excludedIDs, requiredCapability, requireCompact)
	return accountID
}

func (s *OpenAIGatewayService) resolveAccountByPreviousResponseIDForCapability(
	ctx context.Context,
	groupID *int64,
	previousResponseID string,
	requestedModel string,
	excludedIDs map[int64]struct{},
	requiredCapability OpenAIEndpointCapability,
	requireCompact bool,
) (int64, *Account, string, OpenAIWSStateStore) {
	if s == nil {
		return 0, nil, "", nil
	}
	responseID := strings.TrimSpace(previousResponseID)
	if responseID == "" {
		return 0, nil, "", nil
	}
	store := s.getOpenAIWSStateStore()
	if store == nil {
		return 0, nil, "", nil
	}

	accountID, err := store.GetResponseAccount(ctx, derefGroupID(groupID), responseID)
	if err != nil || accountID <= 0 {
		return 0, nil, "", nil
	}
	if excludedIDs != nil {
		if _, excluded := excludedIDs[accountID]; excluded {
			return 0, nil, "", nil
		}
	}

	account, err := s.getSchedulableAccount(ctx, accountID)
	if err != nil || account == nil {
		_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
		return 0, nil, "", nil
	}
	if !codexContinuationSchedulingMatches(ctx, account) {
		return 0, nil, "", nil
	}
	// 非 WSv2 场景（如 force_http/全局关闭）不应使用 previous_response_id 粘连，
	// 以保持“回滚到 HTTP”后的历史行为一致性。
	if s.getOpenAIWSProtocolResolver().Resolve(account).Transport != OpenAIUpstreamTransportResponsesWebsocketV2 {
		return 0, nil, "", nil
	}
	if shouldClearStickySession(account, requestedModel) || !account.IsOpenAI() || !account.IsSchedulable() {
		_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
		return 0, nil, "", nil
	}
	if !parentHealthyForShadow(account, s.parentAccountLookup(ctx)) {
		_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
		return 0, nil, "", nil
	}
	if requestedModel != "" && !supportsOpenAIRequestModel(account, requestedModel, openAIRequestModelForSupport(ctx, requestedModel), requireCompact) {
		return 0, nil, "", nil
	}
	if !account.SupportsOpenAIEndpointCapability(requiredCapability) {
		return 0, nil, "", nil
	}
	// Quota auto-pause must also gate the previous_response_id sticky path; otherwise an
	// account over its 5h/7d threshold keeps serving the same response chain even though
	// normal scheduling skips it. Pause is transient, so fall through to normal scheduling
	// without deleting the binding (the window may reset before the next turn).
	if paused, _ := shouldAutoPauseOpenAIAccountByQuota(ctx, account); paused {
		return 0, nil, "", nil
	}
	if s.isOpenAIAccountRequestRuntimeBlocked(account, requestedModel) {
		_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
		return 0, nil, "", nil
	}
	if s.schedulerSnapshot != nil && s.accountRepo != nil {
		latest, latestErr := s.accountRepo.GetByID(ctx, account.ID)
		if latestErr != nil || latest == nil {
			_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
			return 0, nil, "", nil
		}
		if !codexContinuationSchedulingMatches(ctx, latest) {
			return 0, nil, "", nil
		}
		if shouldClearStickySession(latest, requestedModel) || !latest.IsOpenAI() || !latest.IsSchedulable() {
			_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
			return 0, nil, "", nil
		}
		if !parentHealthyForShadow(latest, s.parentAccountLookup(ctx)) {
			_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
			return 0, nil, "", nil
		}
		if requestedModel != "" && !supportsOpenAIRequestModel(latest, requestedModel, openAIRequestModelForSupport(ctx, requestedModel), requireCompact) {
			return 0, nil, "", nil
		}
		if !latest.SupportsOpenAIEndpointCapability(requiredCapability) {
			return 0, nil, "", nil
		}
		if paused, _ := shouldAutoPauseOpenAIAccountByQuota(ctx, latest); paused {
			return 0, nil, "", nil
		}
		if s.isOpenAIAccountRequestRuntimeBlocked(latest, requestedModel) {
			_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
			return 0, nil, "", nil
		}
		account = latest
	}
	if requireCompact && openAICompactSupportTier(account) == 0 {
		_ = store.DeleteResponseAccount(ctx, derefGroupID(groupID), responseID)
		return 0, nil, "", nil
	}
	return accountID, account, responseID, store
}

func classifyOpenAIWSAcquireError(err error) string {
	if err == nil {
		return "acquire_conn"
	}
	var dialErr *openAIWSDialError
	if errors.As(err, &dialErr) {
		switch dialErr.StatusCode {
		case 426:
			return "upgrade_required"
		case 401, 403:
			return "auth_failed"
		case 429:
			return "upstream_rate_limited"
		}
		if dialErr.StatusCode >= 500 {
			return "upstream_5xx"
		}
		return "dial_failed"
	}
	if errors.Is(err, errOpenAIWSConnQueueFull) {
		return "conn_queue_full"
	}
	if errors.Is(err, errOpenAIWSPreferredConnUnavailable) {
		return "preferred_conn_unavailable"
	}
	if errors.Is(err, context.DeadlineExceeded) {
		return "acquire_timeout"
	}
	return "acquire_conn"
}

func isOpenAIWSRateLimitError(codeRaw, errTypeRaw, msgRaw string) bool {
	code := strings.ToLower(strings.TrimSpace(codeRaw))
	errType := strings.ToLower(strings.TrimSpace(errTypeRaw))
	msg := strings.ToLower(strings.TrimSpace(msgRaw))

	if strings.Contains(errType, "rate_limit") || strings.Contains(errType, "usage_limit") {
		return true
	}
	if strings.Contains(code, "rate_limit") || strings.Contains(code, "usage_limit") || strings.Contains(code, "insufficient_quota") {
		return true
	}
	if strings.Contains(msg, "usage limit") && strings.Contains(msg, "reached") {
		return true
	}
	if strings.Contains(msg, "rate limit") && (strings.Contains(msg, "reached") || strings.Contains(msg, "exceeded")) {
		return true
	}
	return false
}

// isOpenAIWSOverloadError is deliberately narrower than the generic 5xx
// classifier.  Codex emits this condition as either a typed error event or a
// response.failed envelope, and some compatible upstreams omit the error code
// while retaining the canonical message.  Only this explicit capacity signal
// is safe to replay before semantic output.
func isOpenAIWSOverloadError(codeRaw, errTypeRaw, msgRaw string) bool {
	code := strings.ToLower(strings.TrimSpace(codeRaw))
	errType := strings.ToLower(strings.TrimSpace(errTypeRaw))
	msg := strings.ToLower(strings.TrimSpace(msgRaw))
	switch code {
	case "server_is_overloaded", "slow_down":
		return true
	}
	if isOpenAICapacityShedMessage(msg) {
		return true
	}
	if strings.Contains(errType, "service_unavailable") ||
		strings.Contains(errType, "overload") ||
		strings.Contains(errType, "slow_down") {
		return true
	}
	return false
}

// isOpenAIWSOverloadPayload handles both WS event shapes.  A 503-only
// response.failed envelope is included because a few upstream gateways omit
// the semantic code and message entirely.
func isOpenAIWSOverloadPayload(payload []byte) bool {
	if len(payload) == 0 {
		return false
	}
	if isOpenAIUpstreamCapacityShedEvent(payload) {
		return true
	}
	if openAIWSPayloadStatusCode(payload) == http.StatusServiceUnavailable {
		return true
	}
	code := strings.TrimSpace(gjson.GetBytes(payload, "error.code").String())
	if code == "" {
		code = strings.TrimSpace(gjson.GetBytes(payload, "response.error.code").String())
	}
	errType := strings.TrimSpace(gjson.GetBytes(payload, "error.type").String())
	if errType == "" {
		errType = strings.TrimSpace(gjson.GetBytes(payload, "response.error.type").String())
	}
	msg := strings.TrimSpace(gjson.GetBytes(payload, "error.message").String())
	if msg == "" {
		msg = strings.TrimSpace(gjson.GetBytes(payload, "response.error.message").String())
	}
	return isOpenAIWSOverloadError(code, errType, msg)
}

// newOpenAIWSOverloadFailoverError keeps the original event body and
// handshake headers.  The HTTP handler can therefore run its normal bounded
// account loop and, when exhausted, return the upstream's useful diagnostics
// instead of a synthetic generic 502.
func newOpenAIWSOverloadFailoverError(headers http.Header, payload []byte, message string) *UpstreamFailoverError {
	status := openAIWSPayloadStatusCode(payload)
	if status < http.StatusInternalServerError || status > 599 {
		status = http.StatusServiceUnavailable
	}
	err := newOpenAIUpstreamFailoverError(
		status,
		headers,
		append([]byte(nil), payload...),
		message,
		false,
	)
	// A status-only envelope is still request-scoped capacity shedding even
	// though the generic constructor cannot identify it from the body alone.
	err.Scope = GatewayFailureScopeRequest
	err.RetryableOnSameAccount = true
	return err
}

func isOpenAIWSRateLimitsPreamble(eventType string) bool {
	eventType = strings.ToLower(strings.TrimSpace(eventType))
	return eventType == "codex.rate_limits" ||
		eventType == "rate_limits" ||
		strings.HasPrefix(eventType, "rate_limits.") ||
		eventType == "response.rate_limits" ||
		strings.HasPrefix(eventType, "response.rate_limits.")
}

func (s *OpenAIGatewayService) persistOpenAIWSRateLimitSignal(ctx context.Context, account *Account, headers http.Header, responseBody []byte, codeRaw, errTypeRaw, msgRaw string, canonicalModel ...string) {
	if s == nil || s.rateLimitService == nil || account == nil || account.Platform != PlatformOpenAI {
		return
	}
	if !isOpenAIWSRateLimitError(codeRaw, errTypeRaw, msgRaw) {
		return
	}
	s.handleOpenAIAccountUpstreamError(ctx, account, http.StatusTooManyRequests, headers, responseBody, canonicalModel...)
}

func classifyOpenAIWSErrorEventFromRaw(codeRaw, errTypeRaw, msgRaw string) (string, bool) {
	code := strings.ToLower(strings.TrimSpace(codeRaw))
	errType := strings.ToLower(strings.TrimSpace(errTypeRaw))
	msg := strings.ToLower(strings.TrimSpace(msgRaw))

	switch code {
	case "upgrade_required":
		return "upgrade_required", true
	case "websocket_not_supported", "websocket_unsupported":
		return "ws_unsupported", true
	case "websocket_connection_limit_reached":
		return "ws_connection_limit_reached", true
	case "invalid_encrypted_content":
		return "invalid_encrypted_content", true
	case "previous_response_not_found":
		return "previous_response_not_found", true
	}
	if isOpenAIWSOverloadError(codeRaw, errTypeRaw, msgRaw) {
		return "upstream_overloaded", true
	}
	if isOpenAIWSRateLimitError(codeRaw, errTypeRaw, msgRaw) {
		return "upstream_rate_limited", false
	}
	if strings.Contains(msg, "upgrade required") || strings.Contains(msg, "status 426") {
		return "upgrade_required", true
	}
	if strings.Contains(errType, "upgrade") {
		return "upgrade_required", true
	}
	if strings.Contains(msg, "websocket") && strings.Contains(msg, "unsupported") {
		return "ws_unsupported", true
	}
	if strings.Contains(msg, "connection limit") && strings.Contains(msg, "websocket") {
		return "ws_connection_limit_reached", true
	}
	if strings.Contains(msg, "invalid_encrypted_content") ||
		(strings.Contains(msg, "encrypted content") && strings.Contains(msg, "could not be verified")) {
		return "invalid_encrypted_content", true
	}
	if strings.Contains(msg, "previous_response_not_found") ||
		(strings.Contains(msg, "previous response") && strings.Contains(msg, "not found")) {
		return "previous_response_not_found", true
	}
	if strings.EqualFold(strings.TrimSpace(msgRaw), openAIGenericUpstreamFailureMessage) &&
		(errType == "" ||
			errType == "upstream_error" ||
			errType == "server_error" ||
			errType == "api_error" ||
			code == "upstream_error") {
		// Compatible WS upstreams may emit the same generic envelope used by the
		// HTTP transport sentinel. It is replay-safe before downstream output.
		return "upstream_error_event", true
	}
	if strings.Contains(errType, "server_error") || strings.Contains(code, "server_error") {
		return "upstream_error_event", true
	}
	return "event_error", false
}

func classifyOpenAIWSErrorEvent(message []byte) (string, bool) {
	if len(message) == 0 {
		return "event_error", false
	}
	return classifyOpenAIWSErrorEventFromRaw(parseOpenAIWSErrorEventFields(message))
}

func openAIWSErrorHTTPStatusFromRaw(codeRaw, errTypeRaw string) int {
	code := strings.ToLower(strings.TrimSpace(codeRaw))
	errType := strings.ToLower(strings.TrimSpace(errTypeRaw))
	switch {
	case strings.Contains(errType, "invalid_request"),
		strings.Contains(code, "invalid_request"),
		strings.Contains(code, "bad_request"),
		code == "invalid_encrypted_content",
		code == "previous_response_not_found":
		return http.StatusBadRequest
	case strings.Contains(errType, "authentication"),
		strings.Contains(code, "invalid_api_key"),
		strings.Contains(code, "unauthorized"):
		return http.StatusUnauthorized
	case strings.Contains(errType, "permission"),
		strings.Contains(code, "forbidden"):
		return http.StatusForbidden
	case isOpenAIWSOverloadError(codeRaw, errTypeRaw, ""):
		return http.StatusServiceUnavailable
	case isOpenAIWSRateLimitError(codeRaw, errTypeRaw, ""):
		return http.StatusTooManyRequests
	default:
		return http.StatusBadGateway
	}
}

func openAIWSErrorHTTPStatus(message []byte) int {
	if len(message) == 0 {
		return http.StatusBadGateway
	}
	if isOpenAIWSOverloadPayload(message) {
		return http.StatusServiceUnavailable
	}
	codeRaw, errTypeRaw, _ := parseOpenAIWSErrorEventFields(message)
	return openAIWSErrorHTTPStatusFromRaw(codeRaw, errTypeRaw)
}

func (s *OpenAIGatewayService) openAIWSFallbackCooldown() time.Duration {
	if s == nil || s.cfg == nil {
		return 30 * time.Second
	}
	seconds := s.cfg.Gateway.OpenAIWS.FallbackCooldownSeconds
	if seconds <= 0 {
		return 0
	}
	return time.Duration(seconds) * time.Second
}

func (s *OpenAIGatewayService) isOpenAIWSFallbackCooling(accountID int64) bool {
	if s == nil || accountID <= 0 {
		return false
	}
	cooldown := s.openAIWSFallbackCooldown()
	if cooldown <= 0 {
		return false
	}
	rawUntil, ok := s.openaiWSFallbackUntil.Load(accountID)
	if !ok || rawUntil == nil {
		return false
	}
	until, ok := rawUntil.(time.Time)
	if !ok || until.IsZero() {
		s.openaiWSFallbackUntil.Delete(accountID)
		return false
	}
	if time.Now().Before(until) {
		return true
	}
	s.openaiWSFallbackUntil.Delete(accountID)
	return false
}

func (s *OpenAIGatewayService) markOpenAIWSFallbackCooling(accountID int64, _ string) {
	if s == nil || accountID <= 0 {
		return
	}
	cooldown := s.openAIWSFallbackCooldown()
	if cooldown <= 0 {
		return
	}
	s.openaiWSFallbackUntil.Store(accountID, time.Now().Add(cooldown))
}

func (s *OpenAIGatewayService) clearOpenAIWSFallbackCooling(accountID int64) {
	if s == nil || accountID <= 0 {
		return
	}
	s.openaiWSFallbackUntil.Delete(accountID)
}
