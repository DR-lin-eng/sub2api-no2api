package service

import (
	"context"
	"log/slog"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	openAIAccountStateUpdateTimeout       = 5 * time.Second
	openAIOAuth429FallbackCooldown        = 5 * time.Second
	openAIStopSchedulingBridgeCooldown    = 2 * time.Minute
	openAIOAuth429StormWindow             = 10 * time.Second
	openAIOAuth429StormThreshold          = 20
	openAIOAuth429StormMaxAccountSwitches = 1
)

// OpenAIOAuth429FailoverState tracks the request-local follow-up budget after
// the first Grok OAuth 429. Once that 429 occurs, exactly one different account
// may be attempted; any failure from that follow-up account ends failover.
type OpenAIOAuth429FailoverState struct {
	grokOAuth429FollowupPending bool
}

var openAIAccountRuntimeBlockedFailoverErr = &UpstreamFailoverError{
	StatusCode:   http.StatusServiceUnavailable,
	ResponseBody: []byte(`{"error":{"type":"upstream_error","message":"Selected upstream channel became unavailable"}}`),
}

func openAIAccountStateContext(ctx context.Context) (context.Context, context.CancelFunc) {
	base := context.Background()
	if ctx != nil {
		base = context.WithoutCancel(ctx)
	}
	return context.WithTimeout(base, openAIAccountStateUpdateTimeout)
}

func isOpenAIOAuthAccount(account *Account) bool {
	return account != nil && account.Platform == PlatformOpenAI && account.Type == AccountTypeOAuth
}

func isGrokOAuthAccount(account *Account) bool {
	return account != nil && account.Platform == PlatformGrok && account.Type == AccountTypeOAuth
}

func isOpenAIAccount(account *Account) bool {
	return account != nil && account.IsOpenAICompatible()
}

func (s *OpenAIGatewayService) autoDisableOnUpstreamInsufficientBalance(ctx context.Context, account *Account, statusCode int, responseBody []byte) bool {
	return s != nil && s.rateLimitService != nil &&
		s.rateLimitService.handleUpstreamInsufficientBalance(ctx, account, statusCode, responseBody)
}

// handleOpenAIAccountUpstreamError expects canonicalModel to be the model used
// for scheduling after applying account mapping exactly once.
func (s *OpenAIGatewayService) handleOpenAIAccountUpstreamError(ctx context.Context, account *Account, statusCode int, headers http.Header, responseBody []byte, canonicalModel ...string) bool {
	if account != nil && account.Platform == PlatformGrok && isGrokContentPolicyRejection(statusCode, responseBody) {
		return false
	}
	// Any non-2xx upstream HTTP response means the model request was actually sent.
	if s != nil {
		scheduleOllamaCloudUsageActivity(s.deferredService, account)
	}
	if account != nil && account.Platform == PlatformOpenAI && isOpenAIInvalidPromptPolicyError("", responseBody) {
		return false
	}
	// Capacity shedding describes this request, not account health. The request
	// retry budget handles recovery without cooling down the selected account.
	if account != nil && account.Platform == PlatformOpenAI && isOpenAIRequestScopedCapacityShed("", responseBody) {
		return false
	}
	if statusCode == http.StatusForbidden && s.disableOpenAIAgentIdentityOnForbidden(ctx, account, responseBody) {
		return true
	}
	stateCtx, cancel := openAIAccountStateContext(ctx)
	defer cancel()
	stateCtx = withOAuth401CleanupAttemptState(stateCtx)
	modelScope := firstRequestedModel(canonicalModel)
	if statusCode == http.StatusUnauthorized && s.rateLimitService != nil && s.rateLimitService.tryAutoDeleteOAuthAccountOn401(stateCtx, account) {
		return true
	}
	if s != nil && s.rateLimitService != nil && s.rateLimitService.maybeAutoDisableOpenAIAccountOnFailure(stateCtx, account, statusCode, headers, responseBody) {
		return true
	}
	if statusCode != http.StatusUnauthorized && s.autoDisableOnUpstreamInsufficientBalance(stateCtx, account, statusCode, responseBody) {
		return true
	}
	if statusCode == http.StatusTooManyRequests && account.BypassesLocalOpenAI429SchedulingBlocks() {
		if s != nil && s.rateLimitService != nil {
			persistOpenAI429PlanType(stateCtx, s.rateLimitService.accountRepo, account, responseBody)
			s.rateLimitService.persistOpenAICodexSnapshot(stateCtx, account, headers)
		}
		return false
	}

	if account != nil && account.Platform == PlatformOpenAI && isOpenAIContextWindowError("", responseBody) {
		return false
	}

	if isOpenAIImageRateLimitError(statusCode, responseBody) {
		if s != nil && s.rateLimitService != nil {
			_ = s.rateLimitService.HandleOpenAIImageRateLimit(stateCtx, account, statusCode, headers, responseBody)
		}
		return false
	}

	if s == nil || account == nil {
		return false
	}
	if s.rateLimitService != nil {
		// Run before model-scoped early returns so a deactivated Team cannot leave
		// sibling accounts serving traffic after the first 402 response.
		s.rateLimitService.maybeHandleOpenAITeamLinkedError(stateCtx, account, statusCode, responseBody)
	}
	if s.rateLimitService != nil && len(canonicalModel) > 0 && s.rateLimitService.HandleUpstreamModelNotFound(stateCtx, account, canonicalModel[0], statusCode, responseBody) {
		return true
	}
	// Isolate a custom temporary-unschedulable match to the known upstream
	// model before entering the generic account error path. This keeps the
	// account available to other models and avoids the account runtime blocker.
	if s.rateLimitService != nil && statusCode != http.StatusUnauthorized && len(canonicalModel) > 0 && strings.TrimSpace(canonicalModel[0]) != "" &&
		s.rateLimitService.HandleTempUnschedulable(stateCtx, account, statusCode, responseBody, canonicalModel[0]) {
		return true
	}
	// A Codex reset signal identifies the (account, model) quota window that
	// the RateLimitService can persist. Keep the local account-wide bridge only
	// for 429s without a model-scoped reset signal; otherwise one model's quota
	// exhaustion would evict the OAuth account from every model.
	modelScoped429 := statusCode == http.StatusTooManyRequests && strings.TrimSpace(modelScope) != "" &&
		(s.rateLimitService != nil && (calculateOpenAI429ResetTime(headers) != nil || parseOpenAIRateLimitResetTime(responseBody) != nil))
	if statusCode == http.StatusTooManyRequests && !modelScoped429 {
		s.markOpenAIOAuth429RateLimited(stateCtx, account, headers, responseBody)
	}
	if s.rateLimitService == nil {
		return false
	}
	if strings.TrimSpace(modelScope) != "" && s.rateLimitService.HandleUpstreamModelNotFound(stateCtx, account, modelScope, statusCode, responseBody) {
		return true
	}
	genericModelScope := modelScope
	if statusCode == http.StatusTooManyRequests && !account.IsPoolMode() && !modelScoped429 {
		genericModelScope = ""
	}
	shouldDisable := s.rateLimitService.HandleUpstreamError(stateCtx, account, statusCode, headers, responseBody, genericModelScope)
	modelTempMatched := statusCode != http.StatusUnauthorized && strings.TrimSpace(modelScope) != "" &&
		len(matchTempUnschedulableRules(account, statusCode, responseBody)) > 0
	if shouldDisable {
		if !globalTempUnschedulableEnabled(ctx, s.settingService) &&
			((statusCode == http.StatusUnauthorized && account.Type == AccountTypeOAuth) ||
				(statusCode == http.StatusForbidden && account.Platform == PlatformOpenAI)) {
			return shouldDisable
		}
		if !modelTempMatched {
			s.BlockAccountScheduling(account, time.Time{}, "upstream_disable")
		}
	}
	// Pool-mode retryable upstream errors are already bounded by the request-local
	// same-account retry budget. Recording the generic account+model transient
	// cooldown here would block the next approved retry before that budget is used.
	poolModeRetryable := account.IsPoolMode() && account.IsPoolModeRetryableStatus(statusCode)
	if !shouldDisable && account.Platform == PlatformOpenAI && account.Type == AccountTypeAPIKey &&
		shouldCooldownOpenAITransientUpstreamError(statusCode, responseBody) && !poolModeRetryable {
		model := ""
		if len(canonicalModel) > 0 {
			model = canonicalModel[0]
		}
		decision := s.recordOpenAIAccountModelTransientFailure(account, model, time.Now())
		if decision.FailureStreak > 0 {
			slog.Warn("openai_model_transient_state",
				"account_id", account.ID,
				"model", openAIAccountModelTransientModel(model),
				"failure_streak", decision.FailureStreak,
				"cooldown_ms", decision.Cooldown.Milliseconds(),
				"block_scope", "account_model",
			)
		}
	}
	return shouldDisable
}

func shouldCooldownOpenAITransientUpstreamError(statusCode int, responseBody []byte) bool {
	switch statusCode {
	case http.StatusInternalServerError, http.StatusBadGateway, http.StatusServiceUnavailable, http.StatusGatewayTimeout, 520, 521, 522, 523, 524:
		return true
	case http.StatusBadRequest:
		return isOpenAITransientProcessingError(statusCode, "", responseBody)
	default:
		return false
	}
}

func (s *OpenAIGatewayService) markOpenAIOAuth429RateLimited(ctx context.Context, account *Account, headers http.Header, responseBody []byte) {
	if s == nil || !isOpenAIOAuthAccount(account) || account.BypassesLocalOpenAI429SchedulingBlocks() {
		return
	}
	// Spark 影子：不按 /responses 429 的 global x-codex-* 信号做内存运行时熔断(同 handle429,外审第8轮 P1)。
	// 同时避免把 spark 的 429 计入全局 429 storm 计数(recordOpenAIOAuth429),否则会误伤母账号 failover 决策。
	if account.IsShadow() {
		return
	}
	s.recordOpenAIOAuth429()

	now := time.Now()
	cooldownUntil := now.Add(openAIOAuth429FallbackCooldown)
	if s.rateLimitService != nil {
		if resetAt := s.rateLimitService.calculateOpenAI429ResetTime(headers); resetAt != nil && resetAt.After(now) {
			cooldownUntil = *resetAt
		} else if resetUnix := parseOpenAIRateLimitResetTime(responseBody); resetUnix != nil {
			if resetAt := time.Unix(*resetUnix, 0); resetAt.After(now) {
				cooldownUntil = resetAt
			} else {
				cooldown, ok := s.rateLimitService.get429FallbackCooldown(ctx, account)
				if !ok || cooldown <= 0 {
					return
				}
				cooldownUntil = now.Add(cooldown)
			}
		} else {
			cooldown, ok := s.rateLimitService.get429FallbackCooldown(ctx, account)
			if !ok || cooldown <= 0 {
				return
			}
			cooldownUntil = now.Add(cooldown)
		}
	}
	s.BlockAccountScheduling(account, cooldownUntil, "429")
}

func (s *OpenAIGatewayService) BlockAccountScheduling(account *Account, until time.Time, reason string) {
	if s == nil || !isOpenAIAccount(account) {
		return
	}
	if account.BypassesLocalOpenAI429SchedulingBlocks() && isOpenAI429RuntimeBlockReason(reason) {
		return
	}
	mu := s.openAIAccountRuntimeBlockLock(account.ID)
	mu.Lock()
	defer mu.Unlock()
	_, _ = s.blockAccountSchedulingLocked(account, until, reason)
}

func (s *OpenAIGatewayService) openAIAccountRuntimeBlockLock(accountID int64) *sync.Mutex {
	actual, _ := s.openaiAccountRuntimeBlockLocks.LoadOrStore(accountID, &sync.Mutex{})
	mu, ok := actual.(*sync.Mutex)
	if !ok {
		mu = &sync.Mutex{}
		s.openaiAccountRuntimeBlockLocks.Store(accountID, mu)
	}
	return mu
}

func (s *OpenAIGatewayService) blockAccountSchedulingLocked(account *Account, until time.Time, reason string) (uint64, bool) {
	generation := s.openaiAccountRuntimeBlockSequence.Add(1)
	s.openaiAccountRuntimeBlockGeneration.Store(account.ID, generation)
	now := time.Now()
	blockUntil := until
	if blockUntil.IsZero() || !blockUntil.After(now) {
		blockUntil = now.Add(openAIStopSchedulingBridgeCooldown)
	}

	for {
		current, loaded := s.openaiAccountRuntimeBlockUntil.Load(account.ID)
		if !loaded {
			actual, stored := s.openaiAccountRuntimeBlockUntil.LoadOrStore(account.ID, blockUntil)
			if !stored {
				s.openaiAccountRuntimeBlockReason.Store(account.ID, strings.TrimSpace(reason))
				s.setOpenAIAccountRuntimeBlockReasonLocked(account.ID, reason)
				return generation, true
			}
			current = actual
		}

		currentUntil, ok := current.(time.Time)
		if !ok || currentUntil.IsZero() {
			if s.openaiAccountRuntimeBlockUntil.CompareAndSwap(account.ID, current, blockUntil) {
				s.openaiAccountRuntimeBlockReason.Store(account.ID, strings.TrimSpace(reason))
				s.setOpenAIAccountRuntimeBlockReasonLocked(account.ID, reason)
				return generation, true
			}
			continue
		}
		if !blockUntil.After(currentUntil) {
			return generation, false
		}
		if s.openaiAccountRuntimeBlockUntil.CompareAndSwap(account.ID, current, blockUntil) {
			s.openaiAccountRuntimeBlockReason.Store(account.ID, strings.TrimSpace(reason))
			s.setOpenAIAccountRuntimeBlockReasonLocked(account.ID, reason)
			return generation, true
		}
	}
}

func (s *OpenAIGatewayService) setOpenAIAccountRuntimeBlockReasonLocked(accountID int64, reason string) {
	if isTempUnschedulableRuntimeBlockReason(reason) {
		s.openaiAccountRuntimeTempUnsched.Store(accountID, struct{}{})
		return
	}
	s.openaiAccountRuntimeTempUnsched.Delete(accountID)
}

func (s *OpenAIGatewayService) ClearAccountSchedulingBlock(accountID int64) {
	if s == nil || accountID <= 0 {
		return
	}
	mu := s.openAIAccountRuntimeBlockLock(accountID)
	mu.Lock()
	defer mu.Unlock()
	s.openaiAccountRuntimeBlockUntil.Delete(accountID)
	s.openaiAccountRuntimeBlockReason.Delete(accountID)
	s.openaiAccountRuntimeTempUnsched.Delete(accountID)
	s.openaiAccountRuntimeBlockGeneration.Store(accountID, s.openaiAccountRuntimeBlockSequence.Add(1))
}

// ClearAccountSchedulingBlockIfReason removes only the transient block created
// for the supplied reason. A recovered transport attempt must not erase an
// unrelated OAuth, rate-limit, or administrator-enforced block.
func (s *OpenAIGatewayService) ClearAccountSchedulingBlockIfReason(accountID int64, reason string) {
	if s == nil || accountID <= 0 || strings.TrimSpace(reason) == "" {
		return
	}
	mu := s.openAIAccountRuntimeBlockLock(accountID)
	mu.Lock()
	defer mu.Unlock()
	value, ok := s.openaiAccountRuntimeBlockReason.Load(accountID)
	currentReason, _ := value.(string)
	if !ok || strings.TrimSpace(currentReason) != strings.TrimSpace(reason) {
		return
	}
	s.clearOpenAIAccountRuntimeBlockLocked(accountID)
}

func (s *OpenAIGatewayService) DeleteAccountRuntimeState(accountID int64) {
	if s == nil || accountID <= 0 {
		return
	}
	mu := s.openAIAccountRuntimeBlockLock(accountID)
	mu.Lock()
	s.openaiAccountRuntimeBlockUntil.Delete(accountID)
	s.openaiAccountRuntimeBlockReason.Delete(accountID)
	s.openaiAccountRuntimeTempUnsched.Delete(accountID)
	s.openaiAccountRuntimeBlockGeneration.Store(accountID, s.openaiAccountRuntimeBlockSequence.Add(1))
	mu.Unlock()
	s.openaiWSFallbackUntil.Delete(accountID)
	s.openaiCompatSessionResponses.DeletePrefix(strconv.FormatInt(accountID, 10) + "\x00")
	s.openaiCompatAnthropicDigestSessions.DeletePrefix(strconv.FormatInt(accountID, 10) + "|")
	if s.openaiAccountStats != nil {
		s.openaiAccountStats.delete(accountID)
	}
	if s.codexSnapshotThrottle != nil {
		s.codexSnapshotThrottle.Delete(accountID)
	}
	if s.openaiWSPool != nil {
		s.openaiWSPool.RemoveAccount(accountID)
	}
}

func (s *OpenAIGatewayService) isOpenAIAccountRuntimeBlocked(account *Account) bool {
	if s == nil || !isOpenAIAccount(account) {
		return false
	}
	mu := s.openAIAccountRuntimeBlockLock(account.ID)
	mu.Lock()
	defer mu.Unlock()
	if account.BypassesLocalOpenAI429SchedulingBlocks() {
		reasonValue, _ := s.openaiAccountRuntimeBlockReason.Load(account.ID)
		reason, _ := reasonValue.(string)
		if isOpenAI429RuntimeBlockReason(reason) ||
			(isTempUnschedulableRuntimeBlockReason(reason) && account.bypassesLocalOpenAI429TempUnschedulable()) {
			s.clearOpenAIAccountRuntimeBlockLocked(account.ID)
			return false
		}
	}
	if _, isTempUnsched := s.openaiAccountRuntimeTempUnsched.Load(account.ID); isTempUnsched &&
		!globalTempUnschedulableEnabled(context.Background(), s.settingService) {
		s.clearOpenAIAccountRuntimeBlockLocked(account.ID)
		return false
	}
	value, ok := s.openaiAccountRuntimeBlockUntil.Load(account.ID)
	if !ok {
		s.openaiAccountRuntimeBlockReason.Delete(account.ID)
		s.openaiAccountRuntimeTempUnsched.Delete(account.ID)
		return false
	}
	cooldownUntil, ok := value.(time.Time)
	if !ok || cooldownUntil.IsZero() {
		s.clearOpenAIAccountRuntimeBlockLocked(account.ID)
		return false
	}
	if time.Now().Before(cooldownUntil) {
		return true
	}
	s.clearOpenAIAccountRuntimeBlockLocked(account.ID)
	return false
}

func (s *OpenAIGatewayService) clearOpenAIAccountRuntimeBlockLocked(accountID int64) {
	s.openaiAccountRuntimeBlockUntil.Delete(accountID)
	s.openaiAccountRuntimeBlockReason.Delete(accountID)
	s.openaiAccountRuntimeTempUnsched.Delete(accountID)
	s.openaiAccountRuntimeBlockGeneration.Store(accountID, s.openaiAccountRuntimeBlockSequence.Add(1))
}

func isOpenAI429RuntimeBlockReason(reason string) bool {
	switch strings.TrimSpace(reason) {
	case "429", "429_fallback":
		return true
	default:
		return false
	}
}

func (s *OpenAIGatewayService) getOpenAIAccountModelTransientState() *openAIAccountModelTransientState {
	if s == nil {
		return nil
	}
	s.openaiModelTransientOnce.Do(func() {
		if s.openaiModelTransient == nil {
			s.openaiModelTransient = newOpenAIAccountModelTransientState(openAIModelTransientDefaultMax)
		}
	})
	return s.openaiModelTransient
}

func canonicalOpenAIAccountSchedulingModel(account *Account, requestedModel string) string {
	model := strings.TrimSpace(requestedModel)
	if account == nil || model == "" {
		return model
	}
	if mapped := strings.TrimSpace(account.GetMappedModel(model)); mapped != "" {
		return mapped
	}
	return model
}

func openAIAccountModelTransientModel(canonicalModel string) string {
	return normalizeOpenAIAccountModelTransientModel(canonicalModel)
}

func (s *OpenAIGatewayService) recordOpenAIAccountModelTransientFailure(account *Account, canonicalModel string, now time.Time) openAIAccountModelTransientDecision {
	if s == nil || account == nil {
		return openAIAccountModelTransientDecision{}
	}
	state := s.getOpenAIAccountModelTransientState()
	if state == nil {
		return openAIAccountModelTransientDecision{}
	}
	return state.recordFailure(account.ID, openAIAccountModelTransientModel(canonicalModel), now)
}

func (s *OpenAIGatewayService) blockOpenAIAccountModelTransient(account *Account, canonicalModel string, cooldown time.Duration, now time.Time) openAIAccountModelTransientDecision {
	if s == nil || account == nil {
		return openAIAccountModelTransientDecision{}
	}
	state := s.getOpenAIAccountModelTransientState()
	if state == nil {
		return openAIAccountModelTransientDecision{}
	}
	return state.blockFor(account.ID, openAIAccountModelTransientModel(canonicalModel), cooldown, now)
}

func (s *OpenAIGatewayService) clearOpenAIAccountModelTransientState(accountID int64, model string) {
	state := s.getOpenAIAccountModelTransientState()
	if state == nil {
		return
	}
	state.recordSuccess(accountID, model)
}

func (s *OpenAIGatewayService) isOpenAIAccountModelRuntimeBlocked(account *Account, requestedModel string) bool {
	if s == nil || account == nil {
		return false
	}
	state := s.getOpenAIAccountModelTransientState()
	if state == nil {
		return false
	}
	canonicalModel := canonicalOpenAIAccountSchedulingModel(account, requestedModel)
	return state.isBlocked(account.ID, openAIAccountModelTransientModel(canonicalModel), time.Now())
}

func (s *OpenAIGatewayService) isOpenAIAccountRequestRuntimeBlocked(account *Account, requestedModel string) bool {
	return s != nil && (s.isOpenAIAccountRuntimeBlocked(account) || s.isOpenAIAccountModelRuntimeBlocked(account, requestedModel))
}

func isTempUnschedulableRuntimeBlockReason(reason string) bool {
	switch reason {
	case "oauth_401",
		"openai_403_temp",
		"temp_unschedulable",
		"stream_timeout_temp_unschedulable",
		"token_refresh_retry_exhausted",
		"transport_error",
		"grok_temp_unschedulable":
		return true
	default:
		return false
	}
}

// openAIAccountRuntimeBlockedFailover closes the select-then-wait race: an
// account can be healthy when selected, then become blocked while this request
// waits for its concurrency slot. Rechecking at the forwarding boundary keeps
// stale waiters from sending another request to the failed channel.
func (s *OpenAIGatewayService) openAIAccountRuntimeBlockedFailover(account *Account) error {
	if !s.isOpenAIAccountRuntimeBlocked(account) {
		return nil
	}
	return openAIAccountRuntimeBlockedFailoverErr
}

func (s *OpenAIGatewayService) recordOpenAIOAuth429() {
	if s == nil {
		return
	}
	now := time.Now()
	windowStart := s.openaiOAuth429WindowStartUnixNano.Load()
	if windowStart == 0 || now.Sub(time.Unix(0, windowStart)) >= openAIOAuth429StormWindow {
		if s.openaiOAuth429WindowStartUnixNano.CompareAndSwap(windowStart, now.UnixNano()) {
			s.openaiOAuth429WindowCount.Store(1)
			return
		}
	}
	s.openaiOAuth429WindowCount.Add(1)
}

func (s *OpenAIGatewayService) isOpenAIOAuth429Storm() bool {
	if s == nil {
		return false
	}
	windowStart := s.openaiOAuth429WindowStartUnixNano.Load()
	if windowStart == 0 || time.Since(time.Unix(0, windowStart)) >= openAIOAuth429StormWindow {
		return false
	}
	return s.openaiOAuth429WindowCount.Load() >= openAIOAuth429StormThreshold
}

func (s *OpenAIGatewayService) ShouldStopOpenAIOAuth429Failover(account *Account, statusCode int, failedSwitches int, state *OpenAIOAuth429FailoverState) bool {
	if failedSwitches < openAIOAuth429StormMaxAccountSwitches {
		return false
	}
	if state != nil && state.grokOAuth429FollowupPending {
		// The follow-up budget was armed by a Grok OAuth 429. Consume it on
		// any failing follow-up account, even if a mixed pool selected an API-key
		// account next.
		return true
	}
	if isGrokOAuthAccount(account) {
		if state == nil {
			// Preserve the old threshold for callers that have not adopted the
			// request-local state contract yet.
			return statusCode == http.StatusTooManyRequests && failedSwitches >= 2
		}
		if statusCode == http.StatusTooManyRequests {
			state.grokOAuth429FollowupPending = true
		}
		return false
	}
	if statusCode != http.StatusTooManyRequests || !isOpenAIOAuthAccount(account) {
		return false
	}
	if account.BypassesLocalOpenAI429SchedulingBlocks() {
		return false
	}
	return s.isOpenAIOAuth429Storm()
}
